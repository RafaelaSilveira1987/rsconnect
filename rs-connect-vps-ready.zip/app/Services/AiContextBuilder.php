<?php

declare(strict_types=1);

namespace App\Services;

use PDO;

/**
 * Monta o contexto com orçamento explícito antes da chamada ao provedor.
 * Evita reenviar todo o histórico e toda a base de conhecimento em cada turno.
 */
final class AiContextBuilder
{
    /** @var array<string,bool> */
    private array $stopWords = [];

    public function __construct(private readonly AiEfficiencyPolicyService $policy = new AiEfficiencyPolicyService())
    {
        $words = 'a,o,as,os,um,uma,de,da,do,das,dos,e,em,no,na,nos,nas,para,por,com,sem,que,se,como,qual,quais,quando,onde,porque,porquê,eu,voce,você,me,meu,minha,nossa,nosso,isso,isto,essa,esse,esta,este,tem,ter,ser,esta,está,sao,são,mais,muito,muita,pode,poder,quero,gostaria';
        foreach (explode(',', $words) as $word) {
            $this->stopWords[$this->normalize($word)] = true;
        }
    }

    /**
     * @return array{messages:array<int,array<string,mixed>>,agent:array<string,mixed>,telemetry:array<string,mixed>}
     */
    public function build(PDO $pdo, array $agent, int $conversationId, string $incomingContent): array
    {
        $profile = $this->policy->profile($agent);
        $memory = (new AiProgressiveMemoryService())->context($pdo, $conversationId);
        $historyLimit = (int) $profile['history_limit'];
        if ($memory !== null) {
            $memoryHistoryLimit = match ((string) ($profile['mode'] ?? 'balanced')) {
                'economy' => 4,
                'quality' => 10,
                default => 6,
            };
            $historyLimit = min($historyLimit, $memoryHistoryLimit);
        }
        $baselineHistoryLimit = max(4, min(30, (int) ($agent['max_context_messages'] ?? 12)));

        $aggregate = $pdo->prepare(
            'SELECT COUNT(*) AS total_messages,
                    SUM(CASE WHEN direction = "outgoing" AND status NOT IN ("failed", "cancelled") THEN 1 ELSE 0 END) AS outgoing_messages
             FROM conversation_messages
             WHERE conversation_id = :conversation_id
               AND NOT (direction = "outgoing" AND status = "failed")'
        );
        $aggregate->execute(['conversation_id' => $conversationId]);
        $historyStats = $aggregate->fetch(PDO::FETCH_ASSOC) ?: [];

        // Busca no máximo o contexto que a versão anterior enviaria. A economia estimada
        // compara contra esse baseline real, e não contra toda a conversa histórica.
        $statement = $pdo->prepare(
            'SELECT * FROM (
                SELECT direction, sender_type, content, sent_at
                FROM conversation_messages
                WHERE conversation_id = :conversation_id
                  AND NOT (direction = "outgoing" AND status = "failed")
                ORDER BY sent_at DESC, id DESC
                LIMIT ' . $baselineHistoryLimit . '
             ) recent
             ORDER BY sent_at ASC'
        );
        $statement->execute(['conversation_id' => $conversationId]);
        $baselineMessages = $statement->fetchAll(PDO::FETCH_ASSOC) ?: [];

        // 36.34.4: quando o expediente atual está aberto, uma antiga mensagem
        // operacional de ausência não deve virar contexto de verdade para o LLM.
        // Ela continua persistida/auditável no histórico da conversa, mas é removida
        // somente do contexto enviado ao provedor enquanto o status atual for aberto.
        $operatingPolicy = is_array($agent['_operating_policy'] ?? null)
            ? (array) $agent['_operating_policy']
            : (new AgentOperatingPolicyService())->status($agent);
        $afterHoursMessage = trim((string) ($agent['after_hours_message'] ?? ''));
        if (!empty($operatingPolicy['enforced']) && !empty($operatingPolicy['inside']) && $afterHoursMessage !== '') {
            $normalizedAfterHours = $this->normalizeOperationalMessage($afterHoursMessage);
            $baselineMessages = array_values(array_filter(
                $baselineMessages,
                function (array $message) use ($normalizedAfterHours): bool {
                    if ((string) ($message['direction'] ?? '') !== 'outgoing' || (string) ($message['sender_type'] ?? '') !== 'ai') {
                        return true;
                    }
                    return $this->normalizeOperationalMessage((string) ($message['content'] ?? '')) !== $normalizedAfterHours;
                }
            ));
        }

        $messages = count($baselineMessages) > $historyLimit
            ? array_slice($baselineMessages, -$historyLimit)
            : $baselineMessages;

        $baselineHistoryChars = 0;
        foreach ($baselineMessages as $message) {
            $baselineHistoryChars += mb_strlen((string) ($message['content'] ?? ''));
        }
        $historySentChars = 0;
        foreach ($messages as $message) {
            $historySentChars += mb_strlen((string) ($message['content'] ?? ''));
        }

        $knowledge = trim((string) ($agent['knowledge_base'] ?? ''));
        $knowledgeTotalChars = mb_strlen($knowledge);
        $knowledgeSent = $knowledge;

        if ($profile['selective_knowledge'] && $knowledgeTotalChars > (int) $profile['knowledge_budget_chars']) {
            $queryParts = [$incomingContent];
            foreach (array_slice($messages, -3) as $message) {
                if ((string) ($message['direction'] ?? '') === 'incoming') {
                    $queryParts[] = (string) ($message['content'] ?? '');
                }
            }
            $knowledgeSent = $this->selectKnowledge(
                $knowledge,
                implode("\n", $queryParts),
                (int) $profile['knowledge_budget_chars']
            );
        }

        $knowledgeSentChars = mb_strlen($knowledgeSent);
        $memorySummary = trim((string) ($memory['summary'] ?? ''));
        $memoryFacts = is_array($memory['facts'] ?? null) ? $memory['facts'] : [];
        $memoryChars = mb_strlen($memorySummary) + mb_strlen((string) json_encode($memoryFacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $removedChars = max(0, $baselineHistoryChars - $historySentChars - $memoryChars)
            + max(0, $knowledgeTotalChars - $knowledgeSentChars);

        $currentTurn = (new AiTurnContextService())->currentTurn($pdo, $conversationId, 8, 2200);
        $preparedAgent = $agent;
        $preparedAgent['knowledge_base'] = $knowledgeSent;
        $preparedAgent['_ai_efficiency_mode'] = $profile['mode'];
        $preparedAgent['_ai_max_output_tokens'] = $profile['max_output_tokens'];
        $preparedAgent['_current_turn_text'] = trim((string) ($currentTurn['content'] ?? '')) ?: trim($incomingContent);
        $preparedAgent['_current_turn_count'] = max(1, (int) ($currentTurn['count'] ?? 0));
        $preparedAgent['_current_turn_message_ids'] = (array) ($currentTurn['message_ids'] ?? []);
        $preparedAgent['_is_opening_turn'] = (int) ($historyStats['outgoing_messages'] ?? 0) === 0;
        if ($memorySummary !== '') {
            $preparedAgent['_conversation_memory_summary'] = $memorySummary;
            $preparedAgent['_conversation_memory_facts'] = $memoryFacts;
            $preparedAgent['_conversation_memory_refreshed_at'] = $memory['last_refreshed_at'] ?? null;
            $preparedAgent['_conversation_memory_scope'] = $memory['scope'] ?? 'conversation';
        }

        return [
            'messages' => $messages,
            'agent' => $preparedAgent,
            'telemetry' => [
                'efficiency_mode' => $profile['mode'],
                'history_messages_total' => (int) ($historyStats['total_messages'] ?? 0),
                'history_messages_sent' => count($messages),
                'knowledge_chars_total' => $knowledgeTotalChars,
                'knowledge_chars_sent' => $knowledgeSentChars,
                'estimated_input_tokens_avoided' => (int) ceil($removedChars / 4),
                'progressive_memory_used' => $memorySummary !== '',
                'memory_chars_sent' => $memoryChars,
                'memory_refresh_count' => (int) ($memory['refresh_count'] ?? 0),
                'memory_scope' => (string) ($memory['scope'] ?? ''),
                'current_turn_messages' => max(1, (int) ($currentTurn['count'] ?? 0)),
            ],
        ];
    }

    private function selectKnowledge(string $knowledge, string $query, int $budget): string
    {
        $budget = max(1000, $budget);
        if (mb_strlen($knowledge) <= $budget) {
            return $knowledge;
        }

        $chunks = preg_split('/\n\s*\n+/u', $knowledge) ?: [];
        if (count($chunks) < 2) {
            $chunks = preg_split('/(?<=\.)\s+(?=[A-ZÁÉÍÓÚÃÕÇ])/u', $knowledge) ?: [$knowledge];
        }

        $queryTerms = $this->terms($query);
        $ranked = [];
        foreach ($chunks as $index => $chunk) {
            $chunk = trim((string) $chunk);
            if ($chunk === '') {
                continue;
            }
            $terms = $this->terms($chunk);
            $score = 0;
            foreach ($queryTerms as $term => $_) {
                if (isset($terms[$term])) {
                    $score += 4;
                }
            }
            if ($index < 2) {
                $score += 2; // mantém informações introdutórias da empresa como contexto-base.
            }
            $ranked[] = ['index' => $index, 'chunk' => $chunk, 'score' => $score];
        }

        usort($ranked, static function (array $a, array $b): int {
            $scoreOrder = ($b['score'] <=> $a['score']);
            return $scoreOrder !== 0 ? $scoreOrder : ($a['index'] <=> $b['index']);
        });

        $selected = [];
        $used = 0;
        foreach ($ranked as $item) {
            $chunk = (string) $item['chunk'];
            $size = mb_strlen($chunk) + 2;
            if ($used > 0 && $used + $size > $budget) {
                continue;
            }
            if ($used === 0 && $size > $budget) {
                $chunk = mb_substr($chunk, 0, $budget);
                $size = mb_strlen($chunk);
            }
            $selected[] = ['index' => (int) $item['index'], 'chunk' => $chunk];
            $used += $size;
            if ($used >= $budget) {
                break;
            }
        }

        if ($selected === []) {
            return mb_substr($knowledge, 0, $budget);
        }

        usort($selected, static fn (array $a, array $b): int => $a['index'] <=> $b['index']);
        return trim(implode("\n\n", array_column($selected, 'chunk')));
    }

    /** @return array<string,bool> */
    private function terms(string $text): array
    {
        $normalized = $this->normalize($text);
        $parts = preg_split('/\s+/u', $normalized) ?: [];
        $terms = [];
        foreach ($parts as $part) {
            if (mb_strlen($part) < 3 || isset($this->stopWords[$part])) {
                continue;
            }
            $terms[$part] = true;
        }
        return $terms;
    }

    private function normalizeOperationalMessage(string $value): string
    {
        $value = function_exists('mb_strtolower') ? mb_strtolower(trim($value)) : strtolower(trim($value));
        $value = strtr($value, [
            'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a',
            'é' => 'e', 'ê' => 'e', 'í' => 'i',
            'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ú' => 'u', 'ü' => 'u', 'ç' => 'c',
        ]);
        return trim((string) preg_replace('/[^a-z0-9]+/u', ' ', $value));
    }

    private function normalize(string $value): string
    {
        $value = mb_strtolower(trim($value));
        $value = strtr($value, [
            'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a',
            'é' => 'e', 'ê' => 'e', 'í' => 'i',
            'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ú' => 'u', 'ü' => 'u', 'ç' => 'c',
        ]);
        return trim((string) preg_replace('/[^a-z0-9]+/u', ' ', $value));
    }
}
