<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use PDO;
use Throwable;

final class ConversationFlowService
{
    public const GROUPS = [
        'unclassified' => 'Não identificado',
        'interested' => 'Novo interessado',
        'customer' => 'Cliente atual',
        'patient' => 'Paciente atual',
        'family' => 'Familiar',
        'couple' => 'Casal',
        'other' => 'Outro grupo',
    ];


    public const STATUS_LABELS = [
        'lead' => 'Lead / novo contato',
        'customer' => 'Cliente/Paciente atual',
        'inactive' => 'Contato inativo',
    ];

    public const DEMAND_STATUSES = [
        'pending' => 'Ainda não coletada',
        'collected' => 'Demanda coletada',
        'refused' => 'Preferiu não informar',
        'not_required' => 'Não necessária neste fluxo',
    ];

    /**
     * Normaliza a classificação cadastral sem criar novos estados no banco.
     * O grupo mais específico (cliente/paciente) prevalece sobre "Lead" para
     * evitar que um relacionamento existente volte ao fluxo de prospecção.
     *
     * @return array{status:string, group:string}
     */
    public static function normalizeClassification(string $status, string $group): array
    {
        $status = in_array($status, ['lead', 'customer', 'inactive'], true) ? $status : 'lead';
        $group = array_key_exists($group, self::GROUPS) ? $group : 'unclassified';

        if ($status !== 'inactive' && in_array($group, ['customer', 'patient'], true)) {
            $status = 'customer';
        }
        if ($status === 'customer' && in_array($group, ['unclassified', 'interested'], true)) {
            $group = 'customer';
        }

        return ['status' => $status, 'group' => $group];
    }

    /**
     * Traduz classificação + grupo + tags em um perfil operacional único.
     * Esse perfil é consumido pela IA e pelo CRM para diferenciar continuidade
     * de cliente/paciente de uma conversa realmente nova.
     *
     * @return array{key:string,label:string,description:string,ai_instruction:string,is_existing_customer:bool,is_new_lead:bool,should_create_commercial_lead:bool}
     */
    public function relationshipProfile(array $contact): array
    {
        $status = trim((string) ($contact['status'] ?? $contact['contact_status'] ?? ''));
        $group = $this->resolveGroup($contact);
        $tags = $this->tags($contact['tags_json'] ?? null);
        $existing = $this->isExistingCustomer($status, $group, $tags);

        if ($status === 'inactive') {
            return [
                'key' => 'inactive',
                'label' => 'Contato inativo',
                'description' => 'Não presumir vínculo ativo. Se a pessoa retornar, entender primeiro o pedido atual e tratar como reativação quando fizer sentido.',
                'ai_instruction' => 'O contato está inativo. Não o trate como cliente/paciente atual nem como novo lead automaticamente; entenda o pedido atual e confirme apenas o contexto necessário para uma eventual reativação.',
                'is_existing_customer' => false,
                'is_new_lead' => false,
                'should_create_commercial_lead' => false,
            ];
        }

        if ($group === 'patient') {
            return [
                'key' => 'patient',
                'label' => 'Paciente atual',
                'description' => 'Continuidade do atendimento: usar cadastro e histórico e não reiniciar a triagem de um novo lead.',
                'ai_instruction' => 'Trate como paciente atual. Priorize continuidade, dúvidas, acompanhamento e agenda; não faça qualificação comercial de novo lead e não peça novamente dados ou motivo já conhecidos.',
                'is_existing_customer' => true,
                'is_new_lead' => false,
                'should_create_commercial_lead' => false,
            ];
        }

        if ($existing || $group === 'customer') {
            return [
                'key' => 'customer',
                'label' => 'Cliente atual',
                'description' => 'Relacionamento já existente: resolver a necessidade atual sem reiniciar a prospecção.',
                'ai_instruction' => 'Trate como cliente atual. Use cadastro e histórico, responda ao pedido corrente e não reinicie roteiro de captação, descoberta ou qualificação de novo lead.',
                'is_existing_customer' => true,
                'is_new_lead' => false,
                'should_create_commercial_lead' => false,
            ];
        }

        if ($group === 'family') {
            return [
                'key' => 'family',
                'label' => 'Familiar / responsável',
                'description' => 'Atendimento relacionado a outra pessoa. Confirmar para quem é a solicitação apenas quando isso for necessário.',
                'ai_instruction' => 'O contato é familiar ou responsável. Não presuma que ele é o paciente/cliente; identifique para quem é o atendimento somente se isso mudar a resposta ou a próxima ação.',
                'is_existing_customer' => false,
                'is_new_lead' => false,
                'should_create_commercial_lead' => true,
            ];
        }

        if ($group === 'couple') {
            return [
                'key' => 'couple',
                'label' => 'Atendimento de casal',
                'description' => 'Contexto compartilhado. Aplicar as regras específicas do grupo antes de oferecer agenda ou próximos passos.',
                'ai_instruction' => 'O contato está em contexto de casal. Preserve esse contexto e siga as regras específicas do grupo; não converta a conversa automaticamente em atendimento individual.',
                'is_existing_customer' => false,
                'is_new_lead' => false,
                'should_create_commercial_lead' => true,
            ];
        }

        if ($group === 'other') {
            return [
                'key' => 'other',
                'label' => 'Outro grupo',
                'description' => 'Há uma segmentação definida pela empresa; usar grupo, tags e observações antes de fazer nova qualificação.',
                'ai_instruction' => 'Existe uma segmentação específica cadastrada. Use grupo, tags e observações como contexto e pergunte somente o que estiver realmente faltando para o pedido atual.',
                'is_existing_customer' => false,
                'is_new_lead' => false,
                'should_create_commercial_lead' => true,
            ];
        }

        if ($group === 'interested' || $status === 'lead') {
            return [
                'key' => 'lead',
                'label' => 'Novo lead / interessado',
                'description' => 'Novo relacionamento: qualificar somente o necessário e conduzir para o próximo passo adequado.',
                'ai_instruction' => 'Trate como novo lead/interessado. Qualifique de forma progressiva, sem repetir dados já informados, e faça somente as perguntas necessárias para orientar o próximo passo.',
                'is_existing_customer' => false,
                'is_new_lead' => true,
                'should_create_commercial_lead' => true,
            ];
        }

        return [
            'key' => 'unclassified',
            'label' => 'Relacionamento não identificado',
            'description' => 'Ainda não há contexto suficiente. Não assumir que é lead, cliente ou paciente sem evidência.',
            'ai_instruction' => 'O relacionamento ainda não está identificado. Não presuma que a pessoa é novo lead, cliente ou paciente; faça no máximo a pergunta mínima necessária quando essa distinção realmente mudar o atendimento.',
            'is_existing_customer' => false,
            'is_new_lead' => false,
            'should_create_commercial_lead' => true,
        ];
    }

    public const STAGES = [
        'identifying_contact' => 'Identificando o contato',
        'understanding_demand' => 'Entendendo a demanda',
        'collecting_demand' => 'Aguardando a demanda',
        'ready_for_scheduling' => 'Pronto para pré-agendamento',
        'qualified' => 'Contexto identificado',
        'scheduling' => 'Coletando data e horário',
        'awaiting_approval' => 'Aguardando aprovação',
        'human_handoff' => 'Encaminhado para atendimento humano',
        'completed' => 'Atendimento concluído',
    ];

    public function ingestIncoming(PDO $pdo, array $instance, int $contactId, int $conversationId, string $content): array
    {
        $tenantId = (int) ($instance['tenant_id'] ?? 0);
        if ($tenantId < 1 || $contactId < 1 || $conversationId < 1) {
            return [];
        }

        $contact = $this->contact($pdo, $tenantId, $contactId);
        if (!$contact) {
            return [];
        }

        $state = $this->state($pdo, $tenantId, $conversationId, $contactId);
        $group = $this->resolveGroup($contact);
        $contactStatus = (string) ($contact['status'] ?? '');
        $contactTags = $this->tags($contact['tags_json'] ?? null);
        $relationship = $this->relationshipProfile($contact);
        $existingPatient = ($relationship['key'] ?? '') === 'patient';
        $existingCustomer = !empty($relationship['is_existing_customer']);
        $text = $this->normalize($content);
        $intent = $this->intent($text);
        if ($intent === 'conversation'
            && in_array((string) ($state['last_intent'] ?? ''), ['schedule', 'reschedule'], true)
            && in_array((string) ($state['stage'] ?? ''), ['scheduling', 'awaiting_approval'], true)
            && $this->looksLikeSchedulingPreference($text)) {
            $intent = 'schedule';
        }
        $demandStatus = (string) ($state['demand_status'] ?? 'pending');
        $demandSummary = trim((string) ($state['demand_summary'] ?? ''));

        // Cliente/paciente já identificado não deve voltar para a triagem de novo interessado.
        // Se ainda não existe uma demanda registrada, ela deixa de ser pré-requisito para agenda.
        if ($existingCustomer && $demandStatus === 'pending') {
            $demandStatus = 'not_required';
            $demandSummary = $demandSummary !== ''
                ? $demandSummary
                : 'Contato já identificado como cliente/paciente; nova triagem de demanda dispensada.';
        }

        if ($this->isDemandRefusal($text)) {
            $demandStatus = 'refused';
            $demandSummary = 'O contato preferiu não informar a demanda neste momento.';
        } else {
            $candidate = $this->demandCandidate($content, $text);
            if ($candidate !== '') {
                $demandStatus = 'collected';
                $demandSummary = $candidate;
            }
        }

        $stage = $this->stageFor($intent, $demandStatus, $existingPatient);
        $metadata = [
            'contact_group' => $group,
            'contact_status' => $contactStatus,
            'contact_status_label' => self::STATUS_LABELS[$contactStatus] ?? ($contactStatus !== '' ? $contactStatus : 'Não informado'),
            'tags' => $contactTags,
            'is_existing_customer' => $existingCustomer,
            'relationship_key' => (string) ($relationship['key'] ?? 'unclassified'),
            'relationship_label' => (string) ($relationship['label'] ?? 'Relacionamento não identificado'),
            'last_message_preview' => mb_substr(trim($content), 0, 300),
        ];

        $statement = $pdo->prepare(
            'INSERT INTO conversation_flow_states
                (tenant_id, conversation_id, contact_id, stage, demand_status, demand_summary,
                 is_existing_patient, last_intent, source, metadata_json)
             VALUES
                (:tenant_id, :conversation_id, :contact_id, :stage, :demand_status, :demand_summary,
                 :is_existing_patient, :last_intent, "platform", :metadata_json)
             ON DUPLICATE KEY UPDATE
                contact_id = VALUES(contact_id),
                stage = VALUES(stage),
                demand_status = VALUES(demand_status),
                demand_summary = VALUES(demand_summary),
                is_existing_patient = VALUES(is_existing_patient),
                last_intent = VALUES(last_intent),
                source = "platform",
                metadata_json = VALUES(metadata_json),
                updated_at = CURRENT_TIMESTAMP'
        );
        $statement->execute([
            'tenant_id' => $tenantId,
            'conversation_id' => $conversationId,
            'contact_id' => $contactId,
            'stage' => $stage,
            'demand_status' => $demandStatus,
            'demand_summary' => $demandSummary !== '' ? mb_substr($demandSummary, 0, 3000) : null,
            'is_existing_patient' => $existingPatient ? 1 : 0,
            'last_intent' => $intent,
            'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        return $this->context($pdo, $tenantId, $conversationId, $contactId);
    }

    public function schedulingDecision(PDO $pdo, array $instance, int $contactId, int $conversationId, string $content, array $flow = []): array
    {
        $tenantId = (int) ($instance['tenant_id'] ?? 0);
        if ($flow === []) {
            $flow = $this->ingestIncoming($pdo, $instance, $contactId, $conversationId, $content);
        }

        $group = (string) ($flow['contact_group'] ?? 'unclassified');
        $rule = $this->ruleForInstance($pdo, $tenantId, (int) ($instance['id'] ?? 0), $group, $conversationId);
        $demandStatus = (string) ($flow['demand_status'] ?? 'pending');
        $isReschedule = $this->isReschedule($this->normalize($content));

        if (empty($rule['allow_pre_schedule'])) {
            return [
                'allowed' => false,
                'code' => 'group_pre_schedule_blocked',
                'message' => 'O grupo deste contato não permite pré-agendamento automático.',
                'flow' => $flow,
                'rule' => $rule,
            ];
        }

        // A classificação cadastral é fonte de verdade: cliente/paciente existente não precisa
        // repetir motivo/queixa para simplesmente consultar, marcar ou remarcar horário.
        if (!empty($flow['is_existing_customer']) && $demandStatus === 'pending') {
            $this->markDemandNotRequired($pdo, $tenantId, $conversationId, 'Contato já identificado como cliente/paciente; demanda não exigida para agenda.');
            $flow = $this->context($pdo, $tenantId, $conversationId, $contactId);
            return [
                'allowed' => true,
                'code' => 'existing_customer_demand_not_required',
                'message' => null,
                'flow' => $flow,
                'rule' => array_merge($rule, ['require_demand_before_pre_schedule' => false]),
            ];
        }

        if (in_array($demandStatus, ['collected', 'refused', 'not_required'], true)) {
            return ['allowed' => true, 'code' => 'ready', 'message' => null, 'flow' => $flow, 'rule' => $rule];
        }

        if ($group === 'patient' && $isReschedule && !empty($rule['allow_reschedule_without_demand'])) {
            $this->markDemandNotRequired($pdo, $tenantId, $conversationId, 'Paciente atual solicitou remarcação.');
            $flow = $this->context($pdo, $tenantId, $conversationId, $contactId);
            return ['allowed' => true, 'code' => 'patient_reschedule', 'message' => null, 'flow' => $flow, 'rule' => $rule];
        }

        if (empty($rule['require_demand_before_pre_schedule'])) {
            return ['allowed' => true, 'code' => 'demand_not_required_by_rule', 'message' => null, 'flow' => $flow, 'rule' => $rule];
        }

        $this->setStage($pdo, $tenantId, $conversationId, 'collecting_demand', 'agenda_intent_without_demand');
        $flow = $this->context($pdo, $tenantId, $conversationId, $contactId);

        return [
            'allowed' => false,
            'code' => 'demand_required',
            'message' => 'A plataforma aguardará a demanda ou a recusa em informá-la antes de criar o pré-agendamento.',
            'flow' => $flow,
            'rule' => $rule,
        ];
    }

    public function context(PDO $pdo, int $tenantId, int $conversationId, int $contactId = 0): array
    {
        $statement = $pdo->prepare(
            'SELECT fs.*, ct.status AS contact_status,
                    COALESCE(NULLIF(ct.contact_group, ""), "unclassified") AS contact_group,
                    ct.tags_json
             FROM conversations c
             INNER JOIN contacts ct ON ct.id = c.contact_id AND ct.tenant_id = c.tenant_id
             LEFT JOIN conversation_flow_states fs ON fs.conversation_id = c.id AND fs.tenant_id = c.tenant_id
             WHERE c.id = :conversation_id AND c.tenant_id = :tenant_id
             LIMIT 1'
        );
        $statement->execute(['conversation_id' => $conversationId, 'tenant_id' => $tenantId]);
        $row = $statement->fetch(PDO::FETCH_ASSOC) ?: [];
        if ($row === []) {
            return [];
        }

        $group = $this->resolveGroup($row);
        $relationship = $this->relationshipProfile($row);
        return [
            'stage' => (string) ($row['stage'] ?? 'identifying_contact'),
            'demand_status' => (string) ($row['demand_status'] ?? 'pending'),
            'demand_summary' => trim((string) ($row['demand_summary'] ?? '')),
            'is_existing_patient' => $group === 'patient' || (int) ($row['is_existing_patient'] ?? 0) === 1,
            'last_intent' => (string) ($row['last_intent'] ?? ''),
            'contact_group' => $group,
            'contact_status' => (string) ($row['contact_status'] ?? ''),
            'contact_status_label' => self::STATUS_LABELS[(string) ($row['contact_status'] ?? '')] ?? ((string) ($row['contact_status'] ?? '') !== '' ? (string) $row['contact_status'] : 'Não informado'),
            'tags' => $this->tags($row['tags_json'] ?? null),
            'is_existing_customer' => !empty($relationship['is_existing_customer']),
            'relationship_key' => (string) ($relationship['key'] ?? 'unclassified'),
            'relationship_label' => (string) ($relationship['label'] ?? 'Relacionamento não identificado'),
            'relationship_description' => (string) ($relationship['description'] ?? ''),
            'stage_label' => self::STAGES[(string) ($row['stage'] ?? '')] ?? 'Em atendimento',
            'demand_status_label' => self::DEMAND_STATUSES[(string) ($row['demand_status'] ?? '')] ?? 'Ainda não coletada',
            'contact_group_label' => self::GROUPS[$group] ?? 'Outro grupo',
        ];
    }

    public function updateManual(PDO $pdo, int $tenantId, int $conversationId, int $contactId, array $data): void
    {
        $group = (string) ($data['contact_group'] ?? 'unclassified');
        if (!array_key_exists($group, self::GROUPS)) {
            $group = 'unclassified';
        }
        $stage = (string) ($data['flow_stage'] ?? 'identifying_contact');
        if (!array_key_exists($stage, self::STAGES)) {
            $stage = 'identifying_contact';
        }
        $demandStatus = (string) ($data['demand_status'] ?? 'pending');
        if (!array_key_exists($demandStatus, self::DEMAND_STATUSES)) {
            $demandStatus = 'pending';
        }
        $summary = trim((string) ($data['demand_summary'] ?? ''));

        $pdo->prepare(
            'UPDATE contacts SET contact_group = :contact_group WHERE id = :contact_id AND tenant_id = :tenant_id'
        )->execute(['contact_group' => $group, 'contact_id' => $contactId, 'tenant_id' => $tenantId]);

        $pdo->prepare(
            'INSERT INTO conversation_flow_states
                (tenant_id, conversation_id, contact_id, stage, demand_status, demand_summary,
                 is_existing_patient, source)
             VALUES
                (:tenant_id, :conversation_id, :contact_id, :stage, :demand_status, :demand_summary,
                 :is_existing_patient, "manual")
             ON DUPLICATE KEY UPDATE
                contact_id = VALUES(contact_id),
                stage = VALUES(stage),
                demand_status = VALUES(demand_status),
                demand_summary = VALUES(demand_summary),
                is_existing_patient = VALUES(is_existing_patient),
                source = "manual",
                updated_at = CURRENT_TIMESTAMP'
        )->execute([
            'tenant_id' => $tenantId,
            'conversation_id' => $conversationId,
            'contact_id' => $contactId,
            'stage' => $stage,
            'demand_status' => $demandStatus,
            'demand_summary' => $summary !== '' ? mb_substr($summary, 0, 3000) : null,
            'is_existing_patient' => $group === 'patient' ? 1 : 0,
        ]);
    }

    public function ruleForAgent(PDO $pdo, int $tenantId, int $agentId, string $group): array
    {
        $defaults = $this->defaultRule($group);
        if ($agentId < 1) {
            return $defaults;
        }
        try {
            $statement = $pdo->prepare(
                'SELECT allow_pre_schedule, require_demand_before_pre_schedule,
                        allow_reschedule_without_demand, instructions
                 FROM ai_agent_group_rules
                 WHERE tenant_id = :tenant_id AND agent_id = :agent_id AND contact_group = :contact_group
                 LIMIT 1'
            );
            $statement->execute([
                'tenant_id' => $tenantId,
                'agent_id' => $agentId,
                'contact_group' => $group,
            ]);
            $row = $statement->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return $defaults;
            }
            return [
                'allow_pre_schedule' => (int) $row['allow_pre_schedule'] === 1,
                'require_demand_before_pre_schedule' => (int) $row['require_demand_before_pre_schedule'] === 1,
                'allow_reschedule_without_demand' => (int) $row['allow_reschedule_without_demand'] === 1,
                'instructions' => trim((string) ($row['instructions'] ?? '')),
            ];
        } catch (Throwable) {
            return $defaults;
        }
    }

    public function saveGroupRules(PDO $pdo, int $tenantId, int $agentId, array $postedRules): void
    {
        $statement = $pdo->prepare(
            'INSERT INTO ai_agent_group_rules
                (tenant_id, agent_id, contact_group, allow_pre_schedule,
                 require_demand_before_pre_schedule, allow_reschedule_without_demand, instructions)
             VALUES
                (:tenant_id, :agent_id, :contact_group, :allow_pre_schedule,
                 :require_demand, :allow_reschedule, :instructions)
             ON DUPLICATE KEY UPDATE
                allow_pre_schedule = VALUES(allow_pre_schedule),
                require_demand_before_pre_schedule = VALUES(require_demand_before_pre_schedule),
                allow_reschedule_without_demand = VALUES(allow_reschedule_without_demand),
                instructions = VALUES(instructions),
                updated_at = CURRENT_TIMESTAMP'
        );

        foreach (self::GROUPS as $group => $_label) {
            $row = is_array($postedRules[$group] ?? null) ? $postedRules[$group] : [];
            $defaults = $this->defaultRule($group);
            $statement->execute([
                'tenant_id' => $tenantId,
                'agent_id' => $agentId,
                'contact_group' => $group,
                'allow_pre_schedule' => array_key_exists('allow_pre_schedule', $row) ? 1 : 0,
                // Cliente e paciente já conhecidos nunca devem voltar à triagem de demanda
                // por causa de uma configuração antiga ou de um checkbox enviado pela interface.
                'require_demand' => in_array($group, ['customer', 'patient'], true)
                    ? 0
                    : (array_key_exists('require_demand_before_pre_schedule', $row) ? 1 : 0),
                'allow_reschedule' => array_key_exists('allow_reschedule_without_demand', $row) ? 1 : 0,
                'instructions' => trim((string) ($row['instructions'] ?? '')) ?: ($defaults['instructions'] ?: null),
            ]);
        }
    }

    public function rulesForAgents(PDO $pdo, int $tenantId, array $agentIds): array
    {
        $agentIds = array_values(array_filter(array_map('intval', $agentIds), static fn (int $id): bool => $id > 0));
        if ($agentIds === []) {
            return [];
        }
        try {
            $placeholders = implode(',', array_fill(0, count($agentIds), '?'));
            $statement = $pdo->prepare(
                'SELECT * FROM ai_agent_group_rules
                 WHERE tenant_id = ? AND agent_id IN (' . $placeholders . ')'
            );
            $statement->execute(array_merge([$tenantId], $agentIds));
            $result = [];
            foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $result[(int) $row['agent_id']][(string) $row['contact_group']] = $row;
            }
            return $result;
        } catch (Throwable) {
            return [];
        }
    }

    private function ruleForInstance(PDO $pdo, int $tenantId, int $instanceId, string $group, int $conversationId = 0): array
    {
        $agentId = 0;
        try {
            if ($conversationId > 0) {
                $pinned = $pdo->prepare('SELECT ai_agent_id FROM conversations WHERE id = :conversation_id AND tenant_id = :tenant_id LIMIT 1');
                $pinned->execute(['conversation_id' => $conversationId, 'tenant_id' => $tenantId]);
                $agentId = (int) ($pinned->fetchColumn() ?: 0);
            }
        } catch (Throwable) {
            $agentId = 0;
        }

        if ($agentId < 1) {
            try {
                $bindings = (new AgentRoutingService())->agentsForInstance($pdo, $tenantId, $instanceId, true);
                foreach ($bindings as $binding) {
                    if ((int) ($binding['is_primary'] ?? 0) === 1) {
                        $agentId = (int) ($binding['agent_id'] ?? 0);
                        break;
                    }
                }
                if ($agentId < 1 && $bindings !== []) {
                    $agentId = (int) ($bindings[0]['agent_id'] ?? 0);
                }
            } catch (Throwable) {
                $agentId = 0;
            }
        }
        return $this->ruleForAgent($pdo, $tenantId, $agentId, $group);
    }

    private function defaultRule(string $group): array
    {
        return match ($group) {
            'customer' => [
                'allow_pre_schedule' => true,
                'require_demand_before_pre_schedule' => false,
                'allow_reschedule_without_demand' => true,
                'instructions' => 'Cliente atual: use cadastro e histórico existentes e não reinicie a triagem como novo interessado. Pergunte somente o que for necessário para o pedido atual.',
            ],
            'patient' => [
                'allow_pre_schedule' => true,
                'require_demand_before_pre_schedule' => false,
                'allow_reschedule_without_demand' => true,
                'instructions' => 'Paciente atual: trate como relacionamento existente. Não reinicie triagem nem peça novamente motivo/queixa como condição para consultar, marcar ou remarcar horário.',
            ],
            'family' => [
                'allow_pre_schedule' => false,
                'require_demand_before_pre_schedule' => true,
                'allow_reschedule_without_demand' => false,
                'instructions' => 'Familiar: siga as regras da empresa antes de oferecer atendimento ou agenda.',
            ],
            'couple' => [
                'allow_pre_schedule' => false,
                'require_demand_before_pre_schedule' => true,
                'allow_reschedule_without_demand' => false,
                'instructions' => 'Casal: não abra pré-agendamento automático quando a empresa atende somente individualmente.',
            ],
            default => [
                'allow_pre_schedule' => true,
                'require_demand_before_pre_schedule' => true,
                'allow_reschedule_without_demand' => false,
                'instructions' => '',
            ],
        };
    }

    public function refreshContactContext(PDO $pdo, int $tenantId, int $contactId): void
    {
        try {
            $contact = $this->contact($pdo, $tenantId, $contactId);
            if (!$contact) {
                return;
            }
            $group = $this->resolveGroup($contact);
            $status = (string) ($contact['status'] ?? '');
            $tags = $this->tags($contact['tags_json'] ?? null);
            $relationship = $this->relationshipProfile($contact);

            $statement = $pdo->prepare(
                'SELECT id, metadata_json
                 FROM conversation_flow_states
                 WHERE tenant_id = :tenant_id AND contact_id = :contact_id'
            );
            $statement->execute(['tenant_id' => $tenantId, 'contact_id' => $contactId]);
            $update = $pdo->prepare(
                'UPDATE conversation_flow_states
                 SET is_existing_patient = :is_existing_patient,
                     demand_summary = CASE
                         WHEN :is_existing_customer_summary = 1 AND demand_status = "pending" AND (demand_summary IS NULL OR demand_summary = "")
                             THEN "Contato já identificado como cliente/paciente; nova triagem de demanda dispensada."
                         ELSE demand_summary
                     END,
                     stage = CASE
                         WHEN :is_existing_customer_stage = 1
                              AND demand_status = "pending"
                              AND stage IN ("identifying_contact", "understanding_demand", "collecting_demand")
                             THEN "qualified"
                         ELSE stage
                     END,
                     demand_status = CASE
                         WHEN :is_existing_customer = 1 AND demand_status = "pending" THEN "not_required"
                         ELSE demand_status
                     END,
                     metadata_json = :metadata_json,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = :id'
            );

            foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $metadata = json_decode((string) ($row['metadata_json'] ?? ''), true);
                if (!is_array($metadata)) {
                    $metadata = [];
                }
                $metadata['contact_group'] = $group;
                $metadata['contact_status'] = $status;
                $metadata['contact_status_label'] = self::STATUS_LABELS[$status] ?? ($status !== '' ? $status : 'Não informado');
                $metadata['tags'] = $tags;
                $metadata['is_existing_customer'] = !empty($relationship['is_existing_customer']);
                $metadata['relationship_key'] = (string) ($relationship['key'] ?? 'unclassified');
                $metadata['relationship_label'] = (string) ($relationship['label'] ?? 'Relacionamento não identificado');
                $isExistingCustomer = !empty($metadata['is_existing_customer']) ? 1 : 0;

                $update->execute([
                    'is_existing_patient' => $group === 'patient' ? 1 : 0,
                    'is_existing_customer' => $isExistingCustomer,
                    'is_existing_customer_summary' => $isExistingCustomer,
                    'is_existing_customer_stage' => $isExistingCustomer,
                    'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'id' => (int) $row['id'],
                ]);
            }
        } catch (Throwable) {
            // A atualização do contato não pode falhar por ausência de tabelas antigas.
        }
    }

    private function contact(PDO $pdo, int $tenantId, int $contactId): ?array
    {
        $statement = $pdo->prepare(
            'SELECT id, tenant_id, status, contact_group, tags_json, notes
             FROM contacts WHERE id = :id AND tenant_id = :tenant_id LIMIT 1'
        );
        $statement->execute(['id' => $contactId, 'tenant_id' => $tenantId]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    private function state(PDO $pdo, int $tenantId, int $conversationId, int $contactId): array
    {
        try {
            $statement = $pdo->prepare(
                'SELECT * FROM conversation_flow_states
                 WHERE tenant_id = :tenant_id AND conversation_id = :conversation_id LIMIT 1'
            );
            $statement->execute(['tenant_id' => $tenantId, 'conversation_id' => $conversationId]);
            return $statement->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable) {
            return [];
        }
    }

    private function resolveGroup(array $contact): string
    {
        $explicit = trim((string) ($contact['contact_group'] ?? ''));
        $status = trim((string) ($contact['status'] ?? $contact['contact_status'] ?? ''));
        $tags = array_map([$this, 'normalize'], $this->tags($contact['tags_json'] ?? null));
        $taggedCustomer = false;

        foreach ($tags as $tag) {
            if (in_array($tag, ['cliente', 'customer', 'client'], true)) {
                $taggedCustomer = true;
                break;
            }
        }

        // Classificação de cliente é fonte de verdade quando o grupo ainda está como novo interessado.
        if (($status === 'customer' || $taggedCustomer)
            && in_array($explicit, ['', 'unclassified', 'interested', 'customer'], true)) {
            return 'customer';
        }

        if ($explicit !== '' && $explicit !== 'unclassified' && array_key_exists($explicit, self::GROUPS)) {
            return $explicit;
        }
        foreach ($tags as $tag) {
            if (str_contains($tag, 'paciente')) return 'patient';
            if (str_contains($tag, 'interessad') || $tag === 'lead') return 'interested';
            if (str_contains($tag, 'familiar') || str_contains($tag, 'familia')) return 'family';
            if (str_contains($tag, 'casal')) return 'couple';
        }
        return array_key_exists($explicit, self::GROUPS) ? $explicit : 'unclassified';
    }

    /** @param array<int, string> $tags */
    private function isExistingCustomer(string $status, string $group, array $tags): bool
    {
        if ($status === 'inactive') {
            return false;
        }
        if ($status === 'customer' || in_array($group, ['customer', 'patient'], true)) {
            return true;
        }
        foreach ($tags as $tag) {
            $normalized = $this->normalize($tag);
            if (in_array($normalized, ['cliente', 'customer', 'client', 'paciente', 'paciente atual'], true)) {
                return true;
            }
        }
        return false;
    }

    private function tags(mixed $raw): array
    {
        if (is_array($raw)) return array_values(array_filter(array_map('strval', $raw)));
        $decoded = json_decode((string) $raw, true);
        return is_array($decoded) ? array_values(array_filter(array_map('strval', $decoded))) : [];
    }

    private function stageFor(string $intent, string $demandStatus, bool $existingPatient): string
    {
        if ($intent === 'human_handoff') {
            return 'human_handoff';
        }
        if (in_array($demandStatus, ['collected', 'refused', 'not_required'], true)) {
            return in_array($intent, ['schedule', 'reschedule'], true) ? 'scheduling' : 'qualified';
        }
        if (in_array($intent, ['schedule', 'reschedule'], true)) return 'collecting_demand';
        return 'understanding_demand';
    }

    private function intent(string $text): string
    {
        if ($this->isReschedule($text)) return 'reschedule';

        $asksOpeningHours = (bool) preg_match(
            '/\b(horario|horarios)\s+de\s+(atendimento|funcionamento|abertura|fechamento)\b|\b(qual|quais|que)\b.{0,20}\b(horario|horarios)\b.{0,20}\b(atendem|atendimento|funcionam|funcionamento)\b|\bque horas\b.{0,15}\b(abre|fecha|funciona|atende)\b/u',
            $text
        );
        $explicitSchedule = (bool) preg_match(
            '/\b(agendar|reagendar|desmarcar|encaixe)\b|\bmarcar\b.{0,30}\b(consulta|sessao|reuniao|horario)\b|\b(tem|ha|ver|consultar|confirma|confirmar|qual|quais)\b.{0,25}\b(horario|horarios|disponibilidade)\b|\b(quero|gostaria|preciso)\b.{0,20}\b(horario|horarios|agendar|marcar)\b|\b(horario|horarios)\s+(disponivel|disponiveis)\b/u',
            $text
        );
        if ($explicitSchedule && !$asksOpeningHours) return 'schedule';
        if ((bool) preg_match('/\b(humano|atendente|pessoa|equipe|suporte)\b/u', $text)) return 'human_handoff';
        return 'conversation';
    }

    private function looksLikeSchedulingPreference(string $text): bool
    {
        return (bool) preg_match(
            '/\b(hoje|amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|manha|tarde|noite)\b|\b\d{1,2}(?::\d{2})?\s*h?\b|\b\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?\b/u',
            $text
        );
    }

    private function isReschedule(string $text): bool
    {
        return (bool) preg_match('/\b(remarcar|remarcacao|reagendar|trocar o horario|mudar o horario|alterar o horario|outro horario|desmarcar e marcar)\b/u', $text);
    }

    private function isDemandRefusal(string $text): bool
    {
        return (bool) preg_match('/\b(prefiro nao informar|nao quero falar|nao gostaria de explicar|nao me sinto confortavel|quero falar diretamente|prefiro conversar na consulta)\b/u', $text);
    }

    private function demandCandidate(string $original, string $text): string
    {
        if (mb_strlen(trim($original)) < 12) return '';

        $signals = '/\b(ansiedade|depressao|panico|insonia|luto|relacionamento|autoestima|estresse|medo|trauma|crise|angustia|tristeza|terapia|acompanhamento|ajuda|preciso|porque|motivo|queixa|dificuldade|problema|sofrendo|sinto|estou com|tenho tido)\b/u';
        if (preg_match($signals, $text)) {
            return mb_substr(trim($original), 0, 1200);
        }

        // 36.27.17: em empresas comerciais, a própria finalidade explícita do
        // agendamento pode ser a demanda. Ex.: “agendar uma demonstração” ou
        // “agendar uma reunião”. Mantemos a triagem para pedidos genéricos como
        // “quero agendar” e para “agendar uma consulta”, preservando os fluxos
        // clínicos que exigem motivo/queixa quando configurados assim.
        if (in_array($this->intent($text), ['schedule', 'reschedule'], true)) {
            $purpose = $this->schedulingPurposeCandidate($text);
            if ($purpose !== '') {
                return mb_substr(trim($original), 0, 1200);
            }
        }

        if ($this->isOnlySchedulingMessage($text)) return '';
        return '';
    }

    private function schedulingPurposeCandidate(string $text): string
    {
        $clean = preg_replace(
            '/\b(agenda|agendar|reagendar|remarcar|desmarcar|marcar|encaixe|consulta|sessao|atendimento|horario|horarios|disponibilidade|online|presencial|telefone|hoje|amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|manha|tarde|noite|quero|gostaria|preciso|pode|posso|como|qual|quais|tem|ha|ver|consultar|confirma|confirmar|um|uma|o|a|os|as|de|do|da|dos|das|para|por|favor|me|eu)\b/u',
            ' ',
            $text
        ) ?? $text;
        $clean = preg_replace('/\b\d{1,2}(?::\d{2})?\s*h?\b|\b\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?\b/u', ' ', $clean) ?? $clean;
        $clean = preg_replace('/[^a-z0-9 ]+/u', ' ', $clean) ?? $clean;
        $tokens = preg_split('/\s+/u', trim($clean)) ?: [];
        $tokens = array_values(array_filter($tokens, static fn (string $token): bool => mb_strlen($token) >= 6));
        return $tokens !== [] ? implode(' ', $tokens) : '';
    }

    private function isOnlySchedulingMessage(string $text): bool
    {
        $without = preg_replace('/\b(agenda|agendar|marcar|horario|hora|disponibilidade|consulta|sessao|online|presencial|hoje|amanha|segunda|terca|quarta|quinta|sexta|sabado|domingo|manha|tarde|noite|as|às|de|para|quero|gostaria|pode|tem|um|uma|o|a|e|por|favor)\b/u', ' ', $text) ?? $text;
        $without = preg_replace('/\b\d{1,2}([:\/\-]\d{1,4})*\b/u', ' ', $without) ?? $without;
        $without = preg_replace('/\s+/u', ' ', trim($without)) ?? trim($without);
        return mb_strlen($without) < 10;
    }

    private function markDemandNotRequired(PDO $pdo, int $tenantId, int $conversationId, string $summary): void
    {
        $pdo->prepare(
            'UPDATE conversation_flow_states
             SET demand_status = "not_required", demand_summary = :summary,
                 stage = CASE WHEN last_intent IN ("schedule", "reschedule") THEN "scheduling" ELSE "qualified" END,
                 updated_at = CURRENT_TIMESTAMP
             WHERE tenant_id = :tenant_id AND conversation_id = :conversation_id'
        )->execute(['summary' => $summary, 'tenant_id' => $tenantId, 'conversation_id' => $conversationId]);
    }

    private function setStage(PDO $pdo, int $tenantId, int $conversationId, string $stage, string $intent): void
    {
        $pdo->prepare(
            'UPDATE conversation_flow_states
             SET stage = :stage, last_intent = :intent, updated_at = CURRENT_TIMESTAMP
             WHERE tenant_id = :tenant_id AND conversation_id = :conversation_id'
        )->execute(['stage' => $stage, 'intent' => $intent, 'tenant_id' => $tenantId, 'conversation_id' => $conversationId]);
    }

    private function normalize(string $text): string
    {
        $text = mb_strtolower(trim($text));
        return strtr($text, [
            'á'=>'a','à'=>'a','ã'=>'a','â'=>'a','ä'=>'a','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
            'í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','ó'=>'o','ò'=>'o','õ'=>'o','ô'=>'o','ö'=>'o',
            'ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c',
        ]);
    }
}
