<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use DateInterval;
use DatePeriod;
use DateTimeImmutable;
use PDO;
use Throwable;

/**
 * Consolida atendimento, responsabilidade, agenda e carteira preferencial por
 * profissional. A base histórica é fornecida pelas migrations 067 e 068.
 */
final class TeamProfessionalReportService
{
    public const VERSION = '36.34.1-sla-operational-policy';

    private const HISTORICAL_CYCLE_SOURCES = ['migration_snapshot', 'migration_069_recovery'];

    private PDO $pdo;
    private TeamMetricsFoundationService $foundation;
    private SlaPolicyService $slaPolicy;
    private array $warnings = [];
    private bool $cutoverLoaded = false;
    private string $cutoverAtUtc = '';

    public function __construct(?PDO $pdo = null)
    {
        $this->pdo = $pdo ?? Database::connection();
        $this->foundation = new TeamMetricsFoundationService($this->pdo);
        $this->slaPolicy = new SlaPolicyService($this->pdo);
    }

    public function build(array $filters): array
    {
        $this->warnings = [];
        $tenantId = (int) ($filters['tenant_id'] ?? 0);
        $scope = $this->foundation->assertMayView($tenantId);
        $readiness = $this->foundation->readiness();
        $selectedUserId = $this->selectedUserId($tenantId, $scope, (int) ($filters['user_id'] ?? 0));
        $operationalOnly = !empty($filters['operational_only']);
        $slaMinutes = max(5, min(1440, (int) ($filters['sla_minutes'] ?? 30)));
        $tenant = $this->row(
            'SELECT t.id, t.name, t.professional_assignment_enabled, t.professional_calendar_enabled,
                    t.lifecycle_status, t.went_live_at,
                    COALESCE(NULLIF(os.business_timezone, ""), NULLIF(cas.timezone, ""), "America/Sao_Paulo") AS timezone
             FROM tenants t
             LEFT JOIN tenant_onboarding_settings os ON os.tenant_id = t.id
             LEFT JOIN tenant_calendar_availability_settings cas ON cas.tenant_id = t.id
             WHERE t.id = :tenant_id LIMIT 1',
            ['tenant_id' => $tenantId]
        );
        $users = $this->users($tenantId, $scope);

        $base = [
            'version' => self::VERSION,
            'scope' => $scope,
            'readiness' => $readiness,
            'tenant' => $tenant,
            'users' => $users,
            'selected_user_id' => $selectedUserId,
            'overview' => $this->emptyOverview(),
            'professionals' => [],
            'dailySeries' => [],
            'recentActivities' => [],
            'responseAudit' => [],
            'dataQuality' => $this->emptyDataQuality(),
            'serviceQuality' => $this->emptyServiceQuality($slaMinutes),
            'departmentPerformance' => [],
            'queue_enabled' => false,
            'responseProvenance' => $this->emptyResponseProvenance($operationalOnly),
            'warnings' => [],
        ];

        if (!$readiness['ready']) {
            $this->warnings[] = 'As migrations históricas até a 071 ainda não estão completas. Aplique o contrato UTC antes de usar este relatório.';
            $base['warnings'] = $this->warnings;
            return $base;
        }

        if ((string) ($tenant['lifecycle_status'] ?? 'onboarding') !== TenantLifecycleService::LIVE) {
            $this->warnings[] = 'Esta empresa não está em produção. SLA e métricas oficiais consideram somente períodos em que o ciclo operacional estava LIVE.';
        }

        $professionals = $this->professionalBase($users, $selectedUserId);
        $date = $this->dateParams($filters, (string) ($tenant['timezone'] ?? 'America/Sao_Paulo'));
        $responseProvenance = $this->responseProvenance($tenantId, $date, $selectedUserId, $operationalOnly);

        $this->mergeRows($professionals, $this->humanMessages($tenantId, $date, $selectedUserId));
        // Legacy smoke contract: firstResponses($tenantId, $date, $selectedUserId, $operationalOnly)
        $this->mergeRows($professionals, $this->firstResponses($tenantId, $date, $selectedUserId, $operationalOnly, $slaMinutes));
        $this->mergeRows($professionals, $this->serviceDurations($tenantId, $date, $selectedUserId, $operationalOnly));
        $this->mergeRows($professionals, $this->currentWaiting($tenantId, $selectedUserId, $slaMinutes));
        $queueEnabled = (new TenantModuleService())->enabled($tenantId, 'queue');
        if ($queueEnabled) {
            $this->mergeRows($professionals, $this->departmentMemberships($tenantId, $selectedUserId));
        }
        $this->mergeRows($professionals, $this->assignmentIncoming($tenantId, $date, $selectedUserId));
        $this->mergeRows($professionals, $this->assignmentOutgoing($tenantId, $date, $selectedUserId));
        $this->mergeRows($professionals, $this->conversationClosures($tenantId, $date, $selectedUserId, $operationalOnly));
        $this->mergeRows($professionals, $this->openConversations($tenantId, $selectedUserId));
        $this->mergeRows($professionals, $this->appointments($tenantId, $date, $selectedUserId));
        $this->mergeRows($professionals, $this->appointmentTransfers($tenantId, $date, $selectedUserId));
        $this->mergeRows($professionals, $this->preferredClients($tenantId, $selectedUserId));

        foreach ($professionals as &$professional) {
            $appointments = (int) ($professional['appointments'] ?? 0);
            $completed = (int) ($professional['appointments_completed'] ?? 0);
            $confirmed = (int) ($professional['appointments_confirmed'] ?? 0);
            $cancelled = (int) ($professional['appointments_cancelled'] ?? 0);
            $noShow = (int) ($professional['appointments_no_show'] ?? 0);
            $finishedBase = $completed + $cancelled + $noShow;
            $professional['appointment_success_rate'] = $appointments > 0
                ? (($completed + $confirmed) / $appointments) * 100
                : 0.0;
            $professional['attendance_rate'] = $finishedBase > 0
                ? ($completed / $finishedBase) * 100
                : 0.0;
            $professional['avg_first_response_seconds'] = (int) round((float) ($professional['avg_first_response_seconds'] ?? 0));
            $professional['avg_service_duration_seconds'] = (int) round((float) ($professional['avg_service_duration_seconds'] ?? 0));
            $professional['avg_current_wait_seconds'] = (int) round((float) ($professional['avg_current_wait_seconds'] ?? 0));
            $professional['max_current_wait_seconds'] = (int) round((float) ($professional['max_current_wait_seconds'] ?? 0));
            $slaMeasured = (int) ($professional['sla_measured'] ?? 0);
            $professional['sla_compliance'] = $slaMeasured > 0
                ? round(((int) ($professional['sla_met'] ?? 0) / $slaMeasured) * 100, 1)
                : 0.0;
            $professional['activity_score'] = (int) ($professional['human_messages'] ?? 0)
                + ((int) ($professional['appointments_completed'] ?? 0) * 3)
                + ((int) ($professional['closed_conversations'] ?? 0) * 2);
        }
        unset($professional);

        uasort($professionals, static function (array $a, array $b): int {
            $score = ((int) ($b['activity_score'] ?? 0)) <=> ((int) ($a['activity_score'] ?? 0));
            return $score !== 0 ? $score : strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
        });

        $professionalRows = array_values($professionals);
        $dataQuality = $this->responseDataQuality($tenantId, $date, $selectedUserId, $operationalOnly);
        $serviceQuality = $this->serviceQuality($tenantId, $date, $selectedUserId, $operationalOnly, $slaMinutes);
        $overview = $this->overview($professionalRows, $scope, $selectedUserId);
        // Use raw cycle aggregates instead of averages of rounded professional rows. Legacy wording: average of rounded professional averages.
        $overview['first_responses'] = (int) ($dataQuality['measured_responses'] ?? 0);
        $overview['avg_first_response_seconds'] = (int) ($dataQuality['avg_response_seconds'] ?? 0);
        $overview['avg_service_duration_seconds'] = (int) ($serviceQuality['avg_service_duration_seconds'] ?? 0);
        $overview['service_cycles_closed'] = (int) ($serviceQuality['closed_cycles'] ?? 0);
        $overview['sla_measured'] = (int) ($serviceQuality['sla_measured'] ?? 0);
        $overview['sla_met'] = (int) ($serviceQuality['sla_met'] ?? 0);
        $overview['sla_breached'] = (int) ($serviceQuality['sla_breached'] ?? 0);
        $overview['sla_compliance'] = (float) ($serviceQuality['sla_compliance'] ?? 0);
        $overview['waiting_now'] = (int) ($serviceQuality['waiting_now'] ?? 0);
        $overview['waiting_over_sla'] = (int) ($serviceQuality['waiting_over_sla'] ?? 0);
        $overview['avg_current_wait_seconds'] = (int) ($serviceQuality['avg_current_wait_seconds'] ?? 0);
        $overview['max_current_wait_seconds'] = (int) ($serviceQuality['max_current_wait_seconds'] ?? 0);
        $overview['sla_target_minutes'] = $slaMinutes;
        $departmentPerformance = $queueEnabled ? $this->departmentPerformance($tenantId, $slaMinutes) : [];
        $dailySeries = $this->dailySeries($tenantId, $filters, $selectedUserId, $operationalOnly);
        $activities = $this->recentActivities($tenantId, $date, $selectedUserId);
        $responseAudit = $this->firstResponseAudit($tenantId, $date, $selectedUserId, 50, $operationalOnly, $slaMinutes);

        return array_merge($base, [
            'overview' => $overview,
            'professionals' => $professionalRows,
            'dailySeries' => $dailySeries,
            'recentActivities' => $activities,
            'responseAudit' => $responseAudit,
            'dataQuality' => $dataQuality,
            'serviceQuality' => $serviceQuality,
            'departmentPerformance' => $departmentPerformance,
            'queue_enabled' => $queueEnabled,
            'responseProvenance' => $responseProvenance,
            'warnings' => array_values(array_unique($this->warnings)),
        ]);
    }

    /**
     * Returns auditable first-response cycles for CSV export. Public identifiers
     * are used so internal numeric IDs never leave the application.
     */
    public function firstResponseExport(array $filters): array
    {
        $this->warnings = [];
        $tenantId = (int) ($filters['tenant_id'] ?? 0);
        $scope = $this->foundation->assertMayView($tenantId);
        $selectedUserId = $this->selectedUserId($tenantId, $scope, (int) ($filters['user_id'] ?? 0));
        $operationalOnly = !empty($filters['operational_only']);
        $slaMinutes = max(5, min(1440, (int) ($filters['sla_minutes'] ?? 30)));
        $timezone = $this->tenantTimezone($tenantId);
        $date = $this->dateParams($filters, $timezone);
        return $this->firstResponseAudit($tenantId, $date, $selectedUserId, 5000, $operationalOnly, $slaMinutes);
    }

    private function selectedUserId(int $tenantId, array $scope, int $requested): int
    {
        if (($scope['mode'] ?? '') === 'own') {
            return (int) ($scope['user_id'] ?? 0);
        }
        if ($requested < 1) {
            return 0;
        }
        $exists = $this->scalar(
            'SELECT COUNT(*) FROM users WHERE id = :user_id AND tenant_id = :tenant_id',
            ['user_id' => $requested, 'tenant_id' => $tenantId]
        );
        return $exists > 0 ? $requested : 0;
    }

    private function users(int $tenantId, array $scope): array
    {
        $params = ['tenant_id' => $tenantId];
        $where = '';
        if (($scope['mode'] ?? '') === 'own') {
            $where = ' AND id = :scope_user_id';
            $params['scope_user_id'] = (int) ($scope['user_id'] ?? 0);
        }
        return $this->rows(
            'SELECT id, name, whatsapp_display_name, whatsapp_role_label, role, status
             FROM users
             WHERE tenant_id = :tenant_id' . $where . '
             ORDER BY status = "active" DESC, name',
            $params
        );
    }

    private function professionalBase(array $users, int $selectedUserId): array
    {
        $result = [];
        foreach ($users as $user) {
            $id = (int) ($user['id'] ?? 0);
            if ($id < 1 || ($selectedUserId > 0 && $id !== $selectedUserId)) {
                continue;
            }
            $result[$id] = [
                'user_id' => $id,
                'name' => (string) ($user['whatsapp_display_name'] ?: $user['name'] ?: 'Usuário'),
                'account_name' => (string) ($user['name'] ?? ''),
                'role_label' => (string) ($user['whatsapp_role_label'] ?: $this->roleLabel((string) ($user['role'] ?? 'client_user'))),
                'role' => (string) ($user['role'] ?? 'client_user'),
                'status' => (string) ($user['status'] ?? 'active'),
                'human_messages' => 0,
                'conversations_replied' => 0,
                'first_responses' => 0,
                'avg_first_response_seconds' => 0,
                'sla_measured' => 0,
                'sla_met' => 0,
                'sla_breached' => 0,
                'sla_compliance' => 0.0,
                'avg_service_duration_seconds' => 0,
                'service_cycles_closed' => 0,
                'waiting_now' => 0,
                'waiting_over_sla' => 0,
                'avg_current_wait_seconds' => 0,
                'max_current_wait_seconds' => 0,
                'department_names' => '',
                'assignments' => 0,
                'assigned_conversations' => 0,
                'transfers_received' => 0,
                'transfers_out' => 0,
                'releases' => 0,
                'closed_conversations' => 0,
                'open_conversations' => 0,
                'appointments' => 0,
                'appointments_scheduled' => 0,
                'appointments_confirmed' => 0,
                'appointments_completed' => 0,
                'appointments_cancelled' => 0,
                'appointments_no_show' => 0,
                'appointments_upcoming' => 0,
                'appointment_transfers_received' => 0,
                'appointment_transfers_out' => 0,
                'preferred_clients' => 0,
            ];
        }
        return $result;
    }

    private function humanMessages(int $tenantId, array $date, int $userId): array
    {
        [$filter, $params] = $this->userFilter('sender_user_id', $userId);
        return $this->rows(
            'SELECT sender_user_id AS user_id,
                    COUNT(*) AS human_messages,
                    COUNT(DISTINCT conversation_id) AS conversations_replied
             FROM conversation_messages
             WHERE tenant_id = :tenant_id
               AND direction = "outgoing"
               AND sender_type = "user"
               AND sender_user_id IS NOT NULL
               AND sent_at BETWEEN :start_at AND :end_at' . $filter . '
             GROUP BY sender_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params
        );
    }

    private function firstResponses(int $tenantId, array $date, int $userId, bool $operationalOnly, int $slaMinutes): array
    {
        $slaMinutes = max(5, min(1440, $slaMinutes));
        $slaSeconds = $slaMinutes * 60;
        [$filter, $params] = $this->userFilter('sc.first_response_user_id', $userId);
        [$reliabilityFilter, $reliabilityParams] = $this->cycleReliabilityFilter('sc', 'first_response_at', $date, $operationalOnly);
        $rows = $this->rows(
            'SELECT sc.first_response_user_id AS user_id, sc.first_incoming_at, sc.first_response_at,
                    sc.sla_target_minutes, sc.sla_warning_percent,
                    sc.sla_count_outside_business_hours, sc.sla_timezone,
                    sc.sla_business_hours_json
             FROM conversation_service_cycles sc
             WHERE sc.tenant_id = :tenant_id
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_user_id IS NOT NULL
               AND sc.first_response_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . $filter . $reliabilityFilter,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params + $reliabilityParams
        );

        $result = [];
        foreach ($rows as $row) {
            $uid = (int) ($row['user_id'] ?? 0);
            if ($uid < 1) {
                continue;
            }
            if (!isset($result[$uid])) {
                $result[$uid] = [
                    'user_id' => $uid,
                    'first_responses' => 0,
                    'sla_measured' => 0,
                    'sla_met' => 0,
                    'sla_breached' => 0,
                    'avg_first_response_seconds' => 0,
                    '_seconds_total' => 0,
                ];
            }
            $policy = $this->slaPolicy->policyForCycle($tenantId, $row);
            $policy['target_minutes'] = $slaMinutes;
            $elapsed = $this->slaPolicy->elapsedSeconds(
                $tenantId,
                (string) ($row['first_incoming_at'] ?? ''),
                (string) ($row['first_response_at'] ?? ''),
                $policy
            );
            $result[$uid]['first_responses']++;
            $result[$uid]['sla_measured']++;
            $result[$uid]['_seconds_total'] += $elapsed;
            if ($elapsed <= $slaSeconds) {
                $result[$uid]['sla_met']++;
            } else {
                $result[$uid]['sla_breached']++;
            }
        }
        foreach ($result as &$item) {
            $count = max(1, (int) $item['first_responses']);
            $item['avg_first_response_seconds'] = (int) round(((int) $item['_seconds_total']) / $count);
            unset($item['_seconds_total']);
        }
        unset($item);
        return array_values($result);
    }

    private function serviceDurations(int $tenantId, array $date, int $userId, bool $operationalOnly): array
    {
        [$filter, $params] = $this->userFilter('sc.closed_by_user_id', $userId);
        [$reliabilityFilter, $reliabilityParams] = $this->cycleReliabilityFilter('sc', 'closed_at', $date, $operationalOnly);
        return $this->rows(
            'SELECT sc.closed_by_user_id AS user_id,
                    COUNT(*) AS service_cycles_closed,
                    AVG(GREATEST(0, TIMESTAMPDIFF(SECOND, sc.opened_at, sc.closed_at))) AS avg_service_duration_seconds
             FROM conversation_service_cycles sc
             WHERE sc.tenant_id = :tenant_id
               AND sc.cycle_status = "closed"
               AND sc.opened_at IS NOT NULL
               AND sc.closed_at IS NOT NULL
               AND sc.closed_by_user_id IS NOT NULL
               AND sc.closed_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.opened_at') . $filter . $reliabilityFilter . '
             GROUP BY sc.closed_by_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params + $reliabilityParams
        );
    }

    private function currentWaiting(int $tenantId, int $userId, int $slaMinutes): array
    {
        $slaMinutes = max(5, min(1440, $slaMinutes));
        $slaSeconds = $slaMinutes * 60;
        [$filter, $params] = $this->userFilter('c.assigned_user_id', $userId);
        $rows = $this->rows(
            'SELECT c.assigned_user_id AS user_id, sc.first_incoming_at,
                    sc.sla_target_minutes, sc.sla_warning_percent,
                    sc.sla_count_outside_business_hours, sc.sla_timezone,
                    sc.sla_business_hours_json
             FROM conversation_service_cycles sc
             INNER JOIN conversations c ON c.id = sc.conversation_id AND c.tenant_id = sc.tenant_id
             WHERE sc.tenant_id = :tenant_id
               AND sc.cycle_status = "active"
               AND c.status <> "closed"
               AND c.assigned_user_id IS NOT NULL
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_at IS NULL
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . '
               AND ' . TenantLifecycleService::currentLiveSql('sc.tenant_id') . $filter,
            ['tenant_id' => $tenantId] + $params
        );

        $result = [];
        $now = gmdate('Y-m-d H:i:s');
        foreach ($rows as $row) {
            $uid = (int) ($row['user_id'] ?? 0);
            if ($uid < 1) {
                continue;
            }
            if (!isset($result[$uid])) {
                $result[$uid] = [
                    'user_id' => $uid,
                    'waiting_now' => 0,
                    'waiting_over_sla' => 0,
                    'avg_current_wait_seconds' => 0,
                    'max_current_wait_seconds' => 0,
                    '_seconds_total' => 0,
                ];
            }
            $policy = $this->slaPolicy->policyForCycle($tenantId, $row);
            $policy['target_minutes'] = $slaMinutes;
            $elapsed = $this->slaPolicy->elapsedSeconds($tenantId, (string) ($row['first_incoming_at'] ?? ''), $now, $policy);
            $result[$uid]['waiting_now']++;
            $result[$uid]['_seconds_total'] += $elapsed;
            $result[$uid]['max_current_wait_seconds'] = max((int) $result[$uid]['max_current_wait_seconds'], $elapsed);
            if ($elapsed > $slaSeconds) {
                $result[$uid]['waiting_over_sla']++;
            }
        }
        foreach ($result as &$item) {
            $count = max(1, (int) $item['waiting_now']);
            $item['avg_current_wait_seconds'] = (int) round(((int) $item['_seconds_total']) / $count);
            unset($item['_seconds_total']);
        }
        unset($item);
        return array_values($result);
    }

    private function departmentMemberships(int $tenantId, int $userId): array
    {
        [$filter, $params] = $this->userFilter('m.user_id', $userId);
        return $this->rows(
            'SELECT m.user_id, GROUP_CONCAT(DISTINCT d.name ORDER BY d.name SEPARATOR ", ") AS department_names
             FROM service_department_members m
             INNER JOIN service_departments d ON d.id = m.department_id AND d.tenant_id = m.tenant_id
             WHERE m.tenant_id = :tenant_id AND d.status = "active"' . $filter . '
             GROUP BY m.user_id',
            ['tenant_id' => $tenantId] + $params
        );
    }

    private function assignmentIncoming(int $tenantId, array $date, int $userId): array
    {
        [$filter, $params] = $this->userFilter('assigned_user_id', $userId);
        return $this->rows(
            'SELECT assigned_user_id AS user_id,
                    SUM(action = "assign") AS assignments,
                    COUNT(DISTINCT conversation_id) AS assigned_conversations,
                    SUM(action = "transfer") AS transfers_received
             FROM conversation_assignment_history
             WHERE tenant_id = :tenant_id
               AND assigned_user_id IS NOT NULL
               AND occurred_at BETWEEN :start_at AND :end_at' . $filter . '
             GROUP BY assigned_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params
        );
    }

    private function assignmentOutgoing(int $tenantId, array $date, int $userId): array
    {
        [$filter, $params] = $this->userFilter('previous_user_id', $userId);
        return $this->rows(
            'SELECT previous_user_id AS user_id,
                    SUM(action = "transfer") AS transfers_out,
                    SUM(action = "release") AS releases
             FROM conversation_assignment_history
             WHERE tenant_id = :tenant_id
               AND previous_user_id IS NOT NULL
               AND occurred_at BETWEEN :start_at AND :end_at' . $filter . '
             GROUP BY previous_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params
        );
    }

    private function conversationClosures(int $tenantId, array $date, int $userId, bool $operationalOnly): array
    {
        [$filter, $params] = $this->userFilter('sc.closed_by_user_id', $userId);
        [$reliabilityFilter, $reliabilityParams] = $this->cycleReliabilityFilter('sc', 'closed_at', $date, $operationalOnly);
        return $this->rows(
            'SELECT sc.closed_by_user_id AS user_id,
                    COUNT(*) AS closed_conversations
             FROM conversation_service_cycles sc
             WHERE sc.tenant_id = :tenant_id
               AND sc.cycle_status = "closed"
               AND sc.closed_by_user_id IS NOT NULL
               AND sc.closed_at BETWEEN :start_at AND :end_at' . $filter . $reliabilityFilter . '
             GROUP BY sc.closed_by_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params + $reliabilityParams
        );
    }

    private function openConversations(int $tenantId, int $userId): array
    {
        [$filter, $params] = $this->userFilter('assigned_user_id', $userId);
        return $this->rows(
            'SELECT assigned_user_id AS user_id, COUNT(*) AS open_conversations
             FROM conversations
             WHERE tenant_id = :tenant_id
               AND status = "open"
               AND assigned_user_id IS NOT NULL' . $filter . '
             GROUP BY assigned_user_id',
            ['tenant_id' => $tenantId] + $params
        );
    }

    private function appointments(int $tenantId, array $date, int $userId): array
    {
        [$filter, $params] = $this->userFilter('owner_user_id', $userId);
        return $this->rows(
            'SELECT owner_user_id AS user_id,
                    COUNT(*) AS appointments,
                    SUM(status IN ("scheduled", "pre_scheduled", "awaiting_approval", "rescheduled")) AS appointments_scheduled,
                    SUM(status = "confirmed") AS appointments_confirmed,
                    SUM(status = "completed") AS appointments_completed,
                    SUM(status IN ("cancelled", "rejected")) AS appointments_cancelled,
                    SUM(status = "no_show") AS appointments_no_show,
                    SUM(starts_at >= :now_local AND status NOT IN ("cancelled", "rejected", "completed", "no_show")) AS appointments_upcoming
             FROM calendar_appointments
             WHERE tenant_id = :tenant_id
               AND owner_user_id IS NOT NULL
               AND starts_at BETWEEN :start_at AND :end_at' . $filter . '
             GROUP BY owner_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['local_start'], 'end_at' => $date['local_end'], 'now_local' => $date['now_local']] + $params
        );
    }

    private function appointmentTransfers(int $tenantId, array $date, int $userId): array
    {
        $rows = [];
        [$inFilter, $inParams] = $this->userFilter('owner_user_id', $userId);
        foreach ($this->rows(
            'SELECT owner_user_id AS user_id, COUNT(*) AS appointment_transfers_received
             FROM calendar_appointment_history
             WHERE tenant_id = :tenant_id
               AND event_type = "owner_changed"
               AND owner_user_id IS NOT NULL
               AND occurred_at BETWEEN :start_at AND :end_at' . $inFilter . '
             GROUP BY owner_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $inParams
        ) as $row) {
            $rows[(int) $row['user_id']] = $row;
        }

        [$outFilter, $outParams] = $this->userFilter('previous_owner_user_id', $userId);
        foreach ($this->rows(
            'SELECT previous_owner_user_id AS user_id, COUNT(*) AS appointment_transfers_out
             FROM calendar_appointment_history
             WHERE tenant_id = :tenant_id
               AND event_type = "owner_changed"
               AND previous_owner_user_id IS NOT NULL
               AND occurred_at BETWEEN :start_at AND :end_at' . $outFilter . '
             GROUP BY previous_owner_user_id',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $outParams
        ) as $row) {
            $id = (int) $row['user_id'];
            $rows[$id] = ($rows[$id] ?? ['user_id' => $id]) + $row;
        }
        return array_values($rows);
    }

    private function preferredClients(int $tenantId, int $userId): array
    {
        [$filter, $params] = $this->userFilter('preferred_user_id', $userId);
        return $this->rows(
            'SELECT preferred_user_id AS user_id, COUNT(*) AS preferred_clients
             FROM contacts
             WHERE tenant_id = :tenant_id
               AND preferred_user_id IS NOT NULL' . $filter . '
             GROUP BY preferred_user_id',
            ['tenant_id' => $tenantId] + $params
        );
    }

    private function overview(array $professionals, array $scope, int $selectedUserId): array
    {
        $overview = $this->emptyOverview();
        $overview['team_members'] = count($professionals);
        foreach ($professionals as $row) {
            foreach ([
                'human_messages', 'conversations_replied', 'first_responses', 'sla_measured', 'sla_met', 'sla_breached', 'service_cycles_closed', 'waiting_now', 'waiting_over_sla', 'assignments',
                'transfers_received', 'transfers_out', 'releases', 'closed_conversations',
                'open_conversations', 'appointments', 'appointments_confirmed',
                'appointments_completed', 'appointments_cancelled', 'appointments_no_show',
                'appointments_upcoming', 'preferred_clients',
            ] as $key) {
                $overview[$key] += (int) ($row[$key] ?? 0);
            }
        }

        $weightedSeconds = 0;
        foreach ($professionals as $row) {
            $weightedSeconds += ((int) ($row['first_responses'] ?? 0)) * ((int) ($row['avg_first_response_seconds'] ?? 0));
        }
        $overview['avg_first_response_seconds'] = $overview['first_responses'] > 0
            ? (int) round($weightedSeconds / $overview['first_responses'])
            : 0;
        $overview['appointment_success_rate'] = $overview['appointments'] > 0
            ? (($overview['appointments_completed'] + $overview['appointments_confirmed']) / $overview['appointments']) * 100
            : 0.0;
        $attendanceBase = $overview['appointments_completed'] + $overview['appointments_cancelled'] + $overview['appointments_no_show'];
        $overview['attendance_rate'] = $attendanceBase > 0
            ? ($overview['appointments_completed'] / $attendanceBase) * 100
            : 0.0;
        $overview['scope_label'] = ($scope['mode'] ?? '') === 'own'
            ? 'Meus indicadores'
            : ($selectedUserId > 0 ? 'Profissional selecionado' : 'Toda a equipe');
        return $overview;
    }

    private function dailySeries(int $tenantId, array $filters, int $userId, bool $operationalOnly): array
    {
        $timezone = $this->tenantTimezone($tenantId);
        $date = $this->dateParams($filters, $timezone);
        $series = [];
        $start = new DateTimeImmutable((string) $filters['start']);
        $end = new DateTimeImmutable((string) $filters['end']);
        foreach (new DatePeriod($start, new DateInterval('P1D'), $end->modify('+1 day')) as $day) {
            $key = $day->format('Y-m-d');
            $series[$key] = [
                'date' => $key,
                'label' => $day->format('d/m'),
                'human_messages' => 0,
                'first_responses' => 0,
                'appointments' => 0,
                'completed' => 0,
            ];
        }

        [$messageFilter, $messageParams] = $this->userFilter('sender_user_id', $userId);
        foreach ($this->rows(
            'SELECT sent_at
             FROM conversation_messages
             WHERE tenant_id = :tenant_id
               AND direction = "outgoing" AND sender_type = "user"
               AND sent_at BETWEEN :start_at AND :end_at' . $messageFilter,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $messageParams
        ) as $row) {
            $key = \App\Core\Clock::localDateKey((string) ($row['sent_at'] ?? ''), $timezone);
            if (isset($series[$key])) $series[$key]['human_messages']++;
        }

        [$responseFilter, $responseParams] = $this->userFilter('sc.first_response_user_id', $userId);
        [$responseReliabilityFilter, $responseReliabilityParams] = $this->cycleReliabilityFilter('sc', 'first_response_at', $date, $operationalOnly);
        foreach ($this->rows(
            'SELECT sc.first_response_at
             FROM conversation_service_cycles sc
             WHERE sc.tenant_id = :tenant_id
               AND sc.first_response_at BETWEEN :start_at AND :end_at' . $responseFilter . $responseReliabilityFilter,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $responseParams + $responseReliabilityParams
        ) as $row) {
            $key = \App\Core\Clock::localDateKey((string) ($row['first_response_at'] ?? ''), $timezone);
            if (isset($series[$key])) $series[$key]['first_responses']++;
        }

        [$appointmentFilter, $appointmentParams] = $this->userFilter('owner_user_id', $userId);
        foreach ($this->rows(
            'SELECT DATE(starts_at) AS metric_date, COUNT(*) AS appointments,
                    SUM(status = "completed") AS completed
             FROM calendar_appointments
             WHERE tenant_id = :tenant_id
               AND starts_at BETWEEN :start_at AND :end_at' . $appointmentFilter . '
             GROUP BY DATE(starts_at)',
            ['tenant_id' => $tenantId, 'start_at' => $date['local_start'], 'end_at' => $date['local_end']] + $appointmentParams
        ) as $row) {
            $key = (string) $row['metric_date'];
            if (isset($series[$key])) {
                $series[$key]['appointments'] = (int) $row['appointments'];
                $series[$key]['completed'] = (int) $row['completed'];
            }
        }

        return array_values($series);
    }

    private function serviceQuality(int $tenantId, array $date, int $userId, bool $operationalOnly, int $slaMinutes): array
    {
        $slaMinutes = max(5, min(1440, $slaMinutes));
        [$closedFilter, $closedParams] = $this->userFilter('sc.closed_by_user_id', $userId);
        [$closedReliability, $closedReliabilityParams] = $this->cycleReliabilityFilter('sc', 'closed_at', $date, $operationalOnly, 'service');
        $closed = $this->row(
            'SELECT COUNT(*) AS closed_cycles,
                    AVG(GREATEST(0, TIMESTAMPDIFF(SECOND, sc.opened_at, sc.closed_at))) AS avg_service_duration_seconds,
                    MIN(GREATEST(0, TIMESTAMPDIFF(SECOND, sc.opened_at, sc.closed_at))) AS min_service_duration_seconds,
                    MAX(GREATEST(0, TIMESTAMPDIFF(SECOND, sc.opened_at, sc.closed_at))) AS max_service_duration_seconds
             FROM conversation_service_cycles sc
             WHERE sc.tenant_id = :tenant_id AND sc.cycle_status = "closed"
               AND sc.opened_at IS NOT NULL AND sc.closed_at IS NOT NULL
               AND sc.closed_by_user_id IS NOT NULL
               AND sc.closed_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.opened_at') . $closedFilter . $closedReliability,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $closedParams + $closedReliabilityParams
        );

        $slaRows = $this->firstResponses($tenantId, $date, $userId, $operationalOnly, $slaMinutes);
        $waitingRows = $this->currentWaiting($tenantId, $userId, $slaMinutes);
        $measured = $met = $breached = 0;
        foreach ($slaRows as $row) {
            $measured += (int) ($row['sla_measured'] ?? 0);
            $met += (int) ($row['sla_met'] ?? 0);
            $breached += (int) ($row['sla_breached'] ?? 0);
        }
        $waitingNow = $waitingOver = $waitingTotal = $waitingMax = 0;
        foreach ($waitingRows as $row) {
            $count = (int) ($row['waiting_now'] ?? 0);
            $waitingNow += $count;
            $waitingOver += (int) ($row['waiting_over_sla'] ?? 0);
            $waitingTotal += ((int) ($row['avg_current_wait_seconds'] ?? 0)) * $count;
            $waitingMax = max($waitingMax, (int) ($row['max_current_wait_seconds'] ?? 0));
        }

        return [
            'closed_cycles' => (int) ($closed['closed_cycles'] ?? 0),
            'avg_service_duration_seconds' => (int) round((float) ($closed['avg_service_duration_seconds'] ?? 0)),
            'min_service_duration_seconds' => (int) ($closed['min_service_duration_seconds'] ?? 0),
            'max_service_duration_seconds' => (int) ($closed['max_service_duration_seconds'] ?? 0),
            'sla_target_minutes' => $slaMinutes,
            'sla_measured' => $measured,
            'sla_met' => $met,
            'sla_breached' => $breached,
            'sla_compliance' => $measured > 0 ? round(($met / $measured) * 100, 1) : 0.0,
            'waiting_now' => $waitingNow,
            'waiting_over_sla' => $waitingOver,
            'avg_current_wait_seconds' => $waitingNow > 0 ? (int) round($waitingTotal / $waitingNow) : 0,
            'max_current_wait_seconds' => $waitingMax,
        ];
    }

    private function departmentPerformance(int $tenantId, int $slaMinutes): array
    {
        $slaMinutes = max(5, min(1440, $slaMinutes));
        $slaSeconds = $slaMinutes * 60;
        $base = $this->rows(
            'SELECT d.id AS department_id, d.name, d.color,
                    COUNT(DISTINCT CASE WHEN c.status <> "closed" THEN c.id END) AS open_conversations,
                    COUNT(DISTINCT CASE WHEN u.status = "active" THEN m.user_id END) AS active_members
             FROM service_departments d
             LEFT JOIN conversations c ON c.department_id = d.id AND c.tenant_id = d.tenant_id
             LEFT JOIN service_department_members m ON m.department_id = d.id AND m.tenant_id = d.tenant_id
             LEFT JOIN users u ON u.id = m.user_id AND u.tenant_id = m.tenant_id
             WHERE d.tenant_id = :tenant_id AND d.status = "active"
             GROUP BY d.id, d.name, d.color',
            ['tenant_id' => $tenantId]
        );
        $indexed = [];
        foreach ($base as $row) {
            $id = (int) ($row['department_id'] ?? 0);
            $row['waiting_now'] = 0;
            $row['waiting_over_sla'] = 0;
            $row['avg_current_wait_seconds'] = 0;
            $row['_waiting_total'] = 0;
            $indexed[$id] = $row;
        }

        $pending = $this->rows(
            'SELECT c.department_id, sc.first_incoming_at,
                    sc.sla_target_minutes, sc.sla_warning_percent,
                    sc.sla_count_outside_business_hours, sc.sla_timezone,
                    sc.sla_business_hours_json
             FROM conversation_service_cycles sc
             INNER JOIN conversations c ON c.id = sc.conversation_id AND c.tenant_id = sc.tenant_id
             WHERE sc.tenant_id = :tenant_id
               AND c.department_id IS NOT NULL
               AND c.status <> "closed"
               AND sc.cycle_status = "active"
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_at IS NULL
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . '
               AND ' . TenantLifecycleService::currentLiveSql('sc.tenant_id'),
            ['tenant_id' => $tenantId]
        );
        $now = gmdate('Y-m-d H:i:s');
        foreach ($pending as $row) {
            $id = (int) ($row['department_id'] ?? 0);
            if (!isset($indexed[$id])) {
                continue;
            }
            $policy = $this->slaPolicy->policyForCycle($tenantId, $row);
            $policy['target_minutes'] = $slaMinutes;
            $elapsed = $this->slaPolicy->elapsedSeconds($tenantId, (string) ($row['first_incoming_at'] ?? ''), $now, $policy);
            $indexed[$id]['waiting_now']++;
            $indexed[$id]['_waiting_total'] += $elapsed;
            if ($elapsed > $slaSeconds) {
                $indexed[$id]['waiting_over_sla']++;
            }
        }
        foreach ($indexed as &$row) {
            $count = (int) ($row['waiting_now'] ?? 0);
            $row['avg_current_wait_seconds'] = $count > 0 ? (int) round(((int) $row['_waiting_total']) / $count) : 0;
            unset($row['_waiting_total']);
        }
        unset($row);
        $rows = array_values($indexed);
        usort($rows, static function (array $a, array $b): int {
            foreach (['waiting_over_sla', 'waiting_now', 'open_conversations'] as $key) {
                $cmp = ((int) ($b[$key] ?? 0)) <=> ((int) ($a[$key] ?? 0));
                if ($cmp !== 0) {
                    return $cmp;
                }
            }
            return strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
        });
        return $rows;
    }

    private function responseDataQuality(int $tenantId, array $date, int $userId, bool $operationalOnly): array
    {
        [$measuredFilter, $measuredParams] = $this->userFilter('sc.first_response_user_id', $userId);
        [$measuredReliabilityFilter, $measuredReliabilityParams] = $this->cycleReliabilityFilter('sc', 'first_response_at', $date, $operationalOnly);
        $measuredRows = $this->rows(
            'SELECT sc.first_incoming_at, sc.first_response_at,
                    sc.sla_target_minutes, sc.sla_warning_percent,
                    sc.sla_count_outside_business_hours, sc.sla_timezone,
                    sc.sla_business_hours_json
             FROM conversation_service_cycles sc
             WHERE sc.tenant_id = :tenant_id
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_at IS NOT NULL
               AND sc.first_response_user_id IS NOT NULL
               AND sc.first_response_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . $measuredFilter . $measuredReliabilityFilter,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $measuredParams + $measuredReliabilityParams
        );
        $seconds = [];
        $invalid = 0;
        foreach ($measuredRows as $row) {
            $incoming = (string) ($row['first_incoming_at'] ?? '');
            $response = (string) ($row['first_response_at'] ?? '');
            if ($incoming !== '' && $response !== '' && strtotime($response . ' UTC') < strtotime($incoming . ' UTC')) {
                $invalid++;
            }
            $policy = $this->slaPolicy->policyForCycle($tenantId, $row);
            $seconds[] = $this->slaPolicy->elapsedSeconds($tenantId, $incoming, $response, $policy);
        }

        $pendingFilter = '';
        $pendingParams = [];
        if ($userId > 0) {
            $pendingFilter = ' AND c.assigned_user_id = :pending_user_id';
            $pendingParams['pending_user_id'] = $userId;
        }
        [$pendingReliabilityFilter, $pendingReliabilityParams] = $this->cycleReliabilityFilter('sc', 'first_incoming_at', $date, $operationalOnly, 'pending');
        $pending = $this->scalar(
            'SELECT COUNT(*)
             FROM conversation_service_cycles sc
             INNER JOIN conversations c ON c.id = sc.conversation_id AND c.tenant_id = sc.tenant_id
             WHERE sc.tenant_id = :tenant_id
               AND sc.cycle_status = "active"
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_at IS NULL
               AND sc.first_incoming_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . $pendingFilter . $pendingReliabilityFilter,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $pendingParams + $pendingReliabilityParams
        );

        $count = count($seconds);
        $quality = [
            'measured_responses' => $count,
            'avg_response_seconds' => $count > 0 ? (int) round(array_sum($seconds) / $count) : 0,
            'min_response_seconds' => $count > 0 ? (int) min($seconds) : 0,
            'max_response_seconds' => $count > 0 ? (int) max($seconds) : 0,
            'pending_response_cycles' => $pending,
            'invalid_response_cycles' => $invalid,
            'operational_only' => $operationalOnly,
        ];

        if ($quality['invalid_response_cycles'] > 0) {
            $this->warnings[] = 'Há ciclos com resposta anterior à entrada do cliente. Revise a auditoria de primeira resposta.';
        }
        return $quality;
    }

    private function firstResponseAudit(int $tenantId, array $date, int $userId, int $limit, bool $operationalOnly, int $slaMinutes = 30): array
    {
        [$filter, $params] = $this->userFilter('sc.first_response_user_id', $userId);
        [$reliabilityFilter, $reliabilityParams] = $this->cycleReliabilityFilter('sc', 'first_response_at', $date, $operationalOnly);
        $limit = max(1, min(5000, $limit));
        $rows = $this->rows(
            'SELECT sc.conversation_id, sc.cycle_number, sc.first_incoming_at, sc.first_response_at,
                    sc.first_response_user_id, sc.cycle_status, sc.source,
                    sc.sla_target_minutes, sc.sla_warning_percent,
                    sc.sla_count_outside_business_hours, sc.sla_timezone,
                    sc.sla_business_hours_json,
                    COALESCE(NULLIF(u.whatsapp_display_name, ""), u.name, "Usuário") AS professional_name,
                    COALESCE(NULLIF(ct.name, ""), ct.phone, "Cliente") AS contact_name
             FROM conversation_service_cycles sc
             INNER JOIN conversations c ON c.id = sc.conversation_id AND c.tenant_id = sc.tenant_id
             INNER JOIN contacts ct ON ct.id = c.contact_id AND ct.tenant_id = sc.tenant_id
             LEFT JOIN users u ON u.id = sc.first_response_user_id
             WHERE sc.tenant_id = :tenant_id
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_at IS NOT NULL
               AND sc.first_response_user_id IS NOT NULL
               AND sc.first_response_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . $filter . $reliabilityFilter . '
             ORDER BY sc.first_response_at DESC
             LIMIT ' . $limit,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params + $reliabilityParams
        );

        foreach ($rows as &$row) {
            $row['conversation_uuid'] = \App\Core\PublicId::encode('conversation', (int) ($row['conversation_id'] ?? 0));
            unset($row['conversation_id']);
            $row['first_incoming_at_local'] = \App\Core\Clock::utcToLocal((string) ($row['first_incoming_at'] ?? ''), $date['timezone']);
            $row['first_response_at_local'] = \App\Core\Clock::utcToLocal((string) ($row['first_response_at'] ?? ''), $date['timezone']);
            $policy = $this->slaPolicy->policyForCycle($tenantId, $row);
            $policy['target_minutes'] = max(5, min(1440, $slaMinutes));
            $row['response_seconds'] = $this->slaPolicy->elapsedSeconds(
                $tenantId,
                (string) ($row['first_incoming_at'] ?? ''),
                (string) ($row['first_response_at'] ?? ''),
                $policy
            );
            $classification = $this->classifyCycleSource((string) ($row['source'] ?? ''), (string) ($row['first_response_at'] ?? ''), (string) ($date['cutover_at_utc'] ?? ''));
            $row['data_quality'] = $classification['code'];
            $row['data_quality_label'] = $classification['label'];
            $row['source_label'] = $this->sourceLabel((string) ($row['source'] ?? ''));
            $row['metric_cutover_at_utc'] = (string) ($date['cutover_at_utc'] ?? '');
            $row['metric_cutover_at_local'] = (string) ($date['cutover_at_local'] ?? '');
            $row['metric_timezone'] = (string) ($date['timezone'] ?? 'America/Sao_Paulo');
            $row['operational_only'] = $operationalOnly;
            $row['sla_target_minutes'] = max(5, min(1440, $slaMinutes));
            $row['within_sla'] = (int) ($row['response_seconds'] ?? 0) <= ($row['sla_target_minutes'] * 60);
        }
        unset($row);
        return $rows;
    }

    private function responseProvenance(int $tenantId, array $date, int $userId, bool $operationalOnly): array
    {
        [$filter, $params] = $this->userFilter('sc.first_response_user_id', $userId);
        $row = $this->row(
            'SELECT COUNT(*) AS total_measured_cycles,
                    SUM(CASE
                        WHEN COALESCE(sc.source, "") IN ("migration_snapshot", "migration_069_recovery")
                          OR (dc.cutover_at_utc IS NOT NULL AND sc.first_response_at < dc.cutover_at_utc)
                        THEN 1 ELSE 0 END) AS historical_recovered_cycles,
                    SUM(CASE
                        WHEN COALESCE(sc.source, "") = "message_cycle_recovery"
                         AND (dc.cutover_at_utc IS NULL OR sc.first_response_at >= dc.cutover_at_utc)
                        THEN 1 ELSE 0 END) AS operational_recovered_cycles,
                    SUM(CASE
                        WHEN COALESCE(sc.source, "") NOT IN ("migration_snapshot", "migration_069_recovery", "message_cycle_recovery")
                         AND (dc.cutover_at_utc IS NULL OR sc.first_response_at >= dc.cutover_at_utc)
                        THEN 1 ELSE 0 END) AS realtime_operational_cycles
             FROM conversation_service_cycles sc
             LEFT JOIN rs_datetime_contract dc ON dc.id = 1
             WHERE sc.tenant_id = :tenant_id
               AND sc.first_incoming_at IS NOT NULL
               AND sc.first_response_at IS NOT NULL
               AND sc.first_response_user_id IS NOT NULL
               AND sc.first_response_at BETWEEN :start_at AND :end_at
               AND ' . TenantLifecycleService::productionAtSql('sc.tenant_id', 'sc.first_incoming_at') . $filter,
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $params
        );

        $historical = (int) ($row['historical_recovered_cycles'] ?? 0);
        $operationalRecovered = (int) ($row['operational_recovered_cycles'] ?? 0);
        $realtime = (int) ($row['realtime_operational_cycles'] ?? 0);
        $operational = $operationalRecovered + $realtime;
        $total = (int) ($row['total_measured_cycles'] ?? 0);

        return [
            'operational_only' => $operationalOnly,
            'cutover_at_utc' => (string) ($date['cutover_at_utc'] ?? ''),
            'cutover_at_local' => (string) ($date['cutover_at_local'] ?? ''),
            'timezone' => (string) ($date['timezone'] ?? 'America/Sao_Paulo'),
            'total_measured_cycles' => $total,
            'historical_recovered_cycles' => $historical,
            'operational_recovered_cycles' => $operationalRecovered,
            'realtime_operational_cycles' => $realtime,
            'operational_cycles' => $operational,
            'included_cycles' => $operationalOnly ? $operational : $total,
            'excluded_historical_cycles' => $operationalOnly ? $historical : 0,
            'historical_sources' => self::HISTORICAL_CYCLE_SOURCES,
            'filter_label' => $operationalOnly ? 'Somente métricas operacionais' : 'Histórico recuperado + métricas operacionais',
        ];
    }

    private function cycleReliabilityFilter(string $alias, string $timeColumn, array $date, bool $operationalOnly, string $suffix = 'measured'): array
    {
        if (!$operationalOnly) {
            return ['', []];
        }

        $alias = preg_replace('/[^a-zA-Z0-9_]/', '', $alias) ?: 'sc';
        $timeColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $timeColumn) ?: 'first_response_at';
        $parameter = 'operational_cutover_' . preg_replace('/[^a-zA-Z0-9_]/', '', $suffix);
        $filter = ' AND COALESCE(' . $alias . '.source, "") NOT IN ("migration_snapshot", "migration_069_recovery")';
        $params = [];
        $cutoverAtUtc = (string) ($date['cutover_at_utc'] ?? '');
        if ($cutoverAtUtc !== '') {
            $filter .= ' AND ' . $alias . '.' . $timeColumn . ' >= :' . $parameter;
            $params[$parameter] = $cutoverAtUtc;
        }
        return [$filter, $params];
    }

    private function classifyCycleSource(string $source, string $eventAtUtc, string $cutoverAtUtc): array
    {
        if (in_array($source, self::HISTORICAL_CYCLE_SOURCES, true)
            || ($cutoverAtUtc !== '' && $eventAtUtc !== '' && $eventAtUtc < $cutoverAtUtc)) {
            return ['code' => 'historical_recovered', 'label' => 'Histórico recuperado'];
        }
        if ($source === 'message_cycle_recovery') {
            return ['code' => 'operational_recovered', 'label' => 'Operacional recuperado'];
        }
        return ['code' => 'operational', 'label' => 'Métrica operacional'];
    }

    private function sourceLabel(string $source): string
    {
        return match ($source) {
            'migration_snapshot' => 'Snapshot da migração',
            'migration_069_recovery' => 'Recuperação da migration 069',
            'message_cycle_recovery' => 'Recuperação automática por mensagem',
            'conversation_reopened' => 'Conversa reaberta',
            'conversation_created' => 'Conversa criada',
            default => $source !== '' ? str_replace('_', ' ', $source) : 'Origem não informada',
        };
    }

    private function recentActivities(int $tenantId, array $date, int $userId): array
    {
        $activities = [];
        [$assignedFilter, $assignedParams] = $this->activityUserFilter('h.assigned_user_id', 'h.previous_user_id', $userId);
        foreach ($this->rows(
            'SELECT h.occurred_at, "conversation_assignment" AS activity_type, h.action,
                    h.conversation_id AS record_id, h.assigned_user_id AS user_id,
                    u.name AS user_name, pu.name AS previous_user_name,
                    ct.name AS subject_name
             FROM conversation_assignment_history h
             LEFT JOIN users u ON u.id = h.assigned_user_id
             LEFT JOIN users pu ON pu.id = h.previous_user_id
             INNER JOIN conversations c ON c.id = h.conversation_id
             INNER JOIN contacts ct ON ct.id = c.contact_id
             WHERE h.tenant_id = :tenant_id
               AND h.occurred_at BETWEEN :start_at AND :end_at' . $assignedFilter . '
             ORDER BY h.occurred_at DESC LIMIT 30',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $assignedParams
        ) as $row) {
            $row['description'] = $this->assignmentDescription($row);
            $row['occurred_at_local'] = \App\Core\Clock::utcToLocal((string) ($row['occurred_at'] ?? ''), $date['timezone']);
            $activities[] = $row;
        }

        [$appointmentFilter, $appointmentParams] = $this->activityUserFilter('h.owner_user_id', 'h.previous_owner_user_id', $userId);
        foreach ($this->rows(
            'SELECT h.occurred_at, "appointment" AS activity_type, h.event_type AS action,
                    h.appointment_id AS record_id, h.owner_user_id AS user_id,
                    u.name AS user_name, pu.name AS previous_user_name,
                    h.title_snapshot AS subject_name, h.status
             FROM calendar_appointment_history h
             LEFT JOIN users u ON u.id = h.owner_user_id
             LEFT JOIN users pu ON pu.id = h.previous_owner_user_id
             WHERE h.tenant_id = :tenant_id
               AND h.occurred_at BETWEEN :start_at AND :end_at' . $appointmentFilter . '
             ORDER BY h.occurred_at DESC LIMIT 30',
            ['tenant_id' => $tenantId, 'start_at' => $date['utc_start'], 'end_at' => $date['utc_end']] + $appointmentParams
        ) as $row) {
            $row['description'] = $this->appointmentDescription($row);
            $row['occurred_at_local'] = \App\Core\Clock::utcToLocal((string) ($row['occurred_at'] ?? ''), $date['timezone']);
            $activities[] = $row;
        }

        usort($activities, static fn (array $a, array $b): int => strcmp((string) $b['occurred_at'], (string) $a['occurred_at']));
        return array_slice($activities, 0, 30);
    }

    private function assignmentDescription(array $row): string
    {
        $subject = trim((string) ($row['subject_name'] ?? 'Cliente')) ?: 'Cliente';
        $user = trim((string) ($row['user_name'] ?? 'sem responsável')) ?: 'sem responsável';
        $previous = trim((string) ($row['previous_user_name'] ?? ''));
        return match ((string) ($row['action'] ?? '')) {
            'transfer' => $subject . ': transferido de ' . ($previous ?: 'outro responsável') . ' para ' . $user . '.',
            'release' => $subject . ': atendimento liberado por ' . ($previous ?: 'responsável anterior') . '.',
            'snapshot' => $subject . ': responsável atual registrado como ' . $user . '.',
            default => $subject . ': atendimento atribuído a ' . $user . '.',
        };
    }

    private function appointmentDescription(array $row): string
    {
        $title = trim((string) ($row['subject_name'] ?? 'Compromisso')) ?: 'Compromisso';
        $user = trim((string) ($row['user_name'] ?? 'sem profissional')) ?: 'sem profissional';
        $previous = trim((string) ($row['previous_user_name'] ?? ''));
        $action = (string) ($row['action'] ?? '');
        $status = (string) ($row['status'] ?? '');
        if ($action === 'status_changed') {
            return match ($status) {
                'confirmed' => $title . ': confirmado para ' . $user . '.',
                'completed' => $title . ': concluído por ' . $user . '.',
                'cancelled', 'rejected' => $title . ': cancelado.',
                'no_show' => $title . ': cliente não compareceu.',
                default => $title . ': status alterado para ' . str_replace('_', ' ', $status ?: 'atualizado') . '.',
            };
        }
        return match ($action) {
            'owner_changed' => $title . ': profissional alterado de ' . ($previous ?: 'não definido') . ' para ' . $user . '.',
            'rescheduled' => $title . ': horário alterado.',
            'created' => $title . ': compromisso criado para ' . $user . '.',
            'deleted' => $title . ': compromisso excluído.',
            'snapshot' => $title . ': estado inicial registrado.',
            default => $title . ': ' . str_replace('_', ' ', $action ?: 'atualizado') . '.',
        };
    }

    private function mergeRows(array &$professionals, array $rows): void
    {
        foreach ($rows as $row) {
            $id = (int) ($row['user_id'] ?? 0);
            if ($id < 1 || !isset($professionals[$id])) {
                continue;
            }
            foreach ($row as $key => $value) {
                if ($key === 'user_id') continue;
                $professionals[$id][$key] = is_numeric($value) ? (float) $value : $value;
            }
        }
    }

    private function userFilter(string $column, int $userId): array
    {
        if ($userId < 1) return ['', []];
        return [' AND ' . $column . ' = :filter_user_id', ['filter_user_id' => $userId]];
    }

    private function activityUserFilter(string $currentColumn, string $previousColumn, int $userId): array
    {
        if ($userId < 1) return ['', []];
        return [
            ' AND (' . $currentColumn . ' = :activity_current_user_id OR ' . $previousColumn . ' = :activity_previous_user_id)',
            ['activity_current_user_id' => $userId, 'activity_previous_user_id' => $userId],
        ];
    }

    private function tenantTimezone(int $tenantId): string
    {
        $row = $this->row(
            'SELECT COALESCE(NULLIF(os.business_timezone, ""), NULLIF(cas.timezone, ""), "America/Sao_Paulo") AS timezone
             FROM tenants t
             LEFT JOIN tenant_onboarding_settings os ON os.tenant_id = t.id
             LEFT JOIN tenant_calendar_availability_settings cas ON cas.tenant_id = t.id
             WHERE t.id = :tenant_id LIMIT 1',
            ['tenant_id' => $tenantId]
        );
        return \App\Core\Clock::safeTimezone((string) ($row['timezone'] ?? 'America/Sao_Paulo'));
    }

    private function dateParams(array $filters, string $timezone): array
    {
        $timezone = \App\Core\Clock::safeTimezone($timezone);
        $utc = \App\Core\Clock::localRangeToUtc((string) $filters['start'], (string) $filters['end'], $timezone);
        $nowLocal = (new \DateTimeImmutable('now', new \DateTimeZone($timezone)))->format('Y-m-d H:i:s');
        $cutoverAtUtc = $this->reliableCutoverAtUtc();

        return [
            'utc_start' => $utc['start'],
            'utc_end' => $utc['end'],
            'local_start' => $filters['start'] . ' 00:00:00',
            'local_end' => $filters['end'] . ' 23:59:59',
            'now_local' => $nowLocal,
            'timezone' => $timezone,
            'cutover_at_utc' => $cutoverAtUtc,
            'cutover_at_local' => $cutoverAtUtc !== '' ? \App\Core\Clock::utcToLocal($cutoverAtUtc, $timezone) : '',
        ];
    }

    private function reliableCutoverAtUtc(): string
    {
        if ($this->cutoverLoaded) {
            return $this->cutoverAtUtc;
        }
        $this->cutoverLoaded = true;
        $row = $this->row('SELECT cutover_at_utc FROM rs_datetime_contract WHERE id = 1 LIMIT 1');
        $this->cutoverAtUtc = trim((string) ($row['cutover_at_utc'] ?? ''));
        return $this->cutoverAtUtc;
    }

    private function emptyResponseProvenance(bool $operationalOnly = false): array
    {
        return [
            'operational_only' => $operationalOnly,
            'cutover_at_utc' => '',
            'cutover_at_local' => '',
            'timezone' => 'America/Sao_Paulo',
            'total_measured_cycles' => 0,
            'historical_recovered_cycles' => 0,
            'operational_recovered_cycles' => 0,
            'realtime_operational_cycles' => 0,
            'operational_cycles' => 0,
            'included_cycles' => 0,
            'excluded_historical_cycles' => 0,
            'historical_sources' => self::HISTORICAL_CYCLE_SOURCES,
            'filter_label' => $operationalOnly ? 'Somente métricas operacionais' : 'Histórico recuperado + métricas operacionais',
        ];
    }

    private function emptyServiceQuality(int $slaMinutes = 30): array
    {
        return [
            'closed_cycles' => 0,
            'avg_service_duration_seconds' => 0,
            'min_service_duration_seconds' => 0,
            'max_service_duration_seconds' => 0,
            'sla_target_minutes' => max(5, min(1440, $slaMinutes)),
            'sla_measured' => 0,
            'sla_met' => 0,
            'sla_breached' => 0,
            'sla_compliance' => 0.0,
            'waiting_now' => 0,
            'waiting_over_sla' => 0,
            'avg_current_wait_seconds' => 0,
            'max_current_wait_seconds' => 0,
        ];
    }

    private function emptyDataQuality(): array
    {
        return [
            'measured_responses' => 0,
            'avg_response_seconds' => 0,
            'min_response_seconds' => 0,
            'max_response_seconds' => 0,
            'pending_response_cycles' => 0,
            'invalid_response_cycles' => 0,
        ];
    }

    private function emptyOverview(): array
    {
        return [
            'team_members' => 0,
            'human_messages' => 0,
            'conversations_replied' => 0,
            'first_responses' => 0,
            'avg_first_response_seconds' => 0,
            'avg_service_duration_seconds' => 0,
            'service_cycles_closed' => 0,
            'sla_target_minutes' => 30,
            'sla_measured' => 0,
            'sla_met' => 0,
            'sla_breached' => 0,
            'sla_compliance' => 0.0,
            'waiting_now' => 0,
            'waiting_over_sla' => 0,
            'avg_current_wait_seconds' => 0,
            'max_current_wait_seconds' => 0,
            'assignments' => 0,
            'transfers_received' => 0,
            'transfers_out' => 0,
            'releases' => 0,
            'closed_conversations' => 0,
            'open_conversations' => 0,
            'appointments' => 0,
            'appointments_confirmed' => 0,
            'appointments_completed' => 0,
            'appointments_cancelled' => 0,
            'appointments_no_show' => 0,
            'appointments_upcoming' => 0,
            'preferred_clients' => 0,
            'appointment_success_rate' => 0.0,
            'attendance_rate' => 0.0,
            'scope_label' => '',
        ];
    }

    private function roleLabel(string $role): string
    {
        return match ($role) {
            'client_admin' => 'Administrador',
            'super_admin' => 'Super Admin',
            default => 'Profissional',
        };
    }

    private function scalar(string $sql, array $params = []): int
    {
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute($params);
            return (int) $statement->fetchColumn();
        } catch (Throwable $exception) {
            $this->warn($exception);
            return 0;
        }
    }

    private function row(string $sql, array $params = []): array
    {
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute($params);
            return $statement->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $exception) {
            $this->warn($exception);
            return [];
        }
    }

    private function rows(string $sql, array $params = []): array
    {
        try {
            $statement = $this->pdo->prepare($sql);
            $statement->execute($params);
            return $statement->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $exception) {
            $this->warn($exception);
            return [];
        }
    }

    private function warn(Throwable $exception): void
    {
        error_log('[reports.team] ' . preg_replace('/\s+/', ' ', $exception->getMessage()));
        $this->warnings[] = 'Um indicador da equipe ficou temporariamente indisponível.';
    }
}
