<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Audit;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Router;
use App\Core\View;
use App\Services\AdminDashboardService;
use App\Services\AgentBlueprintService;
use App\Services\PreSchedulingService;
use App\Services\TenantModuleService;
use App\Services\TenantLifecycleService;
use App\Services\OnboardingGuideService;
use App\Services\MessageGovernanceService;
use App\Services\ConversationOwnershipService;
use PDO;
use Throwable;

final class CompanyController
{
    public function index(): void
    {
        $data = (new AdminDashboardService())->companies([
            'q' => (string) ($_GET['q'] ?? ''),
            'status' => (string) ($_GET['status'] ?? ''),
            'plan' => (string) ($_GET['plan'] ?? ''),
            'health' => (string) ($_GET['health'] ?? ''),
            'tracking' => (string) ($_GET['tracking'] ?? ''),
            'lifecycle' => (string) ($_GET['lifecycle'] ?? ''),
        ]);

        $blueprintService = new AgentBlueprintService();
        View::render('companies.index', [
            'title' => 'Empresas',
            'companies' => $data['companies'],
            'summary' => $data['summary'],
            'filters' => $data['filters'],
            'dataWarnings' => $data['data_warnings'] ?? [],
            'businessNiches' => $blueprintService->niches(),
            'agentBlueprints' => $blueprintService->blueprints(),
        ]);
    }

    public function overview(): void
    {
        $tenantId = (int) ($_GET['id'] ?? 0);
        $company = (new AdminDashboardService())->companyOverview($tenantId);
        if (!$company) {
            Flash::set('error', 'Empresa não encontrada.');
            $this->redirect('/companies');
        }

        View::render('companies.overview', [
            'title' => 'Visão geral da empresa',
            'company' => $company,
            'lifecycleHistory' => (new TenantLifecycleService())->history($tenantId, 12),
        ]);
    }

    public function store(): void
    {
        $name = trim((string) ($_POST['name'] ?? ''));
        $legalName = trim((string) ($_POST['legal_name'] ?? ''));
        $document = trim((string) ($_POST['document'] ?? ''));
        $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $segment = trim((string) ($_POST['segment'] ?? ''));
        $businessNicheId = max(0, (int) ($_POST['business_niche_id'] ?? 0));
        $agentBlueprintId = max(0, (int) ($_POST['agent_blueprint_id'] ?? 0));
        $plan = (string) ($_POST['plan'] ?? 'starter');
        $ownerName = trim((string) ($_POST['owner_name'] ?? ''));
        $ownerEmail = mb_strtolower(trim((string) ($_POST['owner_email'] ?? '')));
        $ownerPassword = (string) ($_POST['owner_password'] ?? '');

        if ($name === '' || $ownerName === '' || !filter_var($ownerEmail, FILTER_VALIDATE_EMAIL) || strlen($ownerPassword) < 8) {
            Flash::set('error', 'Informe empresa, responsável, e-mail válido e uma senha com pelo menos 8 caracteres.');
            $this->redirect('/companies');
        }

        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            Flash::set('error', 'O e-mail comercial da empresa é inválido.');
            $this->redirect('/companies');
        }

        if (!in_array($plan, ['starter', 'pro', 'business', 'custom'], true)) {
            $plan = 'starter';
        }

        $pdo = Database::connection();
        $blueprintService = new AgentBlueprintService();
        if ($agentBlueprintId > 0) {
            $selectedBlueprint = $blueprintService->blueprint($agentBlueprintId, $pdo);
            if (!$selectedBlueprint || ($businessNicheId > 0 && (int) ($selectedBlueprint['niche_id'] ?? 0) !== $businessNicheId)) {
                Flash::set('error', 'O blueprint selecionado não pertence ao nicho informado.');
                $this->redirect('/companies');
            }
            $businessNicheId = (int) ($selectedBlueprint['niche_id'] ?? $businessNicheId);
            if ($segment === '') {
                $segment = (string) ($selectedBlueprint['niche_name'] ?? '');
            }
        } elseif ($businessNicheId > 0) {
            foreach ($blueprintService->blueprints($businessNicheId) as $candidateBlueprint) {
                $agentBlueprintId = (int) ($candidateBlueprint['id'] ?? 0);
                if ($agentBlueprintId > 0) {
                    if ($segment === '') {
                        $segment = (string) ($candidateBlueprint['niche_name'] ?? '');
                    }
                    break;
                }
            }
        }

        try {
            $pdo->beginTransaction();
            $slug = $this->uniqueSlug($name);

            $tenant = $pdo->prepare(
                'INSERT INTO tenants
                    (name, legal_name, slug, document, email, phone, segment, business_niche_id, plan, status, lifecycle_status, onboarding_step)
                 VALUES
                    (:name, :legal_name, :slug, :document, :email, :phone, :segment, :business_niche_id, :plan, "active", "onboarding", 1)'
            );
            $tenant->execute([
                'name' => $name,
                'legal_name' => $legalName !== '' ? $legalName : null,
                'slug' => $slug,
                'document' => $document !== '' ? $document : null,
                'email' => $email !== '' ? $email : null,
                'phone' => $phone !== '' ? $phone : null,
                'segment' => $segment !== '' ? $segment : null,
                'business_niche_id' => $businessNicheId > 0 ? $businessNicheId : null,
                'plan' => $plan,
            ]);
            $tenantId = (int) $pdo->lastInsertId();

            $user = $pdo->prepare(
                'INSERT INTO users (tenant_id, name, email, password_hash, role, status)
                 VALUES (:tenant_id, :name, :email, :password_hash, "client_admin", "active")'
            );
            $user->execute([
                'tenant_id' => $tenantId,
                'name' => $ownerName,
                'email' => $ownerEmail,
                'password_hash' => password_hash($ownerPassword, PASSWORD_DEFAULT),
            ]);

            $this->createInitialSubscription($pdo, $tenantId, $plan);
            $this->createDefaultPipeline($pdo, $tenantId);
            if ($agentBlueprintId > 0) {
                $blueprintService->applyBlueprint($tenantId, $agentBlueprintId, $pdo, false);
            }

            $pdo->commit();
            Audit::log('company.created', ['company_name' => $name, 'owner_email' => $ownerEmail], $tenantId);
            Flash::set('success', 'Empresa e administrador do cliente cadastrados.');
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            Flash::set('error', 'Não foi possível cadastrar. Confira se o e-mail já está em uso.');
        }

        $this->redirect('/companies');
    }

    public function settings(): void
    {
        $tenantId = $this->requestedTenantId();
        $statement = Database::connection()->prepare('SELECT * FROM tenants WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $tenantId]);
        $company = $statement->fetch(PDO::FETCH_ASSOC);

        if (!$company) {
            Flash::set('error', 'Empresa não encontrada.');
            $this->redirect(Auth::isSuperAdmin() ? '/companies' : '/');
        }

        $preSchedulingService = new PreSchedulingService();
        $moduleService = new TenantModuleService();

        $blueprintService = new AgentBlueprintService();
        $agentPolicyDecisions = [];
        if (Auth::isSuperAdmin()) {
            try {
                $policyStmt = Database::connection()->prepare(
                    'SELECT d.id, d.conversation_id, d.policy_key, d.decision, d.reason_code, d.evidence_json, d.created_at,
                            c.name AS contact_name, c.phone AS contact_phone
                     FROM conversation_policy_decisions d
                     LEFT JOIN contacts c ON c.id = d.contact_id AND c.tenant_id = d.tenant_id
                     WHERE d.tenant_id = :tenant_id
                     ORDER BY d.created_at DESC, d.id DESC
                     LIMIT 40'
                );
                $policyStmt->execute(['tenant_id' => $tenantId]);
                $agentPolicyDecisions = $policyStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                foreach ($agentPolicyDecisions as &$policyDecision) {
                    $decodedEvidence = json_decode((string) ($policyDecision['evidence_json'] ?? ''), true);
                    $policyDecision['evidence'] = is_array($decodedEvidence) ? $decodedEvidence : [];
                }
                unset($policyDecision);
            } catch (Throwable) {
                // A tela continua disponível antes da migration 103.
            }
        }

        View::render('companies.settings', [
            'title' => Auth::isSuperAdmin() ? 'Configurações da empresa' : 'Minha empresa',
            'company' => $company,
            'businessNiches' => $blueprintService->niches(),
            'agentBlueprints' => $blueprintService->blueprints(),
            'agentBlueprintProfile' => $blueprintService->profileForTenant($tenantId, true),
            'agentPolicyDecisions' => $agentPolicyDecisions,
            'preScheduleSettings' => $preSchedulingService->settings($tenantId),
            'availableModules' => TenantModuleService::modules(),
            'moduleSettings' => $moduleService->settingsForTenant($tenantId),
            'calendarAccessSettings' => (new OnboardingGuideService())->calendarAccessSettings($tenantId),
            'messageGovernanceSettings' => (new MessageGovernanceService())->settingsForTenant($tenantId),
            'professionalAssignmentSettings' => (new ConversationOwnershipService())->settingsForTenant(Database::connection(), $tenantId),
        ]);
    }

    public function updateSettings(): void
    {
        $tenantId = Auth::isSuperAdmin()
            ? (int) ($_POST['tenant_id'] ?? 0)
            : (int) Auth::tenantId();

        if ($tenantId < 1) {
            Flash::set('error', 'Empresa inválida.');
            $this->redirect('/');
        }

        $pdo = Database::connection();
        $currentStatement = $pdo->prepare('SELECT * FROM tenants WHERE id = :id LIMIT 1');
        $currentStatement->execute(['id' => $tenantId]);
        $current = $currentStatement->fetch(PDO::FETCH_ASSOC);
        if (!$current) {
            Flash::set('error', 'Empresa não encontrada.');
            $this->redirect(Auth::isSuperAdmin() ? '/companies' : '/');
        }

        $posted = static function (string $key, array $current, bool $lowercase = false): string {
            $value = array_key_exists($key, $_POST)
                ? trim((string) $_POST[$key])
                : trim((string) ($current[$key] ?? ''));
            return $lowercase ? mb_strtolower($value) : $value;
        };

        $name = $posted('name', $current);
        // Dados mestres cadastrais são mantidos pela equipe RS. Mesmo que um cliente
        // altere o HTML no navegador, o backend ignora legal_name/document/segment.
        $legalName = Auth::isSuperAdmin() ? $posted('legal_name', $current) : trim((string) ($current['legal_name'] ?? ''));
        $document = Auth::isSuperAdmin() ? $posted('document', $current) : trim((string) ($current['document'] ?? ''));
        $email = $posted('email', $current, true);
        $phone = $posted('phone', $current);
        $website = $posted('website', $current);
        $segment = Auth::isSuperAdmin() ? $posted('segment', $current) : trim((string) ($current['segment'] ?? ''));
        $commercialWhatsapp = $posted('commercial_whatsapp', $current);
        $instagram = $posted('instagram', $current);
        $postalCode = $posted('postal_code', $current);
        $addressLine = $posted('address_line', $current);
        $addressNumber = $posted('address_number', $current);
        $addressComplement = $posted('address_complement', $current);
        $district = $posted('district', $current);
        $city = $posted('city', $current);
        $state = $posted('state', $current);
        $companyAbout = $posted('company_about', $current);
        $companyServices = $posted('company_services', $current);
        $companyDifferentials = $posted('company_differentials', $current);
        $companyBusinessHours = $posted('company_business_hours', $current);
        $companyNotes = $posted('company_notes', $current);
        $humanSignatureEnabled = array_key_exists('message_governance_settings_submitted', $_POST)
            ? ((string) ($_POST['whatsapp_human_signature_enabled'] ?? '0') === '1' ? 1 : 0)
            : (int) ($current['whatsapp_human_signature_enabled'] ?? 0);
        $humanSignatureFormat = trim((string) ($_POST['whatsapp_human_signature_format'] ?? ($current['whatsapp_human_signature_format'] ?? 'name_role')));
        if (!in_array($humanSignatureFormat, ['name', 'name_role', 'name_company'], true)) {
            $humanSignatureFormat = 'name_role';
        }
        $retentionMode = trim((string) ($_POST['message_retention_mode'] ?? ($current['message_retention_mode'] ?? 'reduced')));
        if (!in_array($retentionMode, ['complete', 'reduced', 'ephemeral'], true)) {
            $retentionMode = 'reduced';
        }
        $retentionDays = max(1, min(3650, (int) ($_POST['message_retention_days'] ?? ($current['message_retention_days'] ?? 90))));
        $rawPayloadDays = max(1, min(3650, (int) ($_POST['message_raw_payload_days'] ?? ($current['message_raw_payload_days'] ?? 30))));
        $ephemeralHours = max(1, min(720, (int) ($_POST['message_ephemeral_hours'] ?? ($current['message_ephemeral_hours'] ?? 24))));
        $professionalAssignmentEnabled = array_key_exists('professional_assignment_settings_submitted', $_POST)
            ? (isset($_POST['professional_assignment_enabled']) ? 1 : 0)
            : (int) ($current['professional_assignment_enabled'] ?? 0);
        $professionalLockEnabled = array_key_exists('professional_assignment_settings_submitted', $_POST)
            ? (isset($_POST['professional_lock_enabled']) ? 1 : 0)
            : (int) ($current['professional_lock_enabled'] ?? 1);
        $professionalAutoAssignEnabled = array_key_exists('professional_assignment_settings_submitted', $_POST)
            ? (isset($_POST['professional_auto_assign_enabled']) ? 1 : 0)
            : (int) ($current['professional_auto_assign_enabled'] ?? 0);
        // A atribuição automática nunca é ligada implicitamente. Ela só permanece ativa
        // quando o recurso geral também está habilitado e a empresa marcou a opção.
        if ($professionalAssignmentEnabled !== 1) {
            $professionalAutoAssignEnabled = 0;
        }

        if ($name === '' || ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL))) {
            Flash::set('error', 'Informe o nome da empresa e um e-mail válido.');
            $this->redirect('/company-settings' . (Auth::isSuperAdmin() ? '?id=' . $tenantId : ''));
        }

        if ($website !== '' && !filter_var($website, FILTER_VALIDATE_URL)) {
            Flash::set('error', 'Informe o site com endereço completo, incluindo https://.');
            $this->redirect('/company-settings' . (Auth::isSuperAdmin() ? '?id=' . $tenantId : ''));
        }

        $statement = $pdo->prepare(
            'UPDATE tenants
             SET name = :name, legal_name = :legal_name, document = :document, email = :email,
                 phone = :phone, website = :website, segment = :segment,
                 commercial_whatsapp = :commercial_whatsapp, instagram = :instagram,
                 postal_code = :postal_code, address_line = :address_line, address_number = :address_number,
                 address_complement = :address_complement, district = :district, city = :city, state = :state,
                 company_about = :company_about, company_services = :company_services,
                 company_differentials = :company_differentials,
                 company_business_hours = :company_business_hours, company_notes = :company_notes,
                 whatsapp_human_signature_enabled = :whatsapp_human_signature_enabled,
                 whatsapp_human_signature_format = :whatsapp_human_signature_format,
                 message_retention_mode = :message_retention_mode,
                 message_retention_days = :message_retention_days,
                 message_raw_payload_days = :message_raw_payload_days,
                 message_ephemeral_hours = :message_ephemeral_hours,
                 professional_assignment_enabled = :professional_assignment_enabled,
                 professional_lock_enabled = :professional_lock_enabled,
                 professional_auto_assign_enabled = :professional_auto_assign_enabled,
                 onboarding_step = GREATEST(onboarding_step, 2)
             WHERE id = :id'
        );
        $statement->execute([
            'name' => $name,
            'legal_name' => $legalName !== '' ? $legalName : null,
            'document' => $document !== '' ? $document : null,
            'email' => $email !== '' ? $email : null,
            'phone' => $phone !== '' ? $phone : null,
            'website' => $website !== '' ? $website : null,
            'segment' => $segment !== '' ? $segment : null,
            'commercial_whatsapp' => $commercialWhatsapp !== '' ? $commercialWhatsapp : null,
            'instagram' => $instagram !== '' ? $instagram : null,
            'postal_code' => $postalCode !== '' ? $postalCode : null,
            'address_line' => $addressLine !== '' ? $addressLine : null,
            'address_number' => $addressNumber !== '' ? $addressNumber : null,
            'address_complement' => $addressComplement !== '' ? $addressComplement : null,
            'district' => $district !== '' ? $district : null,
            'city' => $city !== '' ? $city : null,
            'state' => $state !== '' ? $state : null,
            'company_about' => $companyAbout !== '' ? $companyAbout : null,
            'company_services' => $companyServices !== '' ? $companyServices : null,
            'company_differentials' => $companyDifferentials !== '' ? $companyDifferentials : null,
            'company_business_hours' => $companyBusinessHours !== '' ? $companyBusinessHours : null,
            'company_notes' => $companyNotes !== '' ? $companyNotes : null,
            'whatsapp_human_signature_enabled' => $humanSignatureEnabled,
            'whatsapp_human_signature_format' => $humanSignatureFormat,
            'message_retention_mode' => $retentionMode,
            'message_retention_days' => $retentionDays,
            'message_raw_payload_days' => $rawPayloadDays,
            'message_ephemeral_hours' => $ephemeralHours,
            'professional_assignment_enabled' => $professionalAssignmentEnabled,
            'professional_lock_enabled' => $professionalLockEnabled,
            'professional_auto_assign_enabled' => $professionalAutoAssignEnabled,
            'id' => $tenantId,
        ]);

        if (Auth::isSuperAdmin() && array_key_exists('agent_architecture_settings_submitted', $_POST)) {
            try {
                $blueprintService = new AgentBlueprintService();
                $postedBlueprintId = max(0, (int) ($_POST['agent_blueprint_id'] ?? 0));
                $currentProfile = $blueprintService->profileForTenant($tenantId, false);
                if ($postedBlueprintId > 0 && (int) ($currentProfile['blueprint_id'] ?? 0) !== $postedBlueprintId) {
                    $blueprintService->applyBlueprint($tenantId, $postedBlueprintId, null, false);
                }
                if ($postedBlueprintId > 0 || !empty($currentProfile['id'])) {
                    $blueprintService->saveTenantConfiguration($tenantId, [
                        'interaction_mode' => (string) ($_POST['agent_interaction_mode'] ?? 'hybrid'),
                        'capabilities' => is_array($_POST['agent_capabilities'] ?? null) ? $_POST['agent_capabilities'] : [],
                        'triage_fields' => is_array($_POST['triage_fields'] ?? null) ? $_POST['triage_fields'] : [],
                        'policies' => is_array($_POST['agent_policies'] ?? null) ? $_POST['agent_policies'] : [],
                        'workflow' => is_array($_POST['workflow_steps'] ?? null) ? $_POST['workflow_steps'] : [],
                    ]);
                }
            } catch (Throwable $exception) {
                Flash::set('error', 'Configurações cadastrais salvas, mas a arquitetura do agente não pôde ser atualizada: ' . $exception->getMessage());
                $this->redirect('/company-settings?id=' . $tenantId);
            }
        }

        $confirmationMode = strtolower(trim((string) ($_POST['pre_schedule_confirmation_mode'] ?? '')));
        if (!in_array($confirmationMode, ['human', 'automatic', 'pre_schedule'], true)) {
            $confirmationMode = isset($_POST['pre_schedule_require_human_approval'])
                ? 'human'
                : (isset($_POST['pre_schedule_ai_can_confirm']) ? 'automatic' : 'pre_schedule');
        }

        (new PreSchedulingService())->saveSettings($tenantId, [
            'enabled' => isset($_POST['pre_schedule_enabled']),
            'require_human_approval' => $confirmationMode === 'human',
            'ai_can_suggest_slots' => isset($_POST['pre_schedule_ai_can_suggest_slots']),
            'ai_can_confirm' => $confirmationMode === 'automatic',
            'send_approval_message' => isset($_POST['pre_schedule_send_approval_message']),
            'default_duration_minutes' => (int) ($_POST['pre_schedule_default_duration_minutes'] ?? 50),
            'message_mode' => trim((string) ($_POST['pre_schedule_message_mode'] ?? 'form')),
            'initial_collect_message' => trim((string) ($_POST['pre_schedule_initial_collect_message'] ?? '')),
            'default_message' => trim((string) ($_POST['pre_schedule_default_message'] ?? '')),
            'collect_message' => trim((string) ($_POST['pre_schedule_collect_message'] ?? '')),
            'modality_message' => trim((string) ($_POST['pre_schedule_modality_message'] ?? '')),
            'approved_message' => trim((string) ($_POST['pre_schedule_approved_message'] ?? '')),
            'rejected_message' => trim((string) ($_POST['pre_schedule_rejected_message'] ?? '')),
            'reschedule_message' => trim((string) ($_POST['pre_schedule_reschedule_message'] ?? '')),
            'availability_options_message' => trim((string) ($_POST['pre_schedule_availability_options_message'] ?? '')),
            'slot_selected_message' => trim((string) ($_POST['pre_schedule_slot_selected_message'] ?? '')),
            'no_availability_message' => trim((string) ($_POST['pre_schedule_no_availability_message'] ?? '')),
            'invalid_slot_message' => trim((string) ($_POST['pre_schedule_invalid_slot_message'] ?? '')),
        ]);

        if (Auth::isSuperAdmin() && array_key_exists('smart_calendar_status', $_POST)) {
            try {
                (new OnboardingGuideService())->saveSmartCalendarAccess(
                    $tenantId,
                    trim((string) $_POST['smart_calendar_status']),
                    Auth::id()
                );
            } catch (Throwable $exception) {
                Flash::set('error', $exception->getMessage());
                $this->redirect('/company-settings?id=' . $tenantId);
            }
        }

        if (isset($_POST['module_settings_submitted'])) {
            $visibleModules = array_values(array_filter(array_map('strval', (array) ($_POST['module_visible'] ?? []))));
            $moduleService = new TenantModuleService();
            if (Auth::isSuperAdmin()) {
                $moduleService->saveSettings(
                    $tenantId,
                    $visibleModules,
                    array_values(array_filter(array_map('strval', (array) ($_POST['module_enabled'] ?? []))))
                );
            } elseif ((int) Auth::tenantId() === $tenantId) {
                $moduleService->saveVisibility($tenantId, $visibleModules);
            }
        }

        if (!Auth::isSuperAdmin()
            && (int) Auth::tenantId() === $tenantId
            && array_key_exists('queue_settings_submitted', $_POST)) {
            $queueEnabled = isset($_POST['queue_enabled']) && (string) $_POST['queue_enabled'] === '1';
            (new TenantModuleService())->saveModuleState($tenantId, 'queue', $queueEnabled, $queueEnabled);
            Audit::log('company.queue_preference_updated', ['enabled' => $queueEnabled], $tenantId);
        }

        if (!Auth::isSuperAdmin() && Auth::tenantId() === $tenantId) {
            Auth::refreshUser();
        }

        Audit::log('company.updated', ['company_name' => $name, 'profile_enriched' => !Auth::isSuperAdmin()], $tenantId);
        Flash::set('success', 'Dados da empresa atualizados. As novas informações já podem ser usadas pelos assistentes.');
        $this->redirect('/company-settings' . (Auth::isSuperAdmin() ? '?id=' . $tenantId : ''));
    }

    public function updateLifecycle(): void
    {
        $tenantId = (int) ($_POST['tenant_id'] ?? 0);
        $target = trim((string) ($_POST['lifecycle_status'] ?? ''));
        $note = trim((string) ($_POST['note'] ?? ''));
        $returnTo = trim((string) ($_POST['return_to'] ?? '/companies'));
        if (!str_starts_with($returnTo, '/companies')) {
            $returnTo = '/companies';
        }

        if ($tenantId < 1 || !array_key_exists($target, TenantLifecycleService::statuses())) {
            Flash::set('error', 'Empresa ou estágio operacional inválido.');
            $this->redirect($returnTo);
        }

        try {
            $result = (new TenantLifecycleService())->transition($tenantId, $target, $note);
            $message = match ($target) {
                TenantLifecycleService::READY => 'Empresa marcada como pronta para produção. As métricas oficiais continuam pausadas até o Go-Live.',
                TenantLifecycleService::LIVE => 'Go-Live confirmado. SLA, métricas oficiais e cobranças manuais de produção estão liberados a partir de agora.',
                TenantLifecycleService::SUSPENDED => 'Operação produtiva suspensa. O histórico anterior foi preservado e novas métricas oficiais ficam pausadas.',
                default => 'Empresa retornou para onboarding/homologação. Métricas oficiais ficam pausadas.',
            };
            if (($result['from_status'] ?? '') === TenantLifecycleService::LIVE && $target === TenantLifecycleService::READY) {
                $message = 'Empresa retornou para homologação. O histórico de produção anterior foi preservado e novas métricas oficiais ficam pausadas.';
            }
            Flash::set('success', $message);
        } catch (Throwable $exception) {
            Flash::set('error', $exception->getMessage());
        }

        $this->redirect($returnTo);
    }

    public function updateTracking(): void
    {
        $tenantId = (int) ($_POST['tenant_id'] ?? 0);
        $trackingStatus = trim((string) ($_POST['tracking_status'] ?? 'automatic'));
        $priority = trim((string) ($_POST['priority'] ?? 'attention'));
        $note = trim((string) ($_POST['note'] ?? ''));

        if ($tenantId < 1
            || !in_array($trackingStatus, ['automatic', 'attention', 'reviewed', 'resolved'], true)
            || !in_array($priority, ['attention', 'critical', 'implantation'], true)) {
            Flash::set('error', 'Não foi possível atualizar o acompanhamento da empresa.');
            $this->redirect('/companies');
        }

        $pdo = Database::connection();
        $company = $pdo->prepare('SELECT id, name FROM tenants WHERE id = :id LIMIT 1');
        $company->execute(['id' => $tenantId]);
        $tenant = $company->fetch(PDO::FETCH_ASSOC);
        if (!$tenant) {
            Flash::set('error', 'Empresa não encontrada.');
            $this->redirect('/companies');
        }

        try {
            $acknowledgedAt = in_array($trackingStatus, ['reviewed', 'resolved'], true) ? \App\Core\Clock::nowUtc() : null;
            $resolvedAt = $trackingStatus === 'resolved' ? \App\Core\Clock::nowUtc() : null;
            if ($trackingStatus === 'automatic') {
                $note = '';
                $acknowledgedAt = null;
                $resolvedAt = null;
            }

            $statement = $pdo->prepare(
                'INSERT INTO tenant_admin_tracking
                    (tenant_id, tracking_status, priority, note, acknowledged_at, resolved_at, updated_by)
                 VALUES
                    (:tenant_id, :tracking_status, :priority, :note, :acknowledged_at, :resolved_at, :updated_by)
                 ON DUPLICATE KEY UPDATE
                    tracking_status = VALUES(tracking_status),
                    priority = VALUES(priority),
                    note = VALUES(note),
                    acknowledged_at = VALUES(acknowledged_at),
                    resolved_at = VALUES(resolved_at),
                    updated_by = VALUES(updated_by)'
            );
            $statement->execute([
                'tenant_id' => $tenantId,
                'tracking_status' => $trackingStatus,
                'priority' => $priority,
                'note' => $note !== '' ? $note : null,
                'acknowledged_at' => $acknowledgedAt,
                'resolved_at' => $resolvedAt,
                'updated_by' => Auth::id(),
            ]);

            $action = match ($trackingStatus) {
                'attention' => 'company.attention_marked',
                'reviewed' => 'company.attention_reviewed',
                'resolved' => 'company.attention_resolved',
                default => 'company.attention_reset',
            };
            Audit::log($action, [
                'company_name' => (string) ($tenant['name'] ?? ''),
                'tracking_status' => $trackingStatus,
                'priority' => $priority,
                'note' => $note,
            ], $tenantId);

            $message = match ($trackingStatus) {
                'attention' => 'Empresa marcada para atenção.',
                'reviewed' => 'Pendência marcada como visualizada e em acompanhamento.',
                'resolved' => 'Pendência marcada como corrigida. Falhas antigas foram reconhecidas.',
                default => 'Classificação automática restaurada.',
            };
            Flash::set('success', $message);
        } catch (Throwable $exception) {
            Flash::set('error', 'Não foi possível salvar o acompanhamento. Execute a migration 035 e tente novamente.');
        }

        $returnTo = trim((string) ($_POST['return_to'] ?? '/companies'));
        if (!str_starts_with($returnTo, '/companies')) {
            $returnTo = '/companies';
        }
        $this->redirect($returnTo);
    }

    public function updateStatus(): void
    {
        $tenantId = (int) ($_POST['tenant_id'] ?? 0);
        $status = (string) ($_POST['status'] ?? 'active');
        $plan = (string) ($_POST['plan'] ?? 'starter');

        if ($tenantId < 1 || !in_array($status, ['active', 'inactive', 'suspended'], true)
            || !in_array($plan, ['starter', 'pro', 'business', 'custom'], true)) {
            Flash::set('error', 'Dados de atualização inválidos.');
            $this->redirect('/companies');
        }

        $statement = Database::connection()->prepare(
            'UPDATE tenants SET status = :status, plan = :plan WHERE id = :id'
        );
        $statement->execute(['status' => $status, 'plan' => $plan, 'id' => $tenantId]);
        Audit::log('company.status_updated', ['status' => $status, 'plan' => $plan], $tenantId);
        $statusMessage = match ($status) {
            'inactive' => 'Empresa inativada. Os usuários do cliente não poderão entrar enquanto ela estiver inativa.',
            'suspended' => 'Empresa suspensa. Revise cobrança e acesso antes de reativar.',
            default => 'Empresa ativada e plano atualizado.',
        };
        Flash::set('success', $statusMessage);
        $returnTo = trim((string) ($_POST['return_to'] ?? '/companies'));
        if (!str_starts_with($returnTo, '/companies')) {
            $returnTo = '/companies';
        }
        $this->redirect($returnTo);
    }


    private function createInitialSubscription(PDO $pdo, int $tenantId, string $planKey): void
    {
        $planStatement = $pdo->prepare('SELECT id, monthly_price FROM saas_plans WHERE plan_key = :plan_key LIMIT 1');
        $planStatement->execute(['plan_key' => $planKey]);
        $plan = $planStatement->fetch(PDO::FETCH_ASSOC);
        if (!$plan) {
            return;
        }

        $startsAt = date('Y-m-d');
        $periodEndsAt = date('Y-m-d', strtotime('+1 month -1 day'));
        $nextBillingAt = date('Y-m-d', strtotime('+1 month'));
        $statement = $pdo->prepare(
            'INSERT INTO tenant_subscriptions
                (tenant_id, plan_id, billing_cycle, billing_status, starts_at,
                 current_period_starts_at, current_period_ends_at, next_billing_at,
                 amount, notes, created_by_user_id)
             VALUES
                (:tenant_id, :plan_id, "monthly", "active", :starts_at,
                 :period_starts_at, :period_ends_at, :next_billing_at,
                 :amount, :notes, :created_by_user_id)'
        );
        $statement->execute([
            'tenant_id' => $tenantId,
            'plan_id' => $plan['id'],
            'starts_at' => $startsAt,
            'period_starts_at' => $startsAt,
            'period_ends_at' => $periodEndsAt,
            'next_billing_at' => $nextBillingAt,
            'amount' => $plan['monthly_price'] ?? 0,
            'notes' => 'Assinatura inicial criada junto com o cadastro da empresa.',
            'created_by_user_id' => Auth::id(),
        ]);
    }

    private function createDefaultPipeline(PDO $pdo, int $tenantId): void
    {
        $pipeline = $pdo->prepare(
            'INSERT INTO crm_pipelines (tenant_id, name, is_default)
             VALUES (:tenant_id, "Funil comercial", 1)'
        );
        $pipeline->execute(['tenant_id' => $tenantId]);
        $pipelineId = (int) $pdo->lastInsertId();

        $stages = [
            ['Novo', 'open', 'blue', 1, 10],
            ['Qualificação', 'open', 'cyan', 2, 25],
            ['Proposta', 'open', 'violet', 3, 50],
            ['Negociação', 'open', 'amber', 4, 75],
            ['Ganho', 'won', 'green', 5, 100],
            ['Perdido', 'lost', 'slate', 6, 0],
        ];
        $statement = $pdo->prepare(
            'INSERT INTO crm_stages
                (tenant_id, pipeline_id, name, stage_type, color_key, position, probability)
             VALUES
                (:tenant_id, :pipeline_id, :name, :stage_type, :color_key, :position, :probability)'
        );
        foreach ($stages as [$name, $type, $color, $position, $probability]) {
            $statement->execute([
                'tenant_id' => $tenantId,
                'pipeline_id' => $pipelineId,
                'name' => $name,
                'stage_type' => $type,
                'color_key' => $color,
                'position' => $position,
                'probability' => $probability,
            ]);
        }
    }

    private function requestedTenantId(): int
    {
        if (!Auth::isSuperAdmin()) {
            return (int) Auth::tenantId();
        }

        $tenantId = (int) ($_GET['id'] ?? 0);
        if ($tenantId < 1) {
            Flash::set('warning', 'Selecione uma empresa para editar.');
            $this->redirect('/companies');
        }
        return $tenantId;
    }

    private function uniqueSlug(string $name): string
    {
        $base = mb_strtolower($name);
        $base = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $base) ?: $base;
        $base = preg_replace('/[^a-z0-9]+/', '-', $base) ?: 'empresa';
        $base = trim($base, '-') ?: 'empresa';
        $slug = $base;
        $counter = 2;
        $pdo = Database::connection();

        while (true) {
            $statement = $pdo->prepare('SELECT COUNT(*) FROM tenants WHERE slug = :slug');
            $statement->execute(['slug' => $slug]);
            if ((int) $statement->fetchColumn() === 0) {
                return $slug;
            }
            $slug = $base . '-' . $counter++;
        }
    }

    private function redirect(string $path): never
    {
        header('Location: ' . Router::url($path));
        exit;
    }
}
