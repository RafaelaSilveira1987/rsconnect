<?php

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Router;
use App\Core\PublicId;
use App\Core\View;

$canManage = Auth::can('conversations.manage');
$professionalAssignmentSettings = is_array($professionalAssignmentSettings ?? null) ? $professionalAssignmentSettings : ['enabled' => false, 'lock_enabled' => true, 'auto_assign_enabled' => false];
$ownershipSnapshot = is_array($ownershipSnapshot ?? null) ? $ownershipSnapshot : ['enabled' => false, 'can_interact' => true, 'locked_by_other' => false];
$canOperateSelected = $canManage && !empty($ownershipSnapshot['can_interact']);
$conversationAgents = is_array($conversationAgents ?? null) ? $conversationAgents : [];
$internalNotes = is_array($internalNotes ?? null) ? $internalNotes : [];
$departments = is_array($departments ?? null) ? $departments : [];
$queueEnabled = !empty($queueEnabled);
$commercialRequestSettings = is_array($commercialRequestSettings ?? null) ? $commercialRequestSettings : ['ready' => false, 'enabled' => false, 'show_conversation_alert' => false];
$selectedCommercialRequest = is_array($selectedCommercialRequest ?? null) ? $selectedCommercialRequest : null;
$selectedSla = is_array($selectedSla ?? null) ? $selectedSla : null;
$slaSettings = is_array($slaSettings ?? null) ? $slaSettings : ['target_minutes' => 30, 'warning_percent' => 80, 'count_outside_business_hours' => 0];
$formatDate = static function (?string $date, string $format = 'd/m/Y H:i'): string {
    if (!$date) {
        return '—';
    }
    return \App\Core\Clock::formatUtc($date, $format);
};
$modeLabel = ['ai' => 'IA ativa', 'human' => 'Humano', 'paused' => 'IA pausada'];
$statusLabel = ['open' => 'Aberta', 'pending' => 'Pendente', 'closed' => 'Encerrada'];
$messageStatusLabels = [
    'pending' => 'pendente',
    'sent' => 'enviada',
    'delivered' => 'entregue',
    'read' => 'lida',
    'failed' => 'falhou',
    'received' => 'recebida',
    'cancelled' => 'cancelada',
];
$afterHoursStatusLabels = [
    'pending' => 'Aguardando horário',
    'processing' => 'Retomando agora',
    'blocked_plan' => 'Aguardando franquia',
    'blocked_human' => 'Aguardando equipe',
    'error' => 'Nova tentativa programada',
];
$afterHoursStatusClasses = [
    'pending' => 'is-waiting',
    'processing' => 'is-processing',
    'blocked_plan' => 'is-blocked',
    'blocked_human' => 'is-human',
    'error' => 'is-error',
];
$normalizeStatus = static fn (?string $status): string => in_array($status, ['open', 'pending', 'closed'], true) ? (string) $status : 'open';
$contactGroupLabels = \App\Services\ConversationFlowService::GROUPS;
$contactStatusLabels = \App\Services\ConversationFlowService::STATUS_LABELS;
$relationshipService = new \App\Services\ConversationFlowService();
$selectedRelationship = $selected ? $relationshipService->relationshipProfile($selected) : null;
$flowStageLabels = \App\Services\ConversationFlowService::STAGES;
$demandStatusLabels = \App\Services\ConversationFlowService::DEMAND_STATUSES;
$contactLabel = static function (array $row): string {
    $name = trim((string) ($row['contact_name'] ?? ''));
    $phone = trim((string) ($row['phone'] ?? ''));
    return $name !== '' ? $name : ($phone !== '' ? $phone : 'Contato sem identificação');
};
$contactInitial = static function (array $row) use ($contactLabel): string {
    $label = $contactLabel($row);
    $initial = mb_substr($label, 0, 1);
    return $initial !== '' ? mb_strtoupper($initial) : '?';
};
$contactAvatarUrl = static function (array $row): string {
    $url = trim((string) ($row['avatar_url'] ?? ''));
    return $url !== '' && preg_match('#^https?://#i', $url) ? $url : '';
};
$currentQuery = array_filter([
    'search' => $filters['search'] ?? '',
    'status' => $filters['status'] ?? '',
    'mode' => $filters['mode'] ?? '',
    'instance_id' => $filters['instance_id'] ?? 0,
    'tenant_id' => $filters['tenant_id'] ?? 0,
    'intent' => $filters['intent'] ?? '',
    'queue' => $filters['queue'] ?? '',
], static fn ($value) => $value !== '' && $value !== 0 && $value !== 'tenant');
$lastMessageId = 0;
foreach ($messages as $message) {
    $lastMessageId = max($lastMessageId, (int) ($message['id'] ?? 0));
}
$pollQuery = $currentQuery;
if ($selected) {
    $pollQuery['conversation_id'] = (int) $selected['id'];
}
$returnQuery = http_build_query($pollQuery);
$publicPollQuery = (string) (parse_url(Router::url('/conversations?' . http_build_query($pollQuery)), PHP_URL_QUERY) ?? '');
$selectedConversationPublicId = $selected ? PublicId::encode('conversation', (int) $selected['id']) : '';
$afterHoursQueueCount = count(array_filter($conversations, static fn (array $conversation): bool => trim((string) ($conversation['after_hours_status'] ?? '')) !== ''));
$quotePendingQueueCount = count(array_filter($conversations, static fn (array $conversation): bool => (int) ($conversation['commercial_request_id'] ?? 0) > 0));
$slaRiskCount = count(array_filter($conversations, static function (array $conversation): bool {
    $sla = $conversation['sla'] ?? null;
    return is_array($sla) && empty($sla['responded']) && in_array((string) ($sla['status'] ?? ''), ['warning', 'breached'], true);
}));
?>

<form class="conversation-filters card" method="get" action="<?= View::e(Router::url('/conversations')) ?>">
    <?php if (($filters['intent'] ?? '') === 'agenda'): ?><input type="hidden" name="intent" value="agenda"><?php endif; ?>
    <div class="filter-search">
        <span class="search-icon" aria-hidden="true"></span>
        <input name="search" data-conversation-search autocomplete="off" value="<?= View::e($filters['search'] ?? '') ?>" placeholder="Buscar por nome, telefone ou mensagem">
    </div>

    <?php if (Auth::isSuperAdmin()): ?>
        <select name="tenant_id" aria-label="Filtrar por empresa">
            <option value="">Selecione uma empresa</option>
            <?php foreach ($tenants as $tenant): ?>
                <option value="<?= (int) $tenant['id'] ?>" <?= (int) ($filters['tenant_id'] ?? 0) === (int) $tenant['id'] ? 'selected' : '' ?>><?= View::e($tenant['name']) ?></option>
            <?php endforeach; ?>
        </select>
    <?php endif; ?>

    <select name="instance_id" aria-label="Filtrar por conexão do WhatsApp">
        <option value="">Todas as conexões</option>
        <?php foreach ($instances as $instance): ?>
            <?php
            if (Auth::isSuperAdmin() && (int) ($filters['tenant_id'] ?? 0) < 1) continue;
            if (Auth::isSuperAdmin() && (int) $instance['tenant_id'] !== (int) ($filters['tenant_id'] ?? 0)) continue;
            ?>
            <option value="<?= (int) $instance['id'] ?>" <?= (int) ($filters['instance_id'] ?? 0) === (int) $instance['id'] ? 'selected' : '' ?>><?= View::e($instance['name']) ?></option>
        <?php endforeach; ?>
    </select>

    <select name="status" aria-label="Filtrar por status">
        <option value="">Todos os status</option>
        <?php foreach ($statusLabel as $value => $label): ?>
            <option value="<?= View::e($value) ?>" <?= ($filters['status'] ?? '') === $value ? 'selected' : '' ?>><?= View::e($label) ?></option>
        <?php endforeach; ?>
    </select>

    <select name="mode" aria-label="Filtrar por atendimento">
        <option value="">Todos os modos</option>
        <?php foreach ($modeLabel as $value => $label): ?>
            <option value="<?= View::e($value) ?>" <?= ($filters['mode'] ?? '') === $value ? 'selected' : '' ?>><?= View::e($label) ?></option>
        <?php endforeach; ?>
    </select>

    <select name="queue" aria-label="Filtrar por fila operacional">
        <option value="">Todas as filas</option>
        <option value="after_hours" <?= ($filters['queue'] ?? '') === 'after_hours' ? 'selected' : '' ?>>Aguardando horário<?= $afterHoursQueueCount > 0 ? ' (' . $afterHoursQueueCount . ')' : '' ?></option>
        <option value="quote_pending" <?= ($filters['queue'] ?? '') === 'quote_pending' ? 'selected' : '' ?>>Orçamentos pendentes<?= $quotePendingQueueCount > 0 ? ' (' . $quotePendingQueueCount . ')' : '' ?></option>
    </select>

    <?php if (($filters['intent'] ?? '') === 'agenda'): ?><span class="badge badge-info">Intenção de agenda</span><?php endif; ?>
    <button class="btn btn-secondary" type="submit">Filtrar</button>
    <a class="btn btn-outline" href="<?= View::e(Router::url('/conversations')) ?>">Limpar</a>
</form>

<div class="conversation-workspace" data-conversation-realtime data-poll-url="<?= View::e(Router::url('/conversations/poll')) ?>" data-avatar-url="<?= View::e(Router::url('/conversations/avatar')) ?>" data-current-query="<?= View::e($publicPollQuery) ?>" data-conversation-id="<?= (int) ($selected['id'] ?? 0) ?>" data-conversation-public-id="<?= View::e($selectedConversationPublicId) ?>" data-last-message-id="<?= (int) $lastMessageId ?>" data-base-title="<?= View::e($title ?? 'Conversas') ?>">
    <div class="realtime-toast" data-realtime-toast hidden></div>
    <?php if ($canManage): ?>
        <div class="new-conversation-shell" data-new-conversation-shell hidden>
            <button class="new-conversation-backdrop" type="button" data-new-conversation-close aria-label="Fechar novo atendimento"></button>
            <section class="new-conversation-drawer" id="new-conversation-drawer" role="dialog" aria-modal="true" aria-labelledby="new-conversation-title">
                <form class="new-conversation-form" method="post" action="<?= View::e(Router::url('/conversations/start')) ?>" data-new-conversation-form data-contact-lookup-url="<?= View::e(Router::url('/conversations/contact-lookup')) ?>">
                    <?= Csrf::input() ?>
                    <div class="new-conversation-form-head">
                        <div>
                            <span><span class="eyebrow">Novo atendimento</span><strong id="new-conversation-title">Iniciar conversa</strong></span>
                            <button class="drawer-close new-conversation-close" type="button" data-new-conversation-close aria-label="Fechar novo atendimento" title="Fechar">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>
                            </button>
                        </div>
                        <small>Pesquise um contato já cadastrado ou informe um novo número. A Caixa de Entrada permanece no mesmo ponto enquanto você inicia o atendimento.</small>
                    </div>
                    <div class="new-conversation-form-body">
                        <label class="field"><span>Conexão de WhatsApp</span>
                            <select name="instance_id" required data-new-conversation-instance>
                                <option value="">Selecione</option>
                                <?php foreach ($instances as $instance): ?>
                                    <?php
                                    if (Auth::isSuperAdmin() && (int) ($filters['tenant_id'] ?? 0) < 1) continue;
                                    if (Auth::isSuperAdmin() && (int) $instance['tenant_id'] !== (int) ($filters['tenant_id'] ?? 0)) continue;
                                    ?>
                                    <option value="<?= (int) $instance['id'] ?>"><?= View::e((Auth::isSuperAdmin() ? ($instance['tenant_name'] ?? '') . ' — ' : '') . $instance['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <label class="field new-conversation-contact-search"><span>Buscar contato</span><input type="search" autocomplete="off" placeholder="Nome ou telefone" data-new-conversation-search><small class="field-hint-inline">A busca consulta os contatos da empresa antes de iniciar um novo atendimento.</small></label>
                        <div class="new-conversation-search-results" data-new-conversation-results hidden></div>
                        <div class="new-conversation-field-grid">
                            <label class="field"><span>Telefone com DDI</span><input name="phone" inputmode="tel" autocomplete="off" placeholder="5511999999999" required data-new-conversation-phone></label>
                            <label class="field"><span>Nome do contato</span><input name="name" autocomplete="off" placeholder="Opcional" data-new-conversation-name></label>
                        </div>
                        <div class="new-conversation-existing" data-new-conversation-existing hidden></div>
                        <label class="field"><span>Primeira mensagem</span><textarea name="message" rows="4" required>Olá! Como podemos ajudar?</textarea></label>
                    </div>
                    <div class="new-conversation-actions">
                        <button class="btn btn-outline" type="button" data-new-conversation-close>Cancelar</button>
                        <button class="btn btn-primary" type="submit" <?= !$instances ? 'disabled' : '' ?>>Enviar e abrir conversa</button>
                    </div>
                </form>
            </section>
        </div>
    <?php endif; ?>
    <aside class="conversation-inbox card">
        <div class="conversation-panel-heading">
            <div>
                <span class="eyebrow">Caixa de entrada</span>
                <h2>Conversas</h2>
            </div>
            <div class="conversation-heading-actions">
                <?php $afterHoursFilterQuery = $currentQuery; $afterHoursFilterQuery['queue'] = 'after_hours'; unset($afterHoursFilterQuery['conversation_id']); ?>
                <a class="conversation-queue-filter<?= ($filters['queue'] ?? '') === 'after_hours' ? ' is-active' : '' ?>" data-after-hours-queue-count href="<?= View::e(Router::url('/conversations?' . http_build_query($afterHoursFilterQuery))) ?>" title="Mostrar somente mensagens aguardando o próximo horário" <?= $afterHoursQueueCount > 0 ? '' : 'hidden' ?>>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                    <span><?= (int) $afterHoursQueueCount ?></span>
                </a>
                <?php $quoteFilterQuery = $currentQuery; $quoteFilterQuery['queue'] = 'quote_pending'; unset($quoteFilterQuery['conversation_id']); ?>
                <a class="conversation-queue-filter is-quote<?= ($filters['queue'] ?? '') === 'quote_pending' ? ' is-active' : '' ?>" data-quote-pending-count href="<?= View::e(Router::url('/conversations?' . http_build_query($quoteFilterQuery))) ?>" title="Mostrar somente solicitações de orçamento pendentes" <?= $quotePendingQueueCount > 0 ? '' : 'hidden' ?>>
                    <span class="quote-pending-icon" aria-hidden="true">$</span>
                    <span><?= (int) $quotePendingQueueCount ?></span>
                </a>
                <span class="conversation-sla-risk-counter" data-sla-risk-count title="Conversas com SLA em atenção ou violado" <?= $slaRiskCount > 0 ? '' : 'hidden' ?>><span aria-hidden="true">!</span><strong><?= (int) $slaRiskCount ?></strong><small>SLA</small></span>
                <span class="badge" data-conversation-count><?= count($conversations) ?></span>
                <?php if ($canManage && $conversations): ?>
                    <button class="btn btn-outline btn-small conversation-select-toggle" type="button" data-toggle-bulk-read aria-expanded="false" aria-controls="conversation-bulk-read-form">
                        <svg class="button-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="m14.5 17 2 2 4-5"/></svg>
                        <span data-bulk-toggle-label>Selecionar</span>
                    </button>
                <?php endif; ?>
                <?php if ($canManage): ?>
                    <button class="btn btn-primary btn-small" type="button" data-new-conversation-open aria-haspopup="dialog" aria-controls="new-conversation-drawer">+ Nova</button>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($canManage && $conversations): ?>
            <form id="conversation-bulk-read-form" class="conversation-bulk-toolbar" method="post" action="<?= View::e(Router::url('/conversations/mark-read')) ?>" data-bulk-read-form hidden>
                <?= Csrf::input() ?>
                <input type="hidden" name="tenant_id" value="<?= (int) ($filters['tenant_id'] ?? Auth::tenantId() ?? 0) ?>">
                <input type="hidden" name="return_query" value="<?= View::e($returnQuery) ?>">

                <div class="conversation-bulk-summary">
                    <label class="conversation-select-all">
                        <input type="checkbox" data-select-all-conversations>
                        <span class="conversation-checkbox-ui" aria-hidden="true"></span>
                        <span>Selecionar todas</span>
                    </label>
                    <span class="conversation-selection-count" data-selection-count role="status" aria-live="polite">0 selecionadas</span>
                </div>

                <div class="conversation-bulk-actions">
                    <button class="btn btn-primary btn-small conversation-bulk-action" type="submit" data-mark-read-button disabled>
                        <svg class="button-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 12 5 5L20 6"/></svg>
                        <span class="label-full">Marcar como lidas</span><span class="label-compact">Marcar lidas</span>
                    </button>
                    <button class="btn btn-danger btn-small conversation-bulk-action" type="submit" formaction="<?= View::e(Router::url('/conversations/delete')) ?>" data-delete-conversations-button disabled>
                        <svg class="button-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/></svg>
                        <span class="label-full">Excluir selecionadas</span><span class="label-compact">Excluir</span>
                    </button>
                    <button class="conversation-bulk-cancel" type="button" data-cancel-bulk-select aria-label="Cancelar seleção" title="Cancelar seleção">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>
                    </button>
                </div>
                <small class="conversation-bulk-help">As ações serão aplicadas somente às conversas selecionadas.</small>
            </form>
        <?php endif; ?>

        <div class="conversation-list" data-conversation-list>
            <?php foreach ($conversations as $conversation): ?>
                <?php
                $query = $currentQuery;
                $query['conversation_id'] = (int) $conversation['id'];
                $isSelected = (int) ($selected['id'] ?? 0) === (int) $conversation['id'];
                $displayName = $contactLabel($conversation);
                $initial = $contactInitial($conversation);
                $avatarUrl = $contactAvatarUrl($conversation);
                $conversationPublicId = PublicId::encode('conversation', (int) $conversation['id']);
                $conversationStatus = $normalizeStatus((string) ($conversation['status'] ?? 'open'));
                $afterHoursStatus = trim((string) ($conversation['after_hours_status'] ?? ''));
                $afterHoursCount = max(1, (int) ($conversation['after_hours_message_count'] ?? 0));
                $afterHoursClass = $afterHoursStatusClasses[$afterHoursStatus] ?? 'is-waiting';
                $afterHoursLabel = $afterHoursStatusLabels[$afterHoursStatus] ?? 'Aguardando horário';
                $hasQuotePending = (int) ($conversation['commercial_request_id'] ?? 0) > 0;
                $quoteDueAt = trim((string) ($conversation['commercial_request_due_at'] ?? ''));
                $conversationSla = is_array($conversation['sla'] ?? null) ? $conversation['sla'] : null;
                $slaPendingStatus = $conversationSla && empty($conversationSla['responded']) ? (string) ($conversationSla['status'] ?? '') : '';
                $hasSlaAlert = in_array($slaPendingStatus, ['warning', 'breached'], true);
                ?>
                <div class="conversation-list-row status-<?= View::e($conversationStatus) ?><?= (int) $conversation['unread_count'] > 0 ? ' has-unread' : '' ?><?= $afterHoursStatus !== '' ? ' has-after-hours-queue' : '' ?><?= $hasQuotePending ? ' has-quote-pending' : '' ?><?= $hasSlaAlert ? ' has-sla-' . View::e($slaPendingStatus) : '' ?>" data-conversation-row data-conversation-id="<?= (int) $conversation['id'] ?>" data-conversation-public-id="<?= View::e($conversationPublicId) ?>" data-conversation-status="<?= View::e($conversationStatus) ?>" data-after-hours-status="<?= View::e($afterHoursStatus) ?>">
                    <?php if ($canManage): ?>
                        <label class="conversation-select-control" title="Selecionar <?= View::e($displayName) ?>">
                            <input type="checkbox" name="conversation_ids[]" value="<?= (int) $conversation['id'] ?>" form="conversation-bulk-read-form" data-conversation-select aria-label="Selecionar conversa de <?= View::e($displayName) ?>">
                            <span aria-hidden="true"></span>
                        </label>
                    <?php endif; ?>
                    <a class="conversation-list-item<?= $isSelected ? ' is-selected' : '' ?>" data-conversation-item data-conversation-id="<?= (int) $conversation['id'] ?>" data-conversation-public-id="<?= View::e($conversationPublicId) ?>" href="<?= View::e(Router::url('/conversations?' . http_build_query($query))) ?>">
                    <span class="conversation-avatar" data-contact-avatar-container data-avatar-resolved="<?= array_key_exists('avatar_url', $conversation) && $conversation['avatar_url'] !== null ? '1' : '0' ?>">
                        <span class="conversation-avatar-fallback" data-avatar-fallback><?= View::e($initial) ?></span>
                        <?php if ($avatarUrl !== ''): ?><img class="conversation-avatar-image" data-contact-avatar src="<?= View::e($avatarUrl) ?>" alt="" loading="lazy" referrerpolicy="no-referrer"><?php endif; ?>
                    </span>
                    <span class="conversation-summary">
                        <span class="conversation-title-row">
                            <strong data-conversation-name><?= View::e($displayName) ?></strong>
                            <time data-conversation-time><?= View::e($formatDate($conversation['last_message_at'], 'd/m H:i')) ?></time>
                        </span>
                        <span class="conversation-preview" data-conversation-preview><?= View::e($conversation['last_message_preview'] ?: 'Sem mensagens') ?></span>
                        <span class="conversation-queue-slot" data-after-hours-list-slot>
                            <?php if ($hasSlaAlert): ?>
                                <span class="conversation-queue-state is-sla-<?= View::e($slaPendingStatus) ?>" data-sla-list-state>
                                    <span class="sla-alert-symbol" aria-hidden="true">!</span>
                                    <span><strong><?= $slaPendingStatus === 'breached' ? 'SLA violado' : 'SLA em risco' ?></strong><small><?= number_format((float) ($conversationSla['percent'] ?? 0), 0, ',', '.') ?>% da meta · <?= (int) ($conversationSla['target_minutes'] ?? 30) ?> min</small></span>
                                </span>
                            <?php endif; ?>
                            <?php if ($afterHoursStatus !== ''): ?>
                                <span class="conversation-queue-state <?= View::e($afterHoursClass) ?>" data-after-hours-list-state>
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                                    <span><strong><?= View::e($afterHoursLabel) ?></strong><small><?= $afterHoursCount ?> <?= $afterHoursCount === 1 ? 'mensagem preservada' : 'mensagens preservadas' ?></small></span>
                                </span>
                            <?php endif; ?>
                            <?php if ($hasQuotePending): ?>
                                <span class="conversation-queue-state is-quote-pending">
                                    <span class="quote-pending-icon" aria-hidden="true">$</span>
                                    <span><strong>Orçamento pendente</strong><small><?= $quoteDueAt !== '' ? 'Retorno até ' . View::e($formatDate($quoteDueAt, 'd/m H:i')) : 'Equipe precisa retornar' ?></small></span>
                                </span>
                            <?php endif; ?>
                        </span>
                        <span class="conversation-meta-row">
                            <span class="mini-badge mode-<?= View::e($conversation['attendance_mode']) ?>"><?= View::e($modeLabel[$conversation['attendance_mode']] ?? $conversation['attendance_mode']) ?></span>
                            <span class="mini-badge conversation-status-badge status-<?= View::e($conversationStatus) ?>" data-conversation-list-status><?= View::e($statusLabel[$conversationStatus]) ?></span>
                            <?php if ($queueEnabled && !empty($conversation['department_name'])): ?><span class="mini-badge conversation-department-badge" data-conversation-department><?= View::e($conversation['department_name']) ?></span><?php endif; ?>
                            <?php if (Auth::isSuperAdmin()): ?><small><?= View::e($conversation['tenant_name']) ?></small><?php endif; ?>
                            <b class="unread-count" data-unread-count <?= (int) $conversation['unread_count'] > 0 ? '' : 'hidden' ?>><?= (int) $conversation['unread_count'] ?></b>
                        </span>
                    </span>
                    </a>
                </div>
            <?php endforeach; ?>
            <?php if (!$conversations): ?>
                <div class="empty-state conversation-empty">
                    <?php if (Auth::isSuperAdmin() && (int) ($filters['tenant_id'] ?? 0) < 1): ?>
                        <strong>Selecione uma empresa.</strong>
                        <span>Por segurança, o Super Admin não carrega conversas de todos os clientes automaticamente.</span>
                    <?php else: ?>
                        <strong>Nenhuma conversa encontrada.</strong>
                        <span>Ative o recebimento automático da conexão do WhatsApp para que as mensagens apareçam aqui.</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </aside>

    <?php $selectedStatus = $selected ? $normalizeStatus((string) ($selected['status'] ?? 'open')) : ''; ?>
    <section class="conversation-chat card<?= $selectedStatus !== '' ? ' conversation-status-' . View::e($selectedStatus) : '' ?>" data-selected-conversation-panel data-conversation-status="<?= View::e($selectedStatus) ?>">
        <?php if ($selected): ?>
            <header class="chat-header">
                <div class="chat-contact-title">
                    <?php $selectedAvatarUrl = $contactAvatarUrl($selected); ?>
                    <span class="conversation-avatar large" data-contact-avatar-container data-avatar-resolved="<?= array_key_exists('avatar_url', $selected) && $selected['avatar_url'] !== null ? '1' : '0' ?>">
                        <span class="conversation-avatar-fallback" data-avatar-fallback><?= View::e($contactInitial($selected)) ?></span>
                        <?php if ($selectedAvatarUrl !== ''): ?><img class="conversation-avatar-image" data-contact-avatar src="<?= View::e($selectedAvatarUrl) ?>" alt="" referrerpolicy="no-referrer"><?php endif; ?>
                    </span>
                    <div>
                        <h2><?= View::e($contactLabel($selected)) ?></h2>
                        <p><?= View::e($selected['phone']) ?> · <?= View::e($selected['instance_label']) ?></p>
                    </div>
                </div>

                <?php if ($canOperateSelected): ?>
                    <div class="chat-actions">
                        <button class="btn btn-outline btn-small" type="button" data-toggle-panel="conversation-details">Dados da conversa</button>
                        <form method="post" action="<?= View::e(Router::url('/conversations/mode')) ?>" data-mode-action="human" <?= $selected['attendance_mode'] === 'human' ? 'hidden' : '' ?>>
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="mode" value="human">
                            <button class="btn btn-primary btn-small" type="submit">Assumir atendimento</button>
                        </form>
                        <form method="post" action="<?= View::e(Router::url('/conversations/mode')) ?>" data-mode-action="paused" <?= $selected['attendance_mode'] === 'ai' ? '' : 'hidden' ?>>
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="mode" value="paused">
                            <button class="btn btn-outline btn-small" type="submit">Pausar IA</button>
                        </form>
                        <form method="post" action="<?= View::e(Router::url('/conversations/mode')) ?>" data-mode-action="ai" <?= $selected['attendance_mode'] !== 'ai' ? '' : 'hidden' ?>>
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="mode" value="ai">
                            <button class="btn btn-outline btn-small" type="submit">Devolver para IA</button>
                        </form>
                        <form method="post" action="<?= View::e(Router::url('/conversations/suggest')) ?>">
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                            <button class="btn btn-outline btn-small" type="submit">Gerar sugestão</button>
                        </form>
                        <form method="post" action="<?= View::e(Router::url('/conversations/reprocess-ai')) ?>">
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                            <button class="btn btn-ghost btn-small" type="submit">Reprocessar IA</button>
                        </form>
                        <?php if (Auth::isSuperAdmin()): ?>
                            <a class="btn btn-ghost btn-small" href="<?= View::e(Router::url('/agent-tests?tenant_id=' . (int) $selected['tenant_id'] . '&conversation_id=' . (int) $selected['id'])) ?>">Transformar em teste</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </header>

            <div class="chat-state-bar">
                <span class="badge badge-<?= View::e($selectedStatus) ?>" data-conversation-status-badge><?= View::e($statusLabel[$selectedStatus]) ?></span>
                <span class="mini-badge mode-<?= View::e($selected['attendance_mode']) ?>"><?= View::e($modeLabel[$selected['attendance_mode']] ?? $selected['attendance_mode']) ?></span>
                <?php if ($selected['assigned_user_name']): ?><small>Responsável: <strong><?= View::e($selected['assigned_user_name']) ?></strong></small><?php endif; ?>
            <?php if (!empty($professionalAssignmentSettings['enabled'])): ?>
                    <small class="ownership-state <?= !empty($ownershipSnapshot['locked_by_other']) ? 'is-locked' : 'is-available' ?>">
                        <?= !empty($ownershipSnapshot['locked_by_other'])
                            ? 'Atendimento exclusivo em andamento'
                            : ((int) ($selected['assigned_user_id'] ?? 0) > 0 ? 'Responsável definido' : 'Disponível para assumir') ?>
                    </small>
                <?php endif; ?>
                <?php if (Auth::isSuperAdmin()): ?><small>Empresa: <strong><?= View::e($selected['tenant_name']) ?></strong></small><?php endif; ?>
                <span class="realtime-status" data-realtime-status>Atualização automática ativa</span>
                <?php
                $ruleHoursState = is_array($selectedRuleSnapshot['hours'] ?? null) ? $selectedRuleSnapshot['hours'] : [];
                $isOutsideConfiguredHours = !empty($ruleHoursState['enforced']) && empty($ruleHoursState['inside']);
                $hasAfterHoursPending = is_array($selectedAfterHoursPending ?? null);
                $nextOpeningRaw = trim((string) ($selectedRuleSnapshot['next_opening_at'] ?? ''));
                $selectedAfterHoursStatus = trim((string) ($selectedAfterHoursPending['status'] ?? ''));
                $selectedAfterHoursCount = max(1, (int) ($selectedAfterHoursPending['message_count'] ?? 0));
                $selectedAfterHoursClass = $afterHoursStatusClasses[$selectedAfterHoursStatus] ?? 'is-waiting';
                $selectedAfterHoursLabel = $afterHoursStatusLabels[$selectedAfterHoursStatus] ?? 'Aguardando horário';
                ?>
            <?php if ($hasAfterHoursPending): ?>
                    <span class="after-hours-state <?= View::e($selectedAfterHoursClass) ?>" title="A demanda está preservada e não será perdida.">
                        <?= View::e($selectedAfterHoursLabel) ?> · <?= $selectedAfterHoursCount ?> <?= $selectedAfterHoursCount === 1 ? 'mensagem' : 'mensagens' ?>
                    </span>
                <?php elseif ($isOutsideConfiguredHours): ?>
                    <span class="after-hours-state is-neutral">Fora do horário configurado</span>
                <?php endif; ?>
                <?php $refreshQuery = $currentQuery; $refreshQuery['conversation_id'] = (int) $selected['id']; ?>
                <a class="refresh-chat" href="<?= View::e(Router::url('/conversations?' . http_build_query($refreshQuery))) ?>">Atualizar</a>
            </div>

            <?php if ($selectedSla && empty($selectedSla['responded'])): ?>
                <?php $selectedSlaStatus = (string) ($selectedSla['status'] ?? 'normal'); ?>
                <section class="conversation-sla-banner is-<?= View::e($selectedSlaStatus) ?>" data-selected-sla-banner>
                    <div><span class="eyebrow">SLA da 1ª resposta humana</span><h3><?= $selectedSlaStatus === 'breached' ? 'Prazo violado' : ($selectedSlaStatus === 'warning' ? 'Atendimento em risco' : 'Dentro do prazo') ?></h3><p><?= number_format((float) ($selectedSla['percent'] ?? 0), 0, ',', '.') ?>% de uma meta de <?= (int) ($selectedSla['target_minutes'] ?? 30) ?> min. <?= !empty($selectedSla['count_outside_business_hours']) ? 'Relógio corrido.' : 'O relógio considera somente o expediente configurado.' ?></p></div>
                    <div class="conversation-sla-meter"><span><i style="width: <?= min(100, max(0, (float) ($selectedSla['percent'] ?? 0))) ?>%"></i></span><strong><?= $selectedSlaStatus === 'breached' ? 'Prazo excedido' : ((int) ceil(((int) ($selectedSla['remaining_seconds'] ?? 0)) / 60) . ' min restantes') ?></strong></div>
                </section>
            <?php endif; ?>

            <?php if ($hasAfterHoursPending): ?>
                <?php
                $receivedAt = trim((string) ($selectedAfterHoursPending['first_received_at'] ?? $selectedAfterHoursPending['last_received_at'] ?? ''));
                $lastReceivedAt = trim((string) ($selectedAfterHoursPending['last_received_at'] ?? ''));
                $ackSent = !empty($selectedAfterHoursPending['ack_sent_at']);
                $queueDescription = match ($selectedAfterHoursStatus) {
                    'processing' => 'A automação já iniciou a retomada desta conversa.',
                    'blocked_plan' => 'A mensagem está segura, mas a retomada automática depende da franquia de IA.',
                    'blocked_human' => (string) ($selected['attendance_mode'] ?? '') === 'human'
                        ? 'A mensagem chegou fora do horário e permanece destacada para a equipe responsável.'
                        : 'A mensagem está segura e a automação respeitará o atendimento humano ou a IA pausada.',
                    'error' => 'A mensagem está segura. O sistema fará uma nova tentativa sem duplicar respostas.',
                    default => $isOutsideConfiguredHours
                        ? 'A conversa será retomada automaticamente quando o expediente começar.'
                        : 'O expediente já abriu e esta conversa está na fila de retomada automática.',
                };
                ?>
                <section class="after-hours-queue-banner <?= View::e($selectedAfterHoursClass) ?>" data-after-hours-banner>
                    <div class="after-hours-queue-banner-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                    </div>
                    <div class="after-hours-queue-banner-content">
                        <div class="after-hours-queue-banner-head">
                            <div>
                                <span class="eyebrow">Fila fora do horário</span>
                                <h3><?= View::e($selectedAfterHoursLabel) ?></h3>
                                <p><?= View::e($queueDescription) ?></p>
                            </div>
                            <span class="after-hours-queue-count"><strong><?= $selectedAfterHoursCount ?></strong><?= $selectedAfterHoursCount === 1 ? ' mensagem' : ' mensagens' ?></span>
                        </div>
                        <div class="after-hours-queue-details">
                            <span><small>Primeiro contato</small><strong><?= View::e($receivedAt !== '' ? $formatDate($receivedAt, 'd/m H:i') : '—') ?></strong></span>
                            <span><small>Última mensagem</small><strong><?= View::e($lastReceivedAt !== '' ? $formatDate($lastReceivedAt, 'd/m H:i') : '—') ?></strong></span>
                            <span><small>Aviso de ausência</small><strong><?= $ackSent ? 'Enviado' : 'Não enviado' ?></strong></span>
                            <span><small><?= (string) ($selected['attendance_mode'] ?? '') === 'human' ? 'Próxima abertura' : 'Retomada prevista' ?></small><strong><?= View::e($nextOpeningRaw !== '' ? $formatDate($nextOpeningRaw, 'd/m H:i') : ($isOutsideConfiguredHours ? 'Próximo expediente' : 'Em processamento')) ?></strong></span>
                        </div>
                        <?php if (!empty($selectedAfterHoursPending['last_error'])): ?>
                            <div class="after-hours-queue-note is-error"><strong>Última tentativa:</strong> <?= View::e((string) $selectedAfterHoursPending['last_error']) ?></div>
                        <?php elseif ($selectedAfterHoursStatus === 'blocked_human'): ?>
                            <div class="after-hours-queue-note"><?= (string) ($selected['attendance_mode'] ?? '') === 'human'
                                ? 'A conversa já está com a equipe. A pendência será encerrada após uma resposta humana.'
                                : 'A automação só voltará a responder quando a conversa retornar ao modo IA.' ?></div>
                        <?php else: ?>
                            <div class="after-hours-queue-note">As mensagens ficam reunidas em um único atendimento e não geram custo de IA enquanto aguardam.</div>
                        <?php endif; ?>
                    </div>
                    <?php if ($canOperateSelected && (string) ($selected['attendance_mode'] ?? '') !== 'human'): ?>
                        <form class="after-hours-queue-action" method="post" action="<?= View::e(Router::url('/conversations/mode')) ?>">
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="mode" value="human">
                            <button class="btn btn-outline btn-small" type="submit">Assumir e retirar da fila</button>
                            <small>A responsabilidade passa para você e a retomada automática é cancelada.</small>
                        </form>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

        <?php if ($selectedCommercialRequest && !empty($commercialRequestSettings['enabled']) && !empty($commercialRequestSettings['show_conversation_alert'])): ?>
        <?php
            $quoteDueAt = trim((string) ($selectedCommercialRequest['due_at'] ?? ''));
            $quoteOverdue = $quoteDueAt !== '' && (strtotime($quoteDueAt) ?: PHP_INT_MAX) < time();
            $quoteLeadId = (int) ($selectedCommercialRequest['lead_id'] ?? 0);
            ?>
            <section class="commercial-request-banner<?= $quoteOverdue ? ' is-overdue' : '' ?>">
                <div class="commercial-request-banner-icon" aria-hidden="true">$</div>
                <div class="commercial-request-banner-content">
                    <span class="eyebrow">Solicitação comercial pendente</span>
                    <h3>O cliente pediu um orçamento</h3>
                    <p><?= View::e((string) ($selectedCommercialRequest['reason'] ?? 'A conversa indicou solicitação de orçamento ou proposta.')) ?></p>
                    <div class="commercial-request-banner-meta">
                        <span><small>Prazo</small><strong><?= View::e($quoteDueAt !== '' ? $formatDate($quoteDueAt, 'd/m H:i') : 'Sem prazo') ?></strong></span>
                        <span><small>Responsável</small><strong><?= View::e((string) (($selectedCommercialRequest['assigned_name'] ?? '') ?: 'Equipe comercial')) ?></strong></span>
                        <span><small>Confiança</small><strong><?= (int) round(((float) ($selectedCommercialRequest['confidence'] ?? 0)) * 100) ?>%</strong></span>
                    </div>
                    <?php if (!empty($selectedCommercialRequest['excerpt'])): ?><blockquote>“<?= View::e((string) $selectedCommercialRequest['excerpt']) ?>”</blockquote><?php endif; ?>
                </div>
                <div class="commercial-request-banner-actions">
                    <?php if ($quoteLeadId > 0 && Auth::can('crm.view')): ?><a class="btn btn-outline btn-small" href="<?= View::e(Router::url('/crm?lead_id=' . $quoteLeadId)) ?>">Abrir no Comercial</a><?php endif; ?>
                    <?php if ($canOperateSelected): ?>
                        <form method="post" action="<?= View::e(Router::url('/conversations/commercial-request/resolve')) ?>">
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="commercial_request_uuid" value="<?= View::e(PublicId::encode('commercial_request', (int) $selectedCommercialRequest['id'])) ?>"><input type="hidden" name="decision" value="resolved">
                            <button class="btn btn-primary btn-small" type="submit">Marcar orçamento atendido</button>
                        </form>
                        <form method="post" action="<?= View::e(Router::url('/conversations/commercial-request/resolve')) ?>" data-confirm="O alerta comercial será removido desta conversa sem marcar o orçamento como atendido. Você poderá continuar o atendimento normalmente." data-confirm-title="Dispensar alerta comercial?" data-confirm-action="Dispensar alerta" data-confirm-cancel="Manter alerta" data-confirm-tone="warning">
                            <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="commercial_request_uuid" value="<?= View::e(PublicId::encode('commercial_request', (int) $selectedCommercialRequest['id'])) ?>"><input type="hidden" name="decision" value="dismissed">
                            <button class="btn btn-quiet btn-small" type="submit">Dispensar alerta</button>
                        </form>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

            <?php if (!empty($professionalAssignmentSettings['enabled'])): ?>
                <?php if (!empty($ownershipSnapshot['locked_by_other'])): ?>
                    <div class="conversation-ownership-banner is-locked" data-ownership-banner>
                        <strong>Atendimento em andamento com <?= View::e($selected['assigned_user_name'] ?: 'outro profissional') ?></strong>
                        <span>Você pode acompanhar a conversa, mas não pode responder nem alterar o atendimento enquanto ela estiver aberta.</span>
                    </div>
                <?php elseif ((int) ($selected['assigned_user_id'] ?? 0) < 1 && (string) ($selected['status'] ?? '') !== 'closed'): ?>
                    <div class="conversation-ownership-banner is-available" data-ownership-banner>
                        <strong>Conversa disponível</strong>
                        <span>Ao enviar uma mensagem ou clicar em Assumir atendimento, você se torna o responsável.</span>
                    </div>
                <?php elseif ((int) ($selected['assigned_user_id'] ?? 0) === (int) (Auth::id() ?? 0)): ?>
                    <div class="conversation-ownership-banner is-mine" data-ownership-banner>
                        <strong>Você está responsável por este atendimento</strong>
                        <span>O bloqueio exclusivo está ativo. Outros usuários só podem acompanhar até a transferência, liberação ou encerramento.</span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php if (!empty($selected['last_ai_suggestion'])): ?>
                <div class="ai-suggestion-card">
                    <div>
                        <span class="eyebrow">Sugestão da IA</span>
                        <p><?= nl2br(View::e($selected['last_ai_suggestion'])) ?></p>
                        <?php if (!empty($selected['last_ai_suggestion_at'])): ?><small>Gerada em <?= View::e($formatDate($selected['last_ai_suggestion_at'])) ?></small><?php endif; ?>
                    </div>
                    <?php if ($canOperateSelected): ?>
                        <form method="post" action="<?= View::e(Router::url('/conversations/send')) ?>">
                            <?= Csrf::input() ?>
                            <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                            <input type="hidden" name="message" value="<?= View::e($selected['last_ai_suggestion']) ?>">
                            <button class="btn btn-primary btn-small" type="submit">Enviar sugestão</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="chat-thread" data-chat-thread data-last-message-id="<?= (int) $lastMessageId ?>">
                <?php foreach ($messages as $message): ?>
                    <?php $outgoing = $message['direction'] === 'outgoing'; ?>
                    <article class="message-row <?= $outgoing ? 'is-outgoing' : 'is-incoming' ?>" data-message-id="<?= (int) $message['id'] ?>">
                        <div class="message-bubble <?= $message['status'] === 'failed' ? 'has-error' : '' ?>" data-sender="<?= View::e($message['sender_type']) ?>">
                            <?php
                            $messageTypeLabel = match ((string) ($message['message_type'] ?? 'text')) {
                                'image' => 'Imagem',
                                'audio' => 'Áudio',
                                'document' => 'Documento',
                                default => ucfirst((string) ($message['message_type'] ?? 'text')),
                            };
                            ?>
                            <?php if ($message['message_type'] !== 'text'): ?><span class="message-type"><?= View::e($messageTypeLabel) ?></span><?php endif; ?>
                            <?php foreach (($message['attachments'] ?? []) as $attachment): ?>
                                <?php $attachmentStatus = (string) ($attachment['status'] ?? 'pending'); ?>
                                <div class="message-attachment kind-<?= View::e((string) ($attachment['kind'] ?? 'other')) ?> status-<?= View::e($attachmentStatus) ?>">
                                    <?php if ($attachmentStatus === 'ready' && ($attachment['kind'] ?? '') === 'image'): ?>
                                        <a class="message-attachment-image" href="<?= View::e((string) $attachment['view_url']) ?>" target="_blank" rel="noopener">
                                            <img src="<?= View::e((string) $attachment['view_url']) ?>" alt="<?= View::e((string) $attachment['name']) ?>" loading="lazy">
                                        </a>
                                    <?php elseif ($attachmentStatus === 'ready' && ($attachment['kind'] ?? '') === 'audio'): ?>
                                        <div class="message-attachment-audio">
                                            <audio controls preload="metadata" src="<?= View::e((string) $attachment['view_url']) ?>"></audio>
                                            <label>Velocidade
                                                <select data-audio-speed>
                                                    <option value="1">1x</option>
                                                    <option value="1.5">1,5x</option>
                                                    <option value="2">2x</option>
                                                </select>
                                            </label>
                                        </div>
                                    <?php endif; ?>

                                    <div class="message-attachment-info">
                                        <span class="message-attachment-icon" aria-hidden="true"><?= ($attachment['kind'] ?? '') === 'image' ? '🖼️' : (($attachment['kind'] ?? '') === 'audio' ? '🎵' : '📄') ?></span>
                                        <span><strong><?= View::e((string) $attachment['name']) ?></strong><small><?= View::e((string) $attachment['size_label']) ?></small></span>
                                        <?php if ($attachmentStatus === 'ready'): ?>
                                            <span class="message-attachment-actions">
                                                <?php if (($attachment['kind'] ?? '') === 'document'): ?><a href="<?= View::e((string) $attachment['view_url']) ?>" target="_blank" rel="noopener">Visualizar</a><?php endif; ?>
                                                <a href="<?= View::e((string) $attachment['download_url']) ?>">Baixar</a>
                                            </span>
                                        <?php else: ?>
                                            <small class="message-attachment-error"><?= View::e((string) ($attachment['error_message'] ?: 'Arquivo indisponível.')) ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <?php
                            $messageContent = !empty($message['content_purged_at']) ? 'Conteúdo removido pela política de retenção.' : trim((string) ($message['content'] ?? ''));
                            $attachmentNames = array_map(static fn (array $item): string => trim((string) ($item['name'] ?? '')), (array) ($message['attachments'] ?? []));
                            $mediaPlaceholders = ['[Imagem]', '[Áudio]', '[Documento]', '[Arquivo]', ...$attachmentNames];
                            $showMessageContent = $messageContent !== '' && (!empty($message['content_purged_at']) || !in_array($messageContent, $mediaPlaceholders, true));
                            ?>
                            <?php if ($showMessageContent): ?><p><?= nl2br(View::e($messageContent)) ?></p><?php endif; ?>
                            <?php if (!empty($message['error_message'])): ?><small class="message-error"><?= View::e($message['error_message']) ?></small><?php endif; ?>
                            <footer>
                                <?php if ($outgoing): ?>
                                    <?php $senderLabel = $message['sender_type'] === 'ai' ? ($message['sender_user_name'] ?: 'IA') : ($message['sender_user_name'] ?: 'Equipe'); ?>
                                    <?php if ($message['sender_type'] === 'user' && !empty($message['sender_user_role_label'])): $senderLabel .= ' — ' . $message['sender_user_role_label']; endif; ?>
                                    <span><?= View::e($senderLabel) ?></span>
                                <?php endif; ?>
                                <time><?= View::e($formatDate($message['sent_at'], 'd/m H:i')) ?></time>
                                <?php if ($outgoing): ?><span class="message-status"><?= View::e($messageStatusLabels[(string) ($message['status'] ?? '')] ?? (string) ($message['status'] ?? '')) ?></span><?php endif; ?>
                            </footer>
                        </div>
                    </article>
                <?php endforeach; ?>
                <?php if (!$messages): ?>
                    <div class="chat-empty"><span class="empty-symbol"></span><strong>Histórico vazio</strong><p>As novas mensagens recebidas automaticamente aparecerão aqui.</p></div>
                <?php endif; ?>
            </div>

            <?php if ($canOperateSelected): ?>
                <form class="chat-composer" id="conversation-composer" data-chat-composer method="post" enctype="multipart/form-data" action="<?= View::e(Router::url('/conversations/send')) ?>" data-attachment-action="<?= View::e(Router::url('/conversations/attachments/send')) ?>">
                    <?= Csrf::input() ?>
                    <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                    <input class="chat-attachment-input" type="file" name="attachment" data-attachment-input accept="image/jpeg,image/png,image/webp,application/pdf,audio/mpeg,audio/ogg,audio/opus,audio/mp4,.m4a" hidden>
                    <button class="chat-attachment-button" type="button" data-attachment-open aria-label="Anexar imagem, PDF ou áudio" title="Anexar imagem, PDF ou áudio">📎</button>
                    <div class="chat-composer-main">
                        <div class="chat-attachment-preview" data-attachment-preview hidden>
                            <span class="chat-attachment-preview-icon" data-attachment-preview-icon>📄</span>
                            <span><strong data-attachment-preview-name></strong><small data-attachment-preview-size></small></span>
                            <button type="button" data-attachment-remove aria-label="Remover anexo">×</button>
                        </div>
                        <textarea name="message" rows="2" maxlength="4000" placeholder="Digite uma mensagem..."></textarea>
                        <small class="chat-composer-help">Envie texto, imagem, PDF ou áudio. Limite configurado: <?= View::e((string) ($attachmentMaxLabel ?? '20 MB')) ?>.</small>
                    </div>
                    <button class="btn btn-primary" type="submit">Enviar</button>
                </form>
            <?php elseif ($canManage && !empty($ownershipSnapshot['locked_by_other'])): ?>
                <div class="chat-composer chat-composer-locked" data-chat-composer-locked>
                    <span>Conversa bloqueada para envio</span>
                    <strong><?= View::e($selected['assigned_user_name'] ?: 'Outro profissional') ?> está atendendo este cliente.</strong>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="chat-empty workspace-empty"><span class="empty-symbol"></span><strong>Selecione uma conversa</strong><p>Clique em um contato da lista para abrir o histórico. Nenhuma conversa é aberta automaticamente.</p></div>
        <?php endif; ?>
    </section>

    <aside class="conversation-details conversation-drawer card" id="conversation-details" aria-label="Dados do atendimento">
        <?php if ($selected): ?>
            <?php
            $tags = json_decode((string) ($selected['tags_json'] ?? ''), true);
            $tagText = is_array($tags) ? implode(', ', $tags) : '';
            $interestLabel = $selected['ai_interest_level'] ?? '';
            $drawerAvatarUrl = $contactAvatarUrl($selected);
            $drawerRuleSnapshot = is_array($selectedRuleSnapshot ?? null) ? $selectedRuleSnapshot : [];
            $drawerAgentName = trim((string) ($drawerRuleSnapshot['agent_name'] ?? ''));
            if ($drawerAgentName === '') {
                foreach ($conversationAgents as $routeAgent) {
                    if ((int) ($selected['ai_agent_id'] ?? 0) === (int) ($routeAgent['agent_id'] ?? 0)) {
                        $drawerAgentName = trim((string) ($routeAgent['name'] ?? ''));
                        break;
                    }
                }
            }
            $drawerStatusLabel = $statusLabel[$selectedStatus] ?? $selectedStatus;
            $drawerModeValue = (string) ($selected['attendance_mode'] ?? 'ai');
            $drawerModeLabel = $modeLabel[$drawerModeValue] ?? $drawerModeValue;
            $drawerContactStatus = (string) ($selected['contact_status'] ?? 'lead');
            $drawerContactStatusLabel = $contactStatusLabels[$drawerContactStatus] ?? $drawerContactStatus;
            $drawerGroup = (string) ($selected['contact_group'] ?? 'unclassified');
            $drawerGroupLabel = $contactGroupLabels[$drawerGroup] ?? $drawerGroup;
            $drawerRelationshipLabel = trim((string) ($selectedRelationship['label'] ?? 'Relacionamento não identificado'));
            $drawerRelationshipDescription = trim((string) ($selectedRelationship['description'] ?? ''));
            ?>
            <div class="conversation-drawer-header conversation-data-header">
                <div class="conversation-drawer-person">
                    <span class="conversation-avatar large" data-contact-avatar-container data-avatar-resolved="<?= array_key_exists('avatar_url', $selected) && $selected['avatar_url'] !== null ? '1' : '0' ?>">
                        <span class="conversation-avatar-fallback" data-avatar-fallback><?= View::e($contactInitial($selected)) ?></span>
                        <?php if ($drawerAvatarUrl !== ''): ?><img class="conversation-avatar-image" data-contact-avatar src="<?= View::e($drawerAvatarUrl) ?>" alt="" referrerpolicy="no-referrer"><?php endif; ?>
                    </span>
                    <div class="conversation-drawer-person-copy">
                        <span class="eyebrow">Atendimento</span>
                        <h2>Dados da conversa</h2>
                        <strong><?= View::e($contactLabel($selected)) ?></strong>
                        <p><span><?= View::e((string) ($selected['phone'] ?? '')) ?></span><?php if (!empty($selected['instance_label'])): ?><span aria-hidden="true">·</span><span><?= View::e((string) $selected['instance_label']) ?></span><?php endif; ?></p>
                    </div>
                </div>
                <button class="icon-button drawer-close" type="button" data-close-panel="conversation-details" aria-label="Fechar painel">×</button>
            </div>

            <div class="conversation-drawer-body conversation-data-body">
                <section class="conversation-overview-panel" id="conversation-summary" aria-label="Resumo atual da conversa">
                    <div class="conversation-overview-heading">
                        <div>
                            <span class="eyebrow">Visão rápida</span>
                            <h3>Como este atendimento está agora</h3>
                        </div>
                        <span class="conversation-overview-live">Atual</span>
                    </div>
                    <div class="conversation-overview-grid">
                        <article class="conversation-overview-item status-<?= View::e($selectedStatus) ?>">
                            <span>Situação</span>
                            <strong><?= View::e($drawerStatusLabel) ?></strong>
                            <small><?= $selectedStatus === 'closed' ? 'Ciclo encerrado' : ($selectedStatus === 'pending' ? 'Aguardando andamento' : 'Conversa em operação') ?></small>
                        </article>
                        <article class="conversation-overview-item mode-<?= View::e($drawerModeValue) ?>">
                            <span>Atendimento</span>
                            <strong><?= View::e($drawerModeLabel) ?></strong>
                            <small><?= $drawerModeValue === 'human' ? 'Equipe conduzindo' : ($drawerModeValue === 'paused' ? 'Automação em pausa' : 'Automação habilitada') ?></small>
                        </article>
                        <article class="conversation-overview-item">
                            <span>Responsável</span>
                            <strong><?= View::e((string) ($selected['assigned_user_name'] ?: 'Disponível')) ?></strong>
                            <small><?= !empty($selected['assigned_user_name']) ? 'Profissional atual' : 'Sem responsável exclusivo' ?></small>
                        </article>
                        <article class="conversation-overview-item">
                            <span>Assistente</span>
                            <strong><?= View::e($drawerAgentName !== '' ? $drawerAgentName : 'Não definido') ?></strong>
                            <small><?= $drawerAgentName !== '' ? 'Agente efetivo / vinculado' : 'Revise o roteamento deste WhatsApp' ?></small>
                        </article>
                    </div>
                    <div class="conversation-relationship-summary">
                        <div>
                            <span>Relacionamento</span>
                            <strong><?= View::e($drawerContactStatusLabel) ?> · <?= View::e($drawerGroupLabel) ?></strong>
                        </div>
                        <div>
                            <strong><?= View::e($drawerRelationshipLabel) ?></strong>
                            <?php if ($drawerRelationshipDescription !== ''): ?><small><?= View::e($drawerRelationshipDescription) ?></small><?php endif; ?>
                        </div>
                    </div>
                </section>

                <nav class="conversation-drawer-nav" aria-label="Seções dos dados da conversa">
                    <a href="#conversation-summary">Resumo</a>
                    <?php if ($queueEnabled): ?><a href="#conversation-distribution">Fila</a><?php endif; ?>
                    <?php if (!empty($professionalAssignmentSettings['enabled'])): ?><a href="#conversation-owner">Responsável</a><?php endif; ?>
                    <a href="#conversation-ai-routing">IA</a>
                    <a href="#conversation-internal-notes">Notas</a>
                    <a href="#conversation-contact-data">Contato</a>
                    <a href="#conversation-flow-data">Fluxo</a>
                    <a href="#conversation-crm">CRM</a>
                </nav>
                <?php
                $currentDepartmentId = (int) ($selected['department_id'] ?? 0);
                $currentDepartmentName = trim((string) ($selected['department_name'] ?? ''));
                $canChangeDepartment = $canManage && (
                    Auth::isSuperAdmin()
                    || Auth::role() === 'client_admin'
                    || (int) ($selected['assigned_user_id'] ?? 0) === (int) (Auth::id() ?? 0)
                );
                ?>
                <?php if ($queueEnabled): ?>
                <section class="drawer-section conversation-department-card" id="conversation-distribution">
                    <div class="drawer-section-title">
                        <div>
                            <span class="eyebrow">Distribuição</span>
                            <h3>Setor e fila</h3>
                            <small>Organize a conversa antes de definir o profissional responsável.</small>
                        </div>
                        <span class="mini-badge<?= $currentDepartmentId > 0 ? ' is-active' : '' ?>">
                            <?= View::e($currentDepartmentName !== '' ? $currentDepartmentName : 'Sem setor') ?>
                        </span>
                    </div>

                    <?php if ($canChangeDepartment && $departments): ?>
                        <form method="post" action="<?= View::e(Router::url('/conversations/department')) ?>" class="ownership-transfer-form department-transfer-form" data-confirm="Transferir esta conversa para o setor selecionado? O responsável atual será liberado e a conversa voltará para a fila do setor.">
                            <?= Csrf::input() ?>
                            <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                            <input type="hidden" name="tenant_id" value="<?= (int) $selected['tenant_id'] ?>">
                            <label class="field"><span>Transferir para setor</span><select name="department_id" required>
                                <option value="">Escolha um setor</option>
                                <?php foreach ($departments as $department): ?>
                                    <?php if ((int) ($department['id'] ?? 0) === $currentDepartmentId) continue; ?>
                                    <?php $departmentMemberCount = (int) ($department['members_count'] ?? 0); ?>
                                    <option value="<?= (int) ($department['id'] ?? 0) ?>" <?= $departmentMemberCount < 1 ? 'disabled' : '' ?>>
                                        <?= View::e((string) ($department['name'] ?? 'Setor')) ?><?= $departmentMemberCount > 0 ? ' · ' . $departmentMemberCount . ' membro(s)' : ' · configure a equipe primeiro' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select></label>
                            <button class="btn btn-outline btn-block" type="submit">Transferir para setor</button>
                            <small class="field-hint">A IA fica pausada e a conversa aguarda um profissional vinculado ao novo setor.</small>
                        </form>
                    <?php elseif ($currentDepartmentId > 0): ?>
                        <div class="message-info">Esta conversa está direcionada ao setor <?= View::e($currentDepartmentName !== '' ? $currentDepartmentName : '#' . $currentDepartmentId) ?>.</div>
                    <?php else: ?>
                        <div class="message-info">Nenhum setor foi definido para esta conversa.</div>
                    <?php endif; ?>
                </section>
                <?php endif; ?>

                <?php if (!empty($professionalAssignmentSettings['enabled'])): ?>
                    <section class="drawer-section conversation-ownership-card" id="conversation-owner">
                        <div class="drawer-section-title">
                            <div>
                                <span class="eyebrow">Responsabilidade</span>
                                <h3>Profissional da conversa</h3>
                                <small>A atribuição automática está <?= !empty($professionalAssignmentSettings['auto_assign_enabled']) ? 'ativada' : 'desativada' ?> para esta empresa.</small>
                            </div>
                        </div>
                        <div class="ownership-summary-grid">
                            <div><span>Setor atual</span><strong><?= View::e($currentDepartmentName !== '' ? $currentDepartmentName : 'Sem setor') ?></strong></div>
                            <div><span>Profissional preferido</span><strong><?= View::e($selected['preferred_user_name'] ?: 'Sem preferência') ?></strong></div>
                            <div><span>Responsável atual</span><strong><?= View::e($selected['assigned_user_name'] ?: 'Conversa disponível') ?></strong></div>
                        </div>

                        <?php if (!empty($ownershipSnapshot['can_claim'])): ?>
                            <form method="post" action="<?= View::e(Router::url('/conversations/assignment')) ?>">
                                <?= Csrf::input() ?>
                                <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                                <input type="hidden" name="tenant_id" value="<?= (int) $selected['tenant_id'] ?>">
                                <input type="hidden" name="action" value="claim">
                                <button class="btn btn-primary btn-block" type="submit">Assumir atendimento</button>
                            </form>
                        <?php endif; ?>

                        <?php if (!empty($ownershipSnapshot['can_assign'])): ?>
                            <form method="post" action="<?= View::e(Router::url('/conversations/assignment')) ?>" class="ownership-transfer-form">
                                <?= Csrf::input() ?>
                                <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                                <input type="hidden" name="tenant_id" value="<?= (int) $selected['tenant_id'] ?>">
                                <input type="hidden" name="action" value="assign">
                                <label class="field"><span>Definir responsável</span><select name="assigned_user_id" required>
                                    <option value="">Escolha um profissional</option>
                                    <?php foreach ($team as $member): ?>
                                        <option value="<?= (int) $member['id'] ?>"><?= View::e($member['name']) ?></option>
                                    <?php endforeach; ?>
                                </select></label>
                                <button class="btn btn-outline btn-block" type="submit">Atribuir conversa</button>
                            </form>
                        <?php endif; ?>

                        <?php if (!empty($ownershipSnapshot['can_transfer'])): ?>
                            <form method="post" action="<?= View::e(Router::url('/conversations/assignment')) ?>" class="ownership-transfer-form">
                                <?= Csrf::input() ?>
                                <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                                <input type="hidden" name="tenant_id" value="<?= (int) $selected['tenant_id'] ?>">
                                <input type="hidden" name="action" value="transfer">
                                <label class="field"><span>Transferir para</span><select name="assigned_user_id" required>
                                    <option value="">Escolha um profissional</option>
                                    <?php foreach ($team as $member): ?>
                                        <?php if ((int) $member['id'] === (int) ($selected['assigned_user_id'] ?? 0)) continue; ?>
                                        <option value="<?= (int) $member['id'] ?>"><?= View::e($member['name']) ?></option>
                                    <?php endforeach; ?>
                                </select></label>
                                <button class="btn btn-outline btn-block" type="submit">Transferir atendimento</button>
                            </form>
                        <?php endif; ?>

                        <?php if (!empty($ownershipSnapshot['can_release'])): ?>
                            <form method="post" action="<?= View::e(Router::url('/conversations/assignment')) ?>" data-confirm="Liberar esta conversa para que outro profissional possa assumir?">
                                <?= Csrf::input() ?>
                                <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                                <input type="hidden" name="tenant_id" value="<?= (int) $selected['tenant_id'] ?>">
                                <input type="hidden" name="action" value="release">
                                <button class="btn btn-quiet btn-block" type="submit">Liberar para a equipe</button>
                                <small class="field-hint">A conversa permanece no atendimento humano; a IA não retoma automaticamente.</small>
                            </form>
                        <?php endif; ?>

                        <?php if (!empty($ownershipSnapshot['locked_by_other'])): ?>
                            <div class="message-warning">Somente <?= View::e($selected['assigned_user_name'] ?: 'o responsável atual') ?> ou um administrador após a transferência pode alterar este atendimento.</div>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

                <?php if ($canOperateSelected): ?>
                    <section class="drawer-section drawer-status-card" id="conversation-status-control">
                        <div class="drawer-section-title">
                            <div>
                                <span class="eyebrow">Status</span>
                                <h3>Controle da conversa</h3>
                            </div>
                            <span class="mini-badge mode-<?= View::e($selected['attendance_mode']) ?>"><?= View::e($modeLabel[$selected['attendance_mode']] ?? $selected['attendance_mode']) ?></span>
                        </div>
                        <div class="status-button-grid pro-status-grid">
                            <?php foreach ($statusLabel as $value => $label): ?>
                                <form method="post" action="<?= View::e(Router::url('/conversations/status')) ?>">
                                    <?= Csrf::input() ?><input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>"><input type="hidden" name="status" value="<?= View::e($value) ?>">
                                    <button class="btn btn-small <?= $selected['status'] === $value ? 'btn-primary' : 'btn-outline' ?>" type="submit"><?= View::e($label) ?></button>
                                </form>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>

                <section class="drawer-section conversation-agent-route-card" id="conversation-ai-routing">
                    <div class="drawer-section-title">
                        <div>
                            <span class="eyebrow">Roteamento da IA</span>
                            <h3>Assistente desta conversa</h3>
                            <small>O agente escolhido permanece responsável por esta conversa até uma troca manual.</small>
                        </div>
                    </div>
                    <?php if ($conversationAgents): ?>
                        <?php if ($canOperateSelected): ?>
                            <form method="post" action="<?= View::e(Router::url('/conversations/agent')) ?>" class="conversation-agent-route-form">
                                <?= Csrf::input() ?>
                                <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                                <label class="field">
                                    <span>Agente vinculado</span>
                                    <select name="agent_id" required>
                                        <?php foreach ($conversationAgents as $routeAgent): ?>
                                            <option value="<?= (int) $routeAgent['agent_id'] ?>" <?= (int) ($selected['ai_agent_id'] ?? 0) === (int) $routeAgent['agent_id'] ? 'selected' : '' ?>>
                                                <?= View::e((string) $routeAgent['name']) ?> · <?= View::e((string) $routeAgent['segment']) ?><?= (int) ($routeAgent['is_primary'] ?? 0) === 1 ? ' · Principal' : '' ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <button class="btn btn-outline btn-small" type="submit">Trocar assistente</button>
                            </form>
                        <?php else: ?>
                            <?php
                            $currentAgentLabel = 'Não definido';
                            foreach ($conversationAgents as $routeAgent) {
                                if ((int) ($selected['ai_agent_id'] ?? 0) === (int) $routeAgent['agent_id']) {
                                    $currentAgentLabel = (string) $routeAgent['name'];
                                    break;
                                }
                            }
                            ?>
                            <strong><?= View::e($currentAgentLabel) ?></strong>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="message-warning">Nenhum assistente está vinculado a este WhatsApp. Configure em WhatsApp → Agentes e roteamento.</div>
                    <?php endif; ?>
                </section>

                <?php if (is_array($selectedRuleSnapshot ?? null)): ?>
                    <?php
                    $ruleStatusLabels = ['lead' => 'Lead', 'customer' => 'Cliente', 'inactive' => 'Inativo'];
                    $ruleModeLabels = ['ai' => 'IA ativa', 'human' => 'Humano', 'paused' => 'IA pausada'];
                    $ruleIntentLabels = [
                        'conversation' => 'Conversa geral',
                        'schedule' => 'Agendamento',
                        'reschedule' => 'Reagendamento',
                        'human_handoff' => 'Atendimento humano',
                        'quote' => 'Orçamento',
                        'quote_request' => 'Pedido de orçamento',
                        'support' => 'Suporte',
                    ];
                    $ruleHours = is_array($selectedRuleSnapshot['hours'] ?? null) ? $selectedRuleSnapshot['hours'] : [];
                    $hoursEnforced = !empty($ruleHours['enforced']);
                    $insideHours = !empty($ruleHours['inside']);
                    $ruleGroup = (string) ($selectedRuleSnapshot['contact_group'] ?? 'unclassified');
                    $ruleStage = (string) ($selectedRuleSnapshot['flow_stage'] ?? 'identifying_contact');
                    $ruleLastIntent = (string) ($selectedRuleSnapshot['last_intent'] ?? 'conversation');
                    ?>
                    <section class="drawer-section conversation-flow-card conversation-effective-rules" id="conversation-effective-rules">
                        <div class="drawer-section-title conversation-rules-heading">
                            <div>
                                <span class="eyebrow">Validação efetiva</span>
                                <h3>Regras aplicadas agora</h3>
                                <small>Resumo operacional do que realmente orienta a IA nesta conversa.</small>
                            </div>
                            <span class="mini-badge mode-<?= View::e((string) ($selectedRuleSnapshot['attendance_mode'] ?? 'ai')) ?>"><?= View::e($ruleModeLabels[(string) ($selectedRuleSnapshot['attendance_mode'] ?? '')] ?? (string) ($selectedRuleSnapshot['attendance_mode'] ?? '—')) ?></span>
                        </div>
                        <div class="conversation-rule-grid">
                            <article class="conversation-rule-item is-primary">
                                <span>Agente efetivo</span>
                                <strong><?= View::e((string) ($selectedRuleSnapshot['agent_name'] ?? 'Não definido')) ?></strong>
                                <?php if (!empty($selectedRuleSnapshot['agent_id'])): ?><small>ID <?= (int) $selectedRuleSnapshot['agent_id'] ?> · agente realmente utilizado</small><?php endif; ?>
                            </article>
                            <article class="conversation-rule-item">
                                <span>Classificação</span>
                                <strong><?= View::e($ruleStatusLabels[(string) ($selectedRuleSnapshot['contact_status'] ?? '')] ?? (string) ($selectedRuleSnapshot['contact_status'] ?? 'Não informada')) ?></strong>
                                <small>Perfil comercial atual</small>
                            </article>
                            <article class="conversation-rule-item">
                                <span>Grupo</span>
                                <strong><?= View::e($contactGroupLabels[$ruleGroup] ?? $ruleGroup) ?></strong>
                                <small>Define a tratativa do relacionamento</small>
                            </article>
                            <article class="conversation-rule-item">
                                <span>Horário operacional</span>
                                <strong><?= !$hoursEnforced ? 'Livre / 24h' : ($insideHours ? 'Dentro do expediente' : 'Fora do expediente') ?></strong>
                                <?php if ($hoursEnforced && !empty($ruleHours['current'])): ?><small>Agora: <?= View::e((string) $ruleHours['current']) ?> · <?= View::e((string) ($ruleHours['timezone'] ?? '')) ?></small><?php elseif (!$hoursEnforced): ?><small>Sem bloqueio por faixa de horário</small><?php endif; ?>
                            </article>
                            <article class="conversation-rule-item">
                                <span>Última intenção</span>
                                <strong><?= View::e($ruleIntentLabels[$ruleLastIntent] ?? $ruleLastIntent) ?></strong>
                                <small>Intenção considerada no fluxo atual</small>
                            </article>
                            <article class="conversation-rule-item">
                                <span>Etapa do fluxo</span>
                                <strong><?= View::e($flowStageLabels[$ruleStage] ?? $ruleStage) ?></strong>
                                <small>Posição atual da triagem</small>
                            </article>
                        </div>
                        <?php if ($hoursEnforced && !empty($ruleHours['ranges']) && is_array($ruleHours['ranges'])): ?>
                            <div class="conversation-rule-hours">
                                <span>Faixa aplicada</span>
                                <strong><?= View::e(implode(' / ', array_map(static fn($r) => is_array($r) ? (($r[0] ?? '') . '–' . ($r[1] ?? '')) : '', $ruleHours['ranges']))) ?></strong>
                                <?php if (!$insideHours && !empty($selectedRuleSnapshot['next_opening_at'])): ?><small>Próxima janela: <?= View::e($formatDate((string) $selectedRuleSnapshot['next_opening_at'], 'd/m H:i')) ?></small><?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div class="conversation-rule-context <?= !empty($selectedRuleSnapshot['agenda_context']) ? 'is-agenda' : 'is-general' ?>">
                            <span class="conversation-rule-context-icon" aria-hidden="true"></span>
                            <div>
                                <strong><?= !empty($selectedRuleSnapshot['agenda_context']) ? 'Contexto de agenda ativo' : 'Conversa geral' ?></strong>
                                <small><?= !empty($selectedRuleSnapshot['agenda_context'])
                                    ? 'As regras específicas de pré-agendamento estão autorizadas a entrar no contexto da IA.'
                                    : 'Menções casuais de data ou horário não iniciam a agenda automaticamente.' ?></small>
                            </div>
                        </div>
                        <?php if (!empty($selectedRuleSnapshot['tags'])): ?>
                            <div class="conversation-rule-tags">
                                <span>Tags consideradas</span>
                                <div><?php foreach ($selectedRuleSnapshot['tags'] as $ruleTag): ?><em><?= View::e((string) $ruleTag) ?></em><?php endforeach; ?></div>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

                <?php
                $internalNoteRoleLabel = static fn (string $role): string => match ($role) {
                    'super_admin' => 'Equipe RS',
                    'client_admin' => 'Administrador',
                    default => 'Equipe',
                };
                ?>
                <section class="drawer-section conversation-internal-notes-card" id="conversation-internal-notes">
                    <div class="drawer-section-title conversation-internal-notes-heading">
                        <div>
                            <span class="eyebrow">Equipe</span>
                            <h3>Notas internas da conversa</h3>
                            <small>Histórico privado para alinhamento da equipe. Não é enviado ao WhatsApp e não entra no contexto da IA.</small>
                        </div>
                        <span class="badge"><?= count($internalNotes) ?> nota(s)</span>
                    </div>

                    <?php if ($canOperateSelected): ?>
                        <form class="conversation-internal-note-form" method="post" action="<?= View::e(Router::url('/conversations/internal-notes')) ?>">
                            <?= Csrf::input() ?>
                            <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">
                            <label class="field">
                                <span>Nova nota interna</span>
                                <textarea name="note" rows="3" maxlength="4000" required placeholder="Ex.: cliente pediu retorno depois das 15h; confirmar documento com o financeiro."></textarea>
                                <small class="field-hint">Somente usuários autorizados da operação conseguem visualizar este conteúdo.</small>
                            </label>
                            <div class="conversation-internal-note-actions">
                                <span class="conversation-internal-note-private">Privado · equipe</span>
                                <button class="btn btn-primary btn-small" type="submit">Adicionar nota</button>
                            </div>
                        </form>
                    <?php elseif (!empty($ownershipSnapshot['locked_by_other'])): ?>
                        <div class="message-info">Você pode consultar as notas, mas somente o responsável atual ou um administrador pode registrar uma nova nota durante este atendimento.</div>
                    <?php endif; ?>

                    <div class="conversation-internal-note-list">
                        <?php foreach ($internalNotes as $internalNote): ?>
                            <?php
                            $internalAuthor = trim((string) ($internalNote['user_name'] ?? ''));
                            $internalRole = $internalNoteRoleLabel((string) ($internalNote['user_role'] ?? 'client_user'));
                            ?>
                            <article class="conversation-internal-note-item">
                                <header>
                                    <span class="conversation-internal-note-avatar" aria-hidden="true"><?= View::e(mb_strtoupper(mb_substr($internalAuthor !== '' ? $internalAuthor : 'E', 0, 1))) ?></span>
                                    <div>
                                        <strong><?= View::e($internalAuthor !== '' ? $internalAuthor : 'Equipe') ?></strong>
                                        <small><?= View::e($internalRole) ?> · <?= View::e($formatDate((string) ($internalNote['created_at'] ?? ''), 'd/m/Y H:i')) ?></small>
                                    </div>
                                </header>
                                <p><?= nl2br(View::e((string) ($internalNote['note'] ?? ''))) ?></p>
                            </article>
                        <?php endforeach; ?>
                        <?php if (!$internalNotes): ?>
                            <div class="conversation-internal-note-empty">
                                <strong>Nenhuma nota interna registrada</strong>
                                <span>Use este espaço para contexto operacional que não deve ser enviado ao cliente nem usado pela IA.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <form class="lead-form drawer-form" data-contact-classification-form method="post" action="<?= View::e(Router::url('/conversations/contact')) ?>">
                    <?= Csrf::input() ?>
                    <input type="hidden" name="conversation_id" value="<?= (int) $selected['id'] ?>">

                    <section class="drawer-section conversation-contact-card" id="conversation-contact-data">
                        <div class="drawer-section-title">
                            <div>
                                <span class="eyebrow">Contato</span>
                                <h3>Informações principais</h3>
                            </div>
                        </div>
                        <div class="drawer-form-grid">
                            <label class="field"><span>Nome</span><input name="name" value="<?= View::e($selected['contact_name']) ?>" <?= !$canOperateSelected ? 'readonly' : '' ?>></label>
                            <label class="field"><span>E-mail</span><input type="email" name="email" value="<?= View::e($selected['email']) ?>" <?= !$canOperateSelected ? 'readonly' : '' ?>></label>
                            <label class="field"><span>Empresa</span><input name="company" value="<?= View::e($selected['company']) ?>" <?= !$canOperateSelected ? 'readonly' : '' ?>></label>
                            <label class="field"><span>Classificação</span>
                                <select name="contact_status" data-contact-status-select <?= !$canOperateSelected ? 'disabled' : '' ?>>
                                    <?php foreach ($contactStatusLabels as $value => $label): ?>
                                        <option value="<?= View::e($value) ?>" <?= ($selected['contact_status'] ?? 'lead') === $value ? 'selected' : '' ?>><?= View::e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="field-hint">Diferencia novo contato de relacionamento já existente.</small>
                            </label>
                            <label class="field"><span>Grupo de atendimento</span>
                                <select name="contact_group" data-contact-group-select <?= !$canOperateSelected ? 'disabled' : '' ?>>
                                    <?php foreach ($contactGroupLabels as $value => $label): ?>
                                        <option value="<?= View::e($value) ?>" <?= ($selected['contact_group'] ?? 'unclassified') === $value ? 'selected' : '' ?>><?= View::e($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="field-hint">Paciente e cliente atual recebem continuidade, sem voltar à triagem de novo lead.</small>
                            </label>
                            <div class="contact-ai-context-preview drawer-span" data-contact-ai-context data-relationship="<?= View::e((string) ($selectedRelationship['key'] ?? 'unclassified')) ?>">
                                <span>Como a IA vai conduzir este contato</span>
                                <strong data-contact-ai-context-title><?= View::e((string) ($selectedRelationship['label'] ?? 'Relacionamento não identificado')) ?></strong>
                                <small data-contact-ai-context-description><?= View::e((string) ($selectedRelationship['description'] ?? '')) ?></small>
                            </div>
                        </div>
                        <label class="field drawer-span"><span>Tags separadas por vírgula</span><input name="tags" value="<?= View::e($tagText) ?>" <?= !$canOperateSelected ? 'readonly' : '' ?>></label>
                        <label class="field drawer-span"><span>Contexto do contato</span><textarea name="notes" rows="5" <?= !$canOperateSelected ? 'readonly' : '' ?>><?= View::e($selected['notes']) ?></textarea><small class="field-hint">Informação persistente do cadastro. Pode ser utilizada pela IA para dar continuidade ao relacionamento.</small></label>
                    </section>

                    <section class="drawer-section conversation-flow-card conversation-demand-card" id="conversation-flow-data">
                        <div class="drawer-section-title">
                            <div>
                                <span class="eyebrow">Fluxo do atendimento</span>
                                <h3>Etapa e demanda</h3>
                                <small>Esses dados impedem que a agenda seja aberta antes da hora e são enviados ao assistente.</small>
                            </div>
                        </div>
                        <div class="drawer-form-grid">
                            <label class="field"><span>Etapa atual</span><select name="flow_stage" <?= !$canOperateSelected ? 'disabled' : '' ?>>
                                <?php foreach ($flowStageLabels as $value => $label): ?><option value="<?= View::e($value) ?>" <?= ($selected['flow_stage'] ?? 'identifying_contact') === $value ? 'selected' : '' ?>><?= View::e($label) ?></option><?php endforeach; ?>
                            </select></label>
                            <label class="field"><span>Situação da demanda</span><select name="demand_status" <?= !$canOperateSelected ? 'disabled' : '' ?>>
                                <?php foreach ($demandStatusLabels as $value => $label): ?><option value="<?= View::e($value) ?>" <?= ($selected['demand_status'] ?? 'pending') === $value ? 'selected' : '' ?>><?= View::e($label) ?></option><?php endforeach; ?>
                            </select></label>
                        </div>
                        <label class="field drawer-span"><span>Resumo da demanda</span><textarea name="demand_summary" rows="5" <?= !$canOperateSelected ? 'readonly' : '' ?> placeholder="Registre a queixa, necessidade ou a recusa em informar."><?= View::e($selected['demand_summary'] ?? '') ?></textarea></label>
                        <?php if (($selected['demand_status'] ?? 'pending') === 'pending'): ?>
                            <div class="message-warning">O pré-agendamento automático ficará bloqueado até a demanda ser coletada, recusada ou dispensada pela regra do grupo.</div>
                        <?php else: ?>
                            <div class="message-success">Etapa da demanda concluída. A agenda poderá seguir quando houver intenção real de agendamento.</div>
                        <?php endif; ?>
                    </section>

                    <?php if (!empty($selected['ai_memory_summary'])): ?>
                        <?php $memoryFacts = json_decode((string) ($selected['ai_memory_facts_json'] ?? ''), true); $memoryFacts = is_array($memoryFacts) ? $memoryFacts : []; ?>
                        <details class="drawer-section drawer-collapsed-card conversation-ai-memory-card">
                            <summary><span><span class="eyebrow">Memória da IA</span><strong><?= ($selected['ai_memory_scope'] ?? '') === 'contact' ? 'Memória preservada do contato' : 'Resumo progressivo da conversa' ?></strong><small><?= (int) ($selected['ai_memory_refresh_count'] ?? 0) ?> atualização(ões)<?= !empty($selected['ai_memory_refreshed_at']) ? ' · ' . View::e($formatDate($selected['ai_memory_refreshed_at'], 'd/m H:i')) : '' ?><?= ($selected['ai_memory_scope'] ?? '') === 'contact' ? ' · conversa anterior' : '' ?></small></span><span class="drawer-chevron"></span></summary>
                            <div class="conversation-ai-memory-body">
                                <p><?= nl2br(View::e((string) $selected['ai_memory_summary'])) ?></p>
                                <?php $memoryList = []; foreach (['interests' => 'Interesses','preferences' => 'Preferências','important_facts' => 'Fatos importantes','pending_items' => 'Pendências','commitments' => 'Compromissos','restrictions' => 'Restrições'] as $key => $label) { $values = is_array($memoryFacts[$key] ?? null) ? array_filter(array_map('strval', $memoryFacts[$key])) : []; if ($values) $memoryList[$label] = $values; } ?>
                                <?php if ($memoryList): ?><div class="conversation-ai-memory-facts"><?php foreach ($memoryList as $label => $values): ?><div><strong><?= View::e($label) ?></strong><span><?= View::e(implode(' · ', $values)) ?></span></div><?php endforeach; ?></div><?php endif; ?>
                                <?php if (!empty($memoryFacts['next_action'])): ?><div class="message-success"><strong>Próximo passo:</strong> <?= View::e((string) $memoryFacts['next_action']) ?></div><?php endif; ?>
                                <small class="field-hint">A memória é usada para continuidade e economia de contexto. Mensagens recentes prevalecem se houver divergência.</small>
                            </div>
                        </details>
                    <?php endif; ?>

                    <?php if ($canOperateSelected): ?>
                        <div class="drawer-savebar">
                            <button class="btn btn-primary btn-block" type="submit">Salvar alterações</button>
                        </div>
                    <?php endif; ?>
                </form>

                <details class="drawer-section drawer-collapsed-card" id="conversation-crm">
                    <summary>
                        <span>
                            <span class="eyebrow">CRM automático</span>
                            <strong><?= !empty($selected['lead_id']) ? View::e($selected['lead_title'] ?: 'Lead do WhatsApp') : 'Nenhum negócio vinculado' ?></strong>
                        </span>
                        <span class="drawer-chevron"></span>
                    </summary>
                    <div class="drawer-crm-content">
                        <?php if (!empty($selected['lead_id'])): ?>
                            <span>Etapa: <?= View::e($selected['lead_stage_name'] ?: '—') ?></span>
                            <span>Prioridade: <?= View::e($selected['lead_priority'] ?: '—') ?></span>
                            <?php if ($interestLabel !== ''): ?><span>Interesse: <?= View::e($interestLabel) ?></span><?php endif; ?>
                            <?php if (!empty($selected['ai_next_action'])): ?><p><?= View::e($selected['ai_next_action']) ?></p><?php endif; ?>
                            <a class="btn btn-outline btn-small btn-block" href="<?= View::e(Router::url('/crm?tenant_id=' . (int) $selected['tenant_id'] . '&pipeline_id=' . (int) $selected['lead_pipeline_id'] . '&lead_id=' . (int) $selected['lead_id'])) ?>">Abrir no CRM</a>
                        <?php else: ?>
                            <p>Novas mensagens recebidas pelo WhatsApp criam uma oportunidade automaticamente.</p>
                        <?php endif; ?>
                    </div>
                </details>
            </div>
        <?php else: ?>
            <div class="empty-state">Selecione uma conversa para visualizar o contato.</div>
        <?php endif; ?>
    </aside>
</div>
