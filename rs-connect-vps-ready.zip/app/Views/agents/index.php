<?php

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Router;
use App\Core\View;

$dayLabels = ['mon' => 'Seg', 'tue' => 'Ter', 'wed' => 'Qua', 'thu' => 'Qui', 'fri' => 'Sex', 'sat' => 'Sáb', 'sun' => 'Dom'];
$businessHoursByDay = static function (?string $json): array {
    $decoded = json_decode((string) $json, true);
    $result = [];
    foreach (['mon','tue','wed','thu','fri','sat','sun'] as $day) {
        $range = is_array($decoded) && isset($decoded[$day][0]) && is_array($decoded[$day][0]) ? $decoded[$day][0] : null;
        $result[$day] = [
            'enabled' => $range !== null && isset($range[0], $range[1]),
            'start' => $range !== null && isset($range[0]) ? (string) $range[0] : '08:00',
            'end' => $range !== null && isset($range[1]) ? (string) $range[1] : ($day === 'sat' ? '12:00' : '18:00'),
        ];
    }
    if (!is_array($decoded)) {
        foreach (['mon','tue','wed','thu','fri'] as $day) $result[$day]['enabled'] = true;
    }
    return $result;
};
$canManage = Auth::can('agents.manage');
$isClientExperience = !Auth::isSuperAdmin();
$selectedTenantId = (int) ($selectedTenantId ?? 0);
$tenants = is_array($tenants ?? null) ? $tenants : [];
$groupRules = is_array($groupRules ?? null) ? $groupRules : [];
$contactGroups = is_array($contactGroups ?? null) ? $contactGroups : [];
$promptVersions = is_array($promptVersions ?? null) ? $promptVersions : [];
$profile = is_array($companyProfile ?? null) ? $companyProfile : [];
$companyKnowledge = [];
foreach ([
    'Sobre a empresa' => $profile['company_about'] ?? '',
    'Principais serviços' => $profile['company_services'] ?? '',
    'Diferenciais' => $profile['company_differentials'] ?? '',
    'Horário de atendimento' => $profile['company_business_hours'] ?? '',
    'Site' => $profile['website'] ?? '',
    'Instagram' => $profile['instagram'] ?? '',
    'Observações importantes' => $profile['company_notes'] ?? '',
] as $label => $value) {
    $value = trim((string) $value);
    if ($value !== '') {
        $companyKnowledge[] = $label . ":\n" . $value;
    }
}
$defaultCompanyKnowledge = implode("\n\n", $companyKnowledge);
$aiModeLabels = ['economy' => 'Econômico', 'balanced' => 'Equilibrado', 'quality' => 'Qualidade máxima'];
$aiModeHints = [
    'economy' => 'Até 6 mensagens recentes, base seletiva e respostas mais curtas.',
    'balanced' => 'Lembra até 10 mensagens recentes, com equilíbrio entre qualidade e economia.',
    'quality' => 'Lembra até 20 mensagens recentes para respostas mais completas.',
];
$routingModeForBinding = static function (array $binding): string {
    if ((int) ($binding['is_primary'] ?? 0) === 1) {
        return 'primary';
    }
    return trim((string) ($binding['routing_keywords'] ?? '')) !== '' ? 'specialist' : 'round_robin';
};
$routingModeLabels = [
    'primary' => 'Atendimento principal',
    'specialist' => 'Assuntos específicos',
    'round_robin' => 'Divisão automática',
];
$routingModeShortLabels = [
    'primary' => 'Principal',
    'specialist' => 'Assuntos específicos',
    'round_robin' => 'Divisão automática',
];

$agentRulesProfile = is_array($agentBlueprintProfile ?? null) ? $agentBlueprintProfile : [];
$agentRuleCapabilities = is_array($agentRulesProfile['capabilities'] ?? null) ? $agentRulesProfile['capabilities'] : [];
$agentRuleFields = is_array($agentRulesProfile['triage_fields'] ?? null) ? $agentRulesProfile['triage_fields'] : [];
$agentRulePolicies = is_array($agentRulesProfile['policies'] ?? null) ? $agentRulesProfile['policies'] : [];
$agentRuleWorkflow = is_array($agentRulesProfile['workflow'] ?? null) ? $agentRulesProfile['workflow'] : [];
$conversationBehavior = is_array($conversationBehavior ?? null) ? $conversationBehavior : [];
$behaviorDemand = is_array($conversationBehavior['demand'] ?? null) ? $conversationBehavior['demand'] : [];
$behaviorDelivery = is_array($conversationBehavior['response_delivery'] ?? null) ? $conversationBehavior['response_delivery'] : [];
$behaviorModalities = is_array($conversationBehavior['modalities'] ?? null) ? $conversationBehavior['modalities'] : [];
$behaviorPayment = is_array($conversationBehavior['payment'] ?? null) ? $conversationBehavior['payment'] : [];
$behaviorNoAvailability = is_array($conversationBehavior['no_availability'] ?? null) ? $conversationBehavior['no_availability'] : [];
$behaviorSpecialRoutes = is_array($conversationBehavior['special_routes'] ?? null) ? array_values($conversationBehavior['special_routes']) : [];
$teamUsers = is_array($teamUsers ?? null) ? $teamUsers : [];
$preScheduleSettings = is_array($preScheduleSettings ?? null) ? $preScheduleSettings : [];
$hasExplicitConversationBehavior = is_array(($agentRulesProfile['config']['conversation_behavior'] ?? null));
// Na primeira abertura após a atualização, preserve a mensagem que a empresa já usava
// no pré-agendamento. O default da nova camada não deve sobrescrever silenciosamente
// uma configuração operacional existente.
if (!$hasExplicitConversationBehavior && trim((string) ($preScheduleSettings['no_availability_message'] ?? '')) !== '') {
    $behaviorNoAvailability['message'] = (string) $preScheduleSettings['no_availability_message'];
} elseif (trim((string) ($behaviorNoAvailability['message'] ?? '')) === '' && trim((string) ($preScheduleSettings['no_availability_message'] ?? '')) !== '') {
    $behaviorNoAvailability['message'] = (string) $preScheduleSettings['no_availability_message'];
}
while (count($behaviorSpecialRoutes) < 4) {
    $behaviorSpecialRoutes[] = ['enabled' => false, 'label' => '', 'keywords' => '', 'customer_message' => '', 'target_user_id' => 0];
}
$weekdayLabelsLong = ['mon'=>'Segunda','tue'=>'Terça','wed'=>'Quarta','thu'=>'Quinta','fri'=>'Sexta','sat'=>'Sábado','sun'=>'Domingo'];
$paymentMethodOptions = ['Pix','Cartão','Transferência','Dinheiro','Boleto'];
$agentCapabilityLabels = [
    'triage.enabled' => 'Coletar informações antes de avançar',
    'eligibility.enabled' => 'Validar regras antes de liberar ações',
    'calendar.read' => 'Verificar horários na agenda',
    'calendar.pre_schedule' => 'Fazer pré-reserva de horário',
    'calendar.confirm' => 'Confirmar agendamento automaticamente',
    'calendar.human_approval' => 'Pedir aprovação da equipe antes de confirmar',
    'handoff.audio' => 'Passar para uma pessoa ao receber áudio',
    'policy.fail_closed' => 'Bloquear ações quando houver dúvida ou erro',
];
$agentCapabilityHelp = [
    'triage.enabled' => 'Pergunta somente o que estiver faltando e aproveita o que já foi informado.',
    'eligibility.enabled' => 'Confere as regras do negócio antes de agenda, confirmação ou outra ação importante.',
    'calendar.read' => 'Permite consultar disponibilidade real.',
    'calendar.pre_schedule' => 'Permite segurar um horário válido conforme as regras da agenda.',
    'calendar.confirm' => 'Pode concluir o agendamento sem aprovação humana quando a operação permitir.',
    'calendar.human_approval' => 'Mantém a confirmação final com a equipe.',
    'handoff.audio' => 'Ao receber áudio, pausa a automação e entrega a conversa para uma pessoa.',
    'policy.fail_closed' => 'Proteção estrutural da plataforma: se algo não puder ser validado, a ação não é executada.',
];
$agentPolicyLabels = [
    'minimum_age' => 'Idade mínima para atendimento',
    'couple_service_allowed' => 'Permitir atendimento de casal',
    'scheduling_requires_eligibility' => 'Validar regras antes de consultar agenda',
    'confirmation_requires_human' => 'Confirmação depende da equipe',
    'service_required' => 'Exigir serviço antes de consultar agenda',
    'required_before_schedule' => 'Informações obrigatórias antes da agenda',
];
$agentPolicyActionLabels = [
    'block' => 'Bloquear a ação',
    'block_schedule' => 'Não permitir agenda (a conversa continua)',
    'human_approval' => 'Pedir aprovação da equipe',
    'collect' => 'Pedir a informação antes de seguir',
    'allow_confirm' => 'Permitir confirmação automática',
    'handoff' => 'Passar para atendimento humano',
    'warn' => 'Apenas sinalizar atenção',
];
$agentFieldTypeLabels = ['text' => 'Texto', 'textarea' => 'Texto livre', 'number' => 'Número', 'boolean' => 'Sim ou não', 'select' => 'Lista de opções', 'date' => 'Data', 'time' => 'Horário'];
$humanizeAgentRule = static function (string $key): string {
    $value = preg_replace('/[_\.]+/', ' ', trim($key)) ?? $key;
    return $value !== '' ? mb_convert_case($value, MB_CASE_TITLE, 'UTF-8') : 'Regra';
};
?>
<div class="agent-management-page <?= $isClientExperience ? 'agent-client-experience' : 'agent-admin-experience' ?>">
    <section class="card agent-list-card">
        <div class="section-heading agent-page-heading">
            <div><span class="eyebrow">Assistentes virtuais</span><h2>Assistentes cadastrados</h2></div>
            <div class="agent-page-actions">
                <span class="badge"><?= count($agents) ?> assistente(s)</span>
                <?php if ($canManage): ?>
                    <button class="btn btn-primary" type="button" data-toggle-panel="agent-create-drawer" <?= !$instances ? 'disabled' : '' ?>>
                        Novo assistente
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <?php if (Auth::isSuperAdmin()): ?>
            <form class="agent-admin-tenant-selector" method="get" action="<?= View::e(Router::url('/agents')) ?>">
                <div>
                    <span class="eyebrow">Empresa em edição</span>
                    <strong><?= View::e($profile['name'] ?? 'Selecione uma empresa') ?></strong>
                    <small>Escolha a empresa para visualizar e editar as conexões, assistentes e instruções corretas.</small>
                </div>
                <label class="field compact-field">
                    <span>Empresa</span>
                    <select name="tenant_id" data-auto-submit required>
                        <option value="">Selecione</option>
                        <?php foreach ($tenants as $tenant): ?>
                            <option value="<?= (int) $tenant['id'] ?>" <?= $selectedTenantId === (int) $tenant['id'] ? 'selected' : '' ?>>
                                <?= View::e($tenant['name']) ?> · <?= (int) ($tenant['agents_count'] ?? 0) ?> assistente(s) · <?= (int) ($tenant['instances_count'] ?? 0) ?> WhatsApp(s)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </form>
        <?php endif; ?>

        <?php if ($canManage && !$instances): ?>
            <div class="message-warning agent-connection-warning">
                A equipe RS Connect precisa preparar uma conexão WhatsApp antes da criação do primeiro assistente.
            </div>
        <?php endif; ?>

        <?php if ($canManage && $instances): ?>
            <div class="agent-routing-guide">
                <div><span class="eyebrow">Mais de um assistente</span><strong>Escolha como cada assistente participa do atendimento</strong></div>
                <div class="agent-routing-guide-items">
                    <span><b>Atendimento principal</b> recebe as conversas gerais.</span>
                    <span><b>Assuntos específicos</b> recebe somente os temas que você escolher.</span>
                    <span><b>Divisão automática</b> reparte novos atendimentos entre os assistentes disponíveis.</span>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($canManage && $agentRulesProfile !== [] && !empty($agentRulesProfile['id'])): ?>
            <section class="agent-operation-rules">
                <form method="post" action="<?= View::e(Router::url('/agents/operational-rules')) ?>" class="agent-operation-rules-form">
                    <?= Csrf::input() ?>
                    <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>

                    <div class="agent-operation-rules-head">
                        <div>
                            <span class="eyebrow">Regras do atendimento</span>
                            <h3>Como os assistentes desta empresa devem trabalhar</h3>
                            <p>Essas regras são compartilhadas pelos assistentes da empresa. Cada assistente continua tendo suas próprias instruções, canais e personalidade.</p>
                        </div>
                        <div class="agent-operation-model-summary">
                            <span>Segmento</span><strong><?= View::e((string) ($agentRulesProfile['niche_name'] ?? 'Não definido')) ?></strong>
                            <span>Modelo</span><strong><?= View::e((string) ($agentRulesProfile['blueprint_name'] ?? 'Sem modelo')) ?></strong>
                        </div>
                    </div>

                    <div class="message-info agent-operation-admin-note">
                        <strong>O que fica com a RS Connect</strong>
                        <span>Troca de segmento, modelo-base, versão e proteções técnicas da plataforma ficam no RS Admin. As regras do dia a dia podem ser ajustadas aqui pela empresa.</span>
                    </div>

                    <div class="agent-operation-mode-row">
                        <label class="field compact-field">
                            <span>Como o assistente faz as perguntas</span>
                            <select name="agent_interaction_mode">
                                <option value="hybrid" <?= ($agentRulesProfile['interaction_mode'] ?? 'hybrid') === 'hybrid' ? 'selected' : '' ?>>Natural com regras — recomendado</option>
                                <option value="form" <?= ($agentRulesProfile['interaction_mode'] ?? '') === 'form' ? 'selected' : '' ?>>Perguntas configuradas</option>
                                <option value="prompt" <?= ($agentRulesProfile['interaction_mode'] ?? '') === 'prompt' ? 'selected' : '' ?>>Prompt Studio com as mesmas travas</option>
                            </select>
                            <small>A forma de falar pode variar; as regras abaixo continuam sendo verificadas pelo sistema.</small>
                        </label>
                        <div class="agent-operation-version">
                            <span>Modelo aplicado</span>
                            <strong><?= View::e((string) ($agentRulesProfile['version_label'] ?? '—')) ?></strong>
                            <small><?= !empty($agentRulesProfile['customized']) ? 'Com ajustes próprios da empresa' : 'Padrão do segmento' ?></small>
                        </div>
                    </div>

                    <?php if ($agentRuleWorkflow !== []): ?>
                        <details class="agent-operation-section" open>
                            <summary>
                                <span><b>1</b><strong>Ordem do atendimento</strong><small>Defina o que vem primeiro na conversa.</small></span>
                                <span class="drawer-chevron"></span>
                            </summary>
                            <div class="agent-operation-section-body">
                                <p class="field-hint">A sequência vem do modelo escolhido no RS Admin, mas pode ser reorganizada para esta empresa. A ordem também passa a influenciar qual informação pendente o sistema pede primeiro.</p>
                                <div class="agent-workflow-editor" data-workflow-list>
                                    <?php foreach ($agentRuleWorkflow as $index => $step): ?>
                                        <?php
                                        $workflowKey = (string) ($step['step_key'] ?? '');
                                        $workflowType = (string) ($step['step_type'] ?? 'collect');
                                        $workflowTypeLabel = ['collect'=>'Coleta','policy'=>'Validação','action'=>'Ação','handoff'=>'Equipe','complete'=>'Conclusão'][$workflowType] ?? 'Etapa';
                                        ?>
                                        <article class="agent-workflow-editor-step" data-workflow-step>
                                            <div class="agent-workflow-order">
                                                <span class="agent-workflow-number" data-workflow-number><?= $index + 1 ?></span>
                                                <div class="agent-workflow-move">
                                                    <button type="button" class="workflow-move-btn" data-workflow-move="up" aria-label="Mover para cima">↑</button>
                                                    <button type="button" class="workflow-move-btn" data-workflow-move="down" aria-label="Mover para baixo">↓</button>
                                                </div>
                                            </div>
                                            <div class="agent-workflow-editor-content">
                                                <div class="agent-workflow-editor-head">
                                                    <span class="agent-workflow-type"><?= View::e($workflowTypeLabel) ?></span>
                                                    <?php if ($workflowType !== 'collect'): ?><span class="agent-workflow-protected">Validada pelo sistema</span><?php endif; ?>
                                                </div>
                                                <label class="field compact-field"><span>Nome da etapa</span><input name="workflow_steps[<?= View::e($workflowKey) ?>][label]" value="<?= View::e((string) ($step['label'] ?? $workflowKey)) ?>" maxlength="180"></label>
                                                <input type="hidden" name="workflow_steps[<?= View::e($workflowKey) ?>][position]" value="<?= (int) ($step['position'] ?? (($index + 1) * 10)) ?>" data-workflow-position>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </details>
                    <?php endif; ?>

                    <?php if ($agentRuleFields !== []): ?>
                        <details class="agent-operation-section">
                            <summary>
                                <span><b>2</b><strong>Informações que precisam ser coletadas</strong><small>Escolha o que perguntar e em que momento exigir.</small></span>
                                <span class="drawer-chevron"></span>
                            </summary>
                            <div class="agent-operation-section-body">
                                <div class="agent-operation-fields-grid">
                                    <?php foreach ($agentRuleFields as $field): ?>
                                        <?php $fieldKey = (string) ($field['field_key'] ?? ''); $fieldType = (string) ($field['field_type'] ?? 'text'); ?>
                                        <article class="agent-operation-field-card">
                                            <div class="agent-operation-card-title"><strong><?= View::e((string) ($field['label'] ?? $fieldKey)) ?></strong><span><?= View::e($agentFieldTypeLabels[$fieldType] ?? 'Informação') ?></span></div>
                                            <label class="field compact-field"><span>Nome da informação</span><input name="triage_fields[<?= View::e($fieldKey) ?>][label]" value="<?= View::e((string) ($field['label'] ?? $fieldKey)) ?>"></label>
                                            <label class="field compact-field"><span>Pergunta usada como padrão</span><textarea name="triage_fields[<?= View::e($fieldKey) ?>][prompt_text]" rows="2"><?= View::e((string) ($field['prompt_text'] ?? '')) ?></textarea></label>
                                            <input type="hidden" name="triage_fields[<?= View::e($fieldKey) ?>][active]" value="0">
                                            <label class="check-field compact-check"><input type="checkbox" name="triage_fields[<?= View::e($fieldKey) ?>][active]" value="1" <?= !empty($field['active']) ? 'checked' : '' ?>><span>Usar esta informação</span></label>
                                            <input type="hidden" name="triage_fields[<?= View::e($fieldKey) ?>][required_before_schedule]" value="0">
                                            <label class="check-field compact-check"><input type="checkbox" name="triage_fields[<?= View::e($fieldKey) ?>][required_before_schedule]" value="1" <?= !empty($field['required_before_schedule']) ? 'checked' : '' ?>><span>Exigir antes de consultar a agenda</span></label>
                                            <input type="hidden" name="triage_fields[<?= View::e($fieldKey) ?>][required_for_completion]" value="0">
                                            <label class="check-field compact-check"><input type="checkbox" name="triage_fields[<?= View::e($fieldKey) ?>][required_for_completion]" value="1" <?= !empty($field['required_for_completion']) ? 'checked' : '' ?>><span>Coletar antes de encerrar o atendimento</span></label>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </details>
                    <?php endif; ?>

                    <?php if ($agentRulePolicies !== []): ?>
                        <details class="agent-operation-section">
                            <summary>
                                <span><b>3</b><strong>Regras e limites do negócio</strong><small>Idade, tipo de atendimento, aprovação e mensagens de orientação.</small></span>
                                <span class="drawer-chevron"></span>
                            </summary>
                            <div class="agent-operation-section-body">
                                <div class="agent-operation-fields-grid">
                                    <?php foreach ($agentRulePolicies as $policy): ?>
                                        <?php
                                        $policyKey = (string) ($policy['policy_key'] ?? '');
                                        $policyType = (string) ($policy['policy_type'] ?? 'string');
                                        $policyValue = $policy['value'] ?? '';
                                        $actionKey = (string) ($policy['action_key'] ?? 'block');
                                        ?>
                                        <article class="agent-operation-field-card">
                                            <div class="agent-operation-card-title"><strong><?= View::e($agentPolicyLabels[$policyKey] ?? $humanizeAgentRule($policyKey)) ?></strong><span><?= !empty($policy['enabled']) ? 'Ativa' : 'Desativada' ?></span></div>
                                            <?php if ($policyType === 'boolean'): ?>
                                                <label class="field compact-field"><span>Esta regra deve valer?</span><select name="agent_policies[<?= View::e($policyKey) ?>][value]"><option value="1" <?= !empty($policyValue) ? 'selected' : '' ?>>Sim</option><option value="0" <?= empty($policyValue) ? 'selected' : '' ?>>Não</option></select></label>
                                            <?php elseif ($policyType === 'number'): ?>
                                                <label class="field compact-field"><span>Valor definido</span><input type="number" name="agent_policies[<?= View::e($policyKey) ?>][value]" value="<?= View::e((string) $policyValue) ?>"></label>
                                            <?php else: ?>
                                                <label class="field compact-field"><span>Valor</span><input name="agent_policies[<?= View::e($policyKey) ?>][value]" value="<?= View::e(is_array($policyValue) ? json_encode($policyValue, JSON_UNESCAPED_UNICODE) : (string) $policyValue) ?>"></label>
                                            <?php endif; ?>
                                            <label class="field compact-field"><span>Quando a regra acontecer</span><select name="agent_policies[<?= View::e($policyKey) ?>][action_key]"><?php foreach ($agentPolicyActionLabels as $key => $label): ?><option value="<?= View::e($key) ?>" <?= $actionKey === $key ? 'selected' : '' ?>><?= View::e($label) ?></option><?php endforeach; ?></select></label>
                                            <label class="field compact-field"><span>Mensagem que o cliente recebe</span><textarea name="agent_policies[<?= View::e($policyKey) ?>][customer_message]" rows="3"><?= View::e((string) ($policy['customer_message'] ?? '')) ?></textarea></label>
                                            <input type="hidden" name="agent_policies[<?= View::e($policyKey) ?>][enabled]" value="0">
                                            <label class="check-field compact-check"><input type="checkbox" name="agent_policies[<?= View::e($policyKey) ?>][enabled]" value="1" <?= !empty($policy['enabled']) ? 'checked' : '' ?>><span>Usar esta regra</span></label>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </details>
                    <?php endif; ?>

                    <details class="agent-operation-section agent-conversation-behavior-section" open>
                        <summary>
                            <span><b>4</b><strong>Conversa, modalidades e encaminhamentos</strong><small>Defina o que precisa ser perguntado, como explicar o atendimento e quando chamar uma pessoa.</small></span>
                            <span class="drawer-chevron"></span>
                        </summary>
                        <div class="agent-operation-section-body agent-behavior-body">
                            <div class="agent-behavior-intro">
                                <div><span class="eyebrow">Comportamento estruturado</span><strong>Regras que não dependem só do prompt</strong></div>
                                <p>Use estes campos para informações operacionais que precisam ser consistentes em toda conversa. O texto livre continua definindo tom e personalidade.</p>
                            </div>

                            <div class="agent-behavior-grid">
                                <article class="agent-behavior-card">
                                    <div class="agent-behavior-card-head"><span class="agent-behavior-index">1</span><div><strong>Entender a demanda</strong><small>Evita avançar para agenda sem saber o que a pessoa precisa.</small></div></div>
                                    <input type="hidden" name="conversation_behavior[demand][enabled]" value="0">
                                    <label class="check-field compact-check"><input type="checkbox" name="conversation_behavior[demand][enabled]" value="1" <?= !empty($behaviorDemand['enabled']) ? 'checked' : '' ?>><span>Perguntar a demanda quando ainda não estiver clara</span></label>
                                    <input type="hidden" name="conversation_behavior[demand][required_before_schedule]" value="0">
                                    <label class="check-field compact-check"><input type="checkbox" name="conversation_behavior[demand][required_before_schedule]" value="1" <?= !empty($behaviorDemand['required_before_schedule']) ? 'checked' : '' ?>><span>Exigir a demanda antes de consultar a agenda</span></label>
                                    <label class="field compact-field"><span>Pergunta sugerida</span><textarea name="conversation_behavior[demand][prompt]" rows="3" placeholder="Ex.: Antes de avançarmos, pode me contar brevemente o que você está buscando neste atendimento?"><?= View::e((string) ($behaviorDemand['prompt'] ?? '')) ?></textarea></label>
                                    <p class="field-hint">Clientes e pacientes atuais continuam usando o histórico e não são obrigados a refazer uma triagem já conhecida.</p>
                                </article>

                                <article class="agent-behavior-card">
                                    <div class="agent-behavior-card-head"><span class="agent-behavior-index">2</span><div><strong>Respostas em mensagens curtas</strong><small>Deixa o WhatsApp mais natural sem quebrar uma frase no meio.</small></div></div>
                                    <label class="field compact-field"><span>Como enviar respostas maiores</span><select name="conversation_behavior[response_delivery][mode]"><option value="auto" <?= ($behaviorDelivery['mode'] ?? 'auto') === 'auto' ? 'selected' : '' ?>>Automático conforme o conteúdo</option><option value="blocks" <?= ($behaviorDelivery['mode'] ?? '') === 'blocks' ? 'selected' : '' ?>>Preferir mensagens separadas</option><option value="single" <?= ($behaviorDelivery['mode'] ?? '') === 'single' ? 'selected' : '' ?>>Sempre uma única mensagem</option></select></label>
                                    <label class="field compact-field"><span>Máximo de blocos</span><select name="conversation_behavior[response_delivery][max_blocks]"><?php foreach ([2,3,4] as $blockCount): ?><option value="<?= $blockCount ?>" <?= (int) ($behaviorDelivery['max_blocks'] ?? 3) === $blockCount ? 'selected' : '' ?>><?= $blockCount ?> mensagens</option><?php endforeach; ?></select></label>
                                    <div class="agent-behavior-example"><b>Exemplo</b><span>1. modalidade/local</span><span>2. valor e pagamento</span><span>3. próximo passo</span></div>
                                </article>
                            </div>

                            <div class="agent-behavior-subsection">
                                <div class="agent-behavior-subhead"><div><span class="eyebrow">Modalidades</span><strong>Online e presencial</strong></div><small>Estas informações entram no contexto operacional da IA e os dias presenciais também filtram horários oferecidos pela agenda conversacional.</small></div>
                                <div class="agent-behavior-grid agent-modality-grid">
                                    <?php $online = is_array($behaviorModalities['online'] ?? null) ? $behaviorModalities['online'] : []; ?>
                                    <article class="agent-behavior-card modality-card">
                                        <input type="hidden" name="conversation_behavior[modalities][online][enabled]" value="0">
                                        <label class="check-field compact-check behavior-card-toggle"><input type="checkbox" name="conversation_behavior[modalities][online][enabled]" value="1" <?= !empty($online['enabled']) ? 'checked' : '' ?>><span><strong>Atendimento online</strong></span></label>
                                        <label class="field compact-field"><span>Como acontece</span><input name="conversation_behavior[modalities][online][channel]" value="<?= View::e((string) ($online['channel'] ?? '')) ?>" placeholder="Ex.: Google Meet"></label>
                                        <label class="field compact-field"><span>Mensagem operacional</span><textarea name="conversation_behavior[modalities][online][message]" rows="3" placeholder="Ex.: O atendimento online é realizado pelo Google Meet."><?= View::e((string) ($online['message'] ?? '')) ?></textarea></label>
                                    </article>
                                    <?php $presencial = is_array($behaviorModalities['presencial'] ?? null) ? $behaviorModalities['presencial'] : []; $presencialDays = is_array($presencial['allowed_days'] ?? null) ? $presencial['allowed_days'] : []; ?>
                                    <article class="agent-behavior-card modality-card">
                                        <input type="hidden" name="conversation_behavior[modalities][presencial][enabled]" value="0">
                                        <label class="check-field compact-check behavior-card-toggle"><input type="checkbox" name="conversation_behavior[modalities][presencial][enabled]" value="1" <?= !empty($presencial['enabled']) ? 'checked' : '' ?>><span><strong>Atendimento presencial</strong></span></label>
                                        <label class="field compact-field"><span>Local</span><input name="conversation_behavior[modalities][presencial][location]" value="<?= View::e((string) ($presencial['location'] ?? '')) ?>" placeholder="Ex.: Bronze — endereço ou referência"></label>
                                        <div class="field compact-field"><span>Dias permitidos para presencial</span><div class="agent-weekday-checks"><?php foreach ($weekdayLabelsLong as $dayKey => $dayLabel): ?><label><input type="checkbox" name="conversation_behavior[modalities][presencial][allowed_days][]" value="<?= View::e($dayKey) ?>" <?= in_array($dayKey, $presencialDays, true) ? 'checked' : '' ?>><span><?= View::e($dayLabel) ?></span></label><?php endforeach; ?></div></div>
                                        <label class="field compact-field"><span>Mensagem operacional</span><textarea name="conversation_behavior[modalities][presencial][message]" rows="3" placeholder="Ex.: Os atendimentos presenciais acontecem no Bronze, somente às segundas-feiras."><?= View::e((string) ($presencial['message'] ?? '')) ?></textarea></label>
                                    </article>
                                </div>
                            </div>

                            <div class="agent-behavior-grid">
                                <article class="agent-behavior-card">
                                    <div class="agent-behavior-card-head"><span class="agent-behavior-index">3</span><div><strong>Valor e formas de pagamento</strong><small>Informe depois de explicar a modalidade, sem depender de memória do prompt.</small></div></div>
                                    <input type="hidden" name="conversation_behavior[payment][enabled]" value="0">
                                    <label class="check-field compact-check"><input type="checkbox" name="conversation_behavior[payment][enabled]" value="1" <?= !empty($behaviorPayment['enabled']) ? 'checked' : '' ?>><span>Usar estas informações no atendimento</span></label>
                                    <label class="field compact-field"><span>Valor / regra de preço</span><input name="conversation_behavior[payment][value_text]" value="<?= View::e((string) ($behaviorPayment['value_text'] ?? '')) ?>" placeholder="Ex.: R$ 200 por sessão"></label>
                                    <div class="field compact-field"><span>Formas aceitas</span><div class="agent-payment-methods"><?php $selectedMethods = is_array($behaviorPayment['methods'] ?? null) ? $behaviorPayment['methods'] : []; foreach ($paymentMethodOptions as $method): ?><label><input type="checkbox" name="conversation_behavior[payment][methods][]" value="<?= View::e($method) ?>" <?= in_array($method, $selectedMethods, true) ? 'checked' : '' ?>><span><?= View::e($method) ?></span></label><?php endforeach; ?></div></div>
                                    <label class="field compact-field"><span>Complemento opcional</span><textarea name="conversation_behavior[payment][message]" rows="2" placeholder="Ex.: O pagamento pode ser feito antes da sessão."><?= View::e((string) ($behaviorPayment['message'] ?? '')) ?></textarea></label>
                                </article>

                                <article class="agent-behavior-card">
                                    <div class="agent-behavior-card-head"><span class="agent-behavior-index">4</span><div><strong>Quando não houver vaga</strong><small>A resposta vem da disponibilidade real da agenda.</small></div></div>
                                    <label class="field compact-field"><span>Mensagem sem disponibilidade</span><textarea name="conversation_behavior[no_availability][message]" rows="4" placeholder="Ex.: No momento minha agenda está sem novos horários disponíveis..."><?= View::e((string) ($behaviorNoAvailability['message'] ?? '')) ?></textarea></label>
                                    <label class="field compact-field"><span>Depois de informar</span><select name="conversation_behavior[no_availability][action]"><option value="message_only" <?= ($behaviorNoAvailability['action'] ?? 'message_only') === 'message_only' ? 'selected' : '' ?>>Somente conversar e pedir outra preferência</option><option value="notify" <?= ($behaviorNoAvailability['action'] ?? '') === 'notify' ? 'selected' : '' ?>>Avisar a equipe na RS Connect</option><option value="handoff" <?= ($behaviorNoAvailability['action'] ?? '') === 'handoff' ? 'selected' : '' ?>>Encaminhar para atendimento humano</option></select></label>
                                    <label class="field compact-field"><span>Responsável preferencial</span><select name="conversation_behavior[no_availability][target_user_id]"><option value="0">Equipe / sem responsável específico</option><?php foreach ($teamUsers as $teamUser): ?><option value="<?= (int) $teamUser['id'] ?>" <?= (int) ($behaviorNoAvailability['target_user_id'] ?? 0) === (int) $teamUser['id'] ? 'selected' : '' ?>><?= View::e((string) ($teamUser['whatsapp_display_name'] ?: $teamUser['name'])) ?></option><?php endforeach; ?></select></label>
                                </article>
                            </div>

                            <div class="agent-behavior-subsection">
                                <div class="agent-behavior-subhead"><div><span class="eyebrow">Encaminhamentos especiais</span><strong>Assuntos que não devem virar pré-agendamento</strong></div><small>Ex.: convite para palestra, aula, supervisão ou parceria. Ao detectar o assunto, o RS Connect responde a mensagem configurada, pausa a IA e encaminha a conversa.</small></div>
                                <div class="agent-special-routes">
                                    <?php foreach ($behaviorSpecialRoutes as $routeIndex => $route): ?>
                                        <article class="agent-special-route-card">
                                            <div class="agent-special-route-title"><strong>Regra <?= $routeIndex + 1 ?></strong><label class="compact-inline-check"><input type="hidden" name="conversation_behavior[special_routes][<?= $routeIndex ?>][enabled]" value="0"><input type="checkbox" name="conversation_behavior[special_routes][<?= $routeIndex ?>][enabled]" value="1" <?= !empty($route['enabled']) ? 'checked' : '' ?>><span>Ativa</span></label></div>
                                            <div class="agent-special-route-grid">
                                                <label class="field compact-field"><span>Assunto</span><input name="conversation_behavior[special_routes][<?= $routeIndex ?>][label]" value="<?= View::e((string) ($route['label'] ?? '')) ?>" placeholder="Ex.: Convite para palestra"></label>
                                                <label class="field compact-field"><span>Palavras / frases</span><input name="conversation_behavior[special_routes][<?= $routeIndex ?>][keywords]" value="<?= View::e((string) ($route['keywords'] ?? '')) ?>" placeholder="palestra, convite para palestra, evento"></label>
                                                <label class="field compact-field"><span>Encaminhar para</span><select name="conversation_behavior[special_routes][<?= $routeIndex ?>][target_user_id]"><option value="0">Equipe / sem responsável específico</option><?php foreach ($teamUsers as $teamUser): ?><option value="<?= (int) $teamUser['id'] ?>" <?= (int) ($route['target_user_id'] ?? 0) === (int) $teamUser['id'] ? 'selected' : '' ?>><?= View::e((string) ($teamUser['whatsapp_display_name'] ?: $teamUser['name'])) ?></option><?php endforeach; ?></select></label>
                                                <label class="field compact-field agent-special-route-message"><span>Mensagem para o cliente</span><textarea name="conversation_behavior[special_routes][<?= $routeIndex ?>][customer_message]" rows="2" placeholder="Ex.: Claro! Vou encaminhar seu convite para a responsável continuar com você."><?= View::e((string) ($route['customer_message'] ?? '')) ?></textarea></label>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </details>

                    <?php if ($agentRuleCapabilities !== []): ?>
                        <details class="agent-operation-section">
                            <summary>
                                <span><b>5</b><strong>O que a automação pode fazer</strong><small>Permissões práticas de triagem, agenda e encaminhamento.</small></span>
                                <span class="drawer-chevron"></span>
                            </summary>
                            <div class="agent-operation-section-body">
                                <div class="settings-toggle-grid agent-operation-capabilities">
                                    <?php foreach ($agentRuleCapabilities as $capabilityKey => $enabled): ?>
                                        <?php $platformLocked = $capabilityKey === 'policy.fail_closed' && !Auth::isSuperAdmin(); ?>
                                        <label class="switch-card agent-rule-toggle <?= $enabled ? 'is-on' : 'is-off' ?> <?= $platformLocked ? 'is-platform-locked' : '' ?>">
                                            <?php if (!$platformLocked): ?><input type="hidden" name="agent_capabilities[<?= View::e((string) $capabilityKey) ?>]" value="0"><?php endif; ?>
                                            <input type="checkbox" name="agent_capabilities[<?= View::e((string) $capabilityKey) ?>]" value="1" <?= $enabled ? 'checked' : '' ?> <?= $platformLocked ? 'disabled' : '' ?>>
                                            <span><strong><?= View::e($agentCapabilityLabels[$capabilityKey] ?? $humanizeAgentRule((string) $capabilityKey)) ?></strong><small><?= View::e($agentCapabilityHelp[$capabilityKey] ?? 'Permissão definida pelo modelo de atendimento.') ?><?= $platformLocked ? ' Esta proteção é mantida pela RS Connect.' : '' ?></small></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </details>
                    <?php endif; ?>

                    <div class="agent-operation-savebar">
                        <div><strong>As mudanças valem para as próximas conversas.</strong><small>As proteções técnicas continuam ativas mesmo quando você muda a ordem ou a forma das perguntas.</small></div>
                        <?php if ($canManage): ?><button class="btn btn-primary" type="submit">Salvar regras do atendimento</button><?php endif; ?>
                    </div>
                </form>
            </section>
        <?php endif; ?>

        <div class="agent-grid">
            <?php foreach ($agents as $agent): ?>
                <?php
                $dayHours = $businessHoursByDay($agent['business_hours_json'] ?? null);
                $agentChannelBindings = [];
                foreach (($agent['channels'] ?? []) as $channelBinding) {
                    $bindingInstanceId = (int) ($channelBinding['instance_id'] ?? 0);
                    if ($bindingInstanceId > 0) {
                        $agentChannelBindings[$bindingInstanceId] = $channelBinding;
                    }
                }
                $legacyInstanceId = (int) ($agent['instance_id'] ?? 0);
                if ($legacyInstanceId > 0 && !isset($agentChannelBindings[$legacyInstanceId])) {
                    $agentChannelBindings[$legacyInstanceId] = [
                        'instance_id' => $legacyInstanceId,
                        'is_primary' => 1,
                        'priority' => 100,
                        'routing_keywords' => null,
                        'status' => 'active',
                    ];
                }
                $routingModesInUse = [];
                $routingKeywordsSummary = [];
                foreach ($agentChannelBindings as $binding) {
                    $mode = $routingModeForBinding($binding);
                    $routingModesInUse[$mode] = true;
                    if ($mode === 'specialist') {
                        foreach (preg_split('/[,;\n]+/u', (string) ($binding['routing_keywords'] ?? '')) ?: [] as $keyword) {
                            $keyword = trim((string) $keyword);
                            if ($keyword !== '' && !in_array($keyword, $routingKeywordsSummary, true)) {
                                $routingKeywordsSummary[] = $keyword;
                            }
                        }
                    }
                }
                $routingSummaryLabels = array_map(
                    static fn (string $mode): string => $routingModeShortLabels[$mode] ?? $mode,
                    array_keys($routingModesInUse)
                );
                $routingSummary = $routingSummaryLabels !== [] ? implode(' · ', $routingSummaryLabels) : 'Não configurado';
                ?>
                <article class="agent-card">
                    <div class="agent-card-head">
                        <span class="agent-icon agent-icon-bot" aria-hidden="true"></span>
                        <div class="agent-card-identity"><h3><?= View::e($agent['name']) ?></h3><p><?= View::e($agent['segment']) ?></p></div>
                        <span class="agent-card-status-dot <?= $agent['status'] === 'active' ? 'is-active' : 'is-inactive' ?>" title="<?= $agent['status'] === 'active' ? 'Ativo' : 'Inativo' ?>" aria-label="<?= $agent['status'] === 'active' ? 'Ativo' : 'Inativo' ?>"></span>
                    </div>
                    <div class="agent-data agent-data-compact">
                        <div>
                            <span>Canais</span>
                            <strong><?= (int) ($agent['channel_count'] ?? 0) === 1 ? '1 canal vinculado' : (int) ($agent['channel_count'] ?? 0) . ' canais vinculados' ?></strong>
                            <small class="agent-data-ellipsis" title="<?= View::e((string) ($agent['channel_names'] ?? '')) ?>"><?= View::e(($agent['channel_names'] ?? '') !== '' ? $agent['channel_names'] : ($agent['instance_name'] ?? 'Não vinculado')) ?></small>
                        </div>
                        <div>
                            <span>Papel no atendimento</span>
                            <strong><?= View::e($routingSummary) ?></strong>
                            <?php if ($routingKeywordsSummary !== []): ?>
                                <small><?= count($routingKeywordsSummary) ?> intenção(ões) configurada(s)</small>
                            <?php else: ?>
                                <small>Sem direcionamento por intenção</small>
                            <?php endif; ?>
                        </div>
                        <div><span>Modelo</span><strong><?= View::e($agent['credential_model'] ?: $agent['model_name']) ?></strong></div>
                        <div><span>Memória</span><strong><?= (int) ($agent['max_context_messages'] ?? 12) ?> mensagens · <?= View::e($aiModeLabels[$agent['ai_efficiency_mode'] ?? 'balanced'] ?? 'Equilibrado') ?></strong></div>
                    </div>
                    <div class="badge-row agent-card-badges">
                        <span class="badge badge-<?= View::e($agent['status']) ?>"><?= $agent['status'] === 'active' ? 'Ativo' : 'Inativo' ?></span>
                        <span class="badge <?= (int) ($agent['auto_reply_enabled'] ?? 0) === 1 ? 'badge-success' : 'badge-muted' ?>"><?= (int) ($agent['auto_reply_enabled'] ?? 0) === 1 ? 'Automático' : 'Manual' ?></span>
                        <?php foreach (array_slice(array_keys($routingModesInUse), 0, 1) as $routingMode): ?>
                            <span class="badge agent-routing-badge agent-routing-badge-<?= View::e($routingMode) ?>"><?= View::e($routingModeShortLabels[$routingMode] ?? $routingMode) ?></span>
                        <?php endforeach; ?>
                    </div>
                    <details class="agent-technical-summary">
                        <summary>Detalhes técnicos</summary>
                        <div class="agent-technical-grid">
                            <div><span>Acesso à IA</span><strong><?= View::e($agent['credential_label'] ?: 'Configuração da RS Connect') ?></strong></div>
                            <div><span>Economia</span><strong><?= View::e($aiModeLabels[$agent['ai_efficiency_mode'] ?? 'balanced'] ?? 'Equilibrado') ?></strong><small><?= View::e($aiModeHints[$agent['ai_efficiency_mode'] ?? 'balanced'] ?? $aiModeHints['balanced']) ?></small></div>
                            <?php if ($routingKeywordsSummary !== []): ?><div class="agent-technical-wide"><span>Intenções</span><strong><?= View::e(implode(', ', $routingKeywordsSummary)) ?></strong></div><?php endif; ?>
                        </div>
                    </details>
                    <?php if ($canManage && $instances): ?>
                        <a class="agent-routing-jump" href="#agent-settings-<?= (int) $agent['id'] ?>" data-agent-settings-open data-agent-settings-target="#agent-routing-<?= (int) $agent['id'] ?>">Configurar</a>
                    <?php endif; ?>

                    <?php if ($canManage): ?>
                        <details class="agent-prompt agent-prompt-editor">
                            <summary>Editar instruções e informações</summary>
                            <form method="post" action="<?= View::e(Router::url('/agents/prompt')) ?>">
                                <?= Csrf::input() ?>
                                <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>
                                <input type="hidden" name="agent_id" value="<?= (int) $agent['id'] ?>">
                                <label class="field">
                                    <span>Como o assistente deve atender</span>
                                    <textarea class="agent-prompt-textarea" name="system_prompt" rows="16" maxlength="60000" required><?= View::e($agent['system_prompt']) ?></textarea>
                                    <small class="field-hint">Descreva o tom de voz, o que ele pode fazer, o que deve evitar e como conduzir o atendimento.</small>
                                </label>
                                <label class="field">
                                    <span>Informações da empresa</span>
                                    <textarea class="agent-knowledge-textarea" name="knowledge_base" rows="10" maxlength="500000" placeholder="Serviços, horários, links, políticas, respostas frequentes e informações importantes."><?= View::e($agent['knowledge_base'] ?? '') ?></textarea>
                                </label>
                                <div class="agent-prompt-actions">
                                    <span class="muted-text">As mudanças passam a valer nas próximas respostas.</span>
                                    <button class="btn btn-primary" type="submit">Salvar instruções</button>
                                </div>
                            </form>
                        </details>
                        <?php $agentPromptVersions = $promptVersions[(int) $agent['id']] ?? []; ?>
                        <details class="agent-prompt prompt-version-history">
                            <summary>Histórico das instruções <span class="badge"><?= count($agentPromptVersions) ?> versão(ões)</span></summary>
                            <div class="prompt-version-list">
                                <?php foreach ($agentPromptVersions as $version): ?>
                                    <article class="prompt-version-item">
                                        <div>
                                            <strong>Versão <?= (int) ($version['version_number'] ?? 0) ?></strong>
                                            <span><?= View::e($version['title'] ?? 'Instruções salvas') ?></span>
                                            <small><?= View::e($version['created_by_name'] ?? 'Sistema') ?> · <?= View::e($version['created_at'] ?? '') ?> · <?= View::e($version['source'] ?? 'manual') ?></small>
                                        </div>
                                        <form method="post" action="<?= View::e(Router::url('/prompt-studio/restore')) ?>" data-confirm="Restaurar esta versão das instruções?">
                                            <?= Csrf::input() ?>
                                            <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>
                                            <input type="hidden" name="agent_id" value="<?= (int) $agent['id'] ?>">
                                            <input type="hidden" name="version_id" value="<?= (int) ($version['id'] ?? 0) ?>">
                                            <button class="btn btn-quiet btn-sm" type="submit">Restaurar</button>
                                        </form>
                                    </article>
                                <?php endforeach; ?>
                                <?php if (!$agentPromptVersions): ?><div class="empty-state compact-empty">O histórico aparecerá depois que a atualização do banco for concluída ou uma nova versão for salva.</div><?php endif; ?>
                            </div>
                        </details>
                    <?php else: ?>
                        <details class="agent-prompt"><summary>Ver instruções e informações</summary><pre><?= View::e($agent['system_prompt']) ?></pre><?php if (!empty($agent['knowledge_base'])): ?><pre><?= View::e($agent['knowledge_base']) ?></pre><?php endif; ?></details>
                    <?php endif; ?>

                    <?php if ($canManage): ?>
                        <details class="agent-settings-details" id="agent-settings-<?= (int) $agent['id'] ?>">
                            <summary><span><strong>Configurar assistente</strong><small>Canais, distribuição do atendimento, horários, memória e automações.</small></span><span class="drawer-chevron"></span></summary>
                        <form class="agent-actions agent-settings-form" method="post" action="<?= View::e(Router::url('/agents/status')) ?>">
                            <?= Csrf::input() ?>
                            <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>
                            <input type="hidden" name="agent_id" value="<?= (int) $agent['id'] ?>">
                            <input type="hidden" name="channels_present" value="1">

                            <section class="agent-channel-editor" id="agent-routing-<?= (int) $agent['id'] ?>">
                                <div class="agent-channel-editor-head">
                                    <div>
                                        <span class="eyebrow">WhatsApp do assistente</span>
                                        <strong>Em quais números este assistente atende?</strong>
                                        <small>Escolha um ou mais WhatsApps e defina como o atendimento será distribuído em cada número.</small>
                                    </div>
                                    <span class="badge"><?= count($agentChannelBindings) ?> vinculado(s)</span>
                                </div>
                                <?php if ($instances): ?>
                                    <div class="agent-channel-selection-grid">
                                        <?php foreach ($instances as $instance): ?>
                                            <?php
                                            $channelId = (int) $instance['id'];
                                            $channelBinding = $agentChannelBindings[$channelId] ?? null;
                                            $isLinked = is_array($channelBinding);
                                            $routingMode = $isLinked ? $routingModeForBinding($channelBinding) : 'round_robin';
                                            $routingKeywordsValue = $isLinked ? trim((string) ($channelBinding['routing_keywords'] ?? '')) : '';
                                            ?>
                                            <article class="agent-channel-option <?= $isLinked ? 'is-linked' : '' ?>" data-agent-channel-option>
                                                <label class="agent-channel-link-toggle">
                                                    <input type="checkbox" name="instance_ids[]" value="<?= $channelId ?>" <?= $isLinked ? 'checked' : '' ?> data-agent-channel-link>
                                                    <span class="agent-channel-check" aria-hidden="true"></span>
                                                    <span>
                                                        <strong><?= View::e($instance['name']) ?></strong>
                                                        <small><?= $isLinked ? 'Assistente vinculado a este WhatsApp' : 'Marque para vincular este WhatsApp' ?></small>
                                                    </span>
                                                </label>
                                                <div class="agent-channel-routing-config">
                                                    <label class="field compact-field">
                                                        <span>Como atender neste WhatsApp</span>
                                                        <select name="routing_mode[<?= $channelId ?>]" data-routing-mode <?= !$isLinked ? 'disabled' : '' ?>>
                                                            <option value="primary" <?= $routingMode === 'primary' ? 'selected' : '' ?>>Atendimento principal</option>
                                                            <option value="specialist" <?= $routingMode === 'specialist' ? 'selected' : '' ?>>Atender assuntos específicos</option>
                                                            <option value="round_robin" <?= $routingMode === 'round_robin' ? 'selected' : '' ?>>Dividir atendimentos automaticamente</option>
                                                        </select>
                                                    </label>
                                                    <label class="field compact-field agent-routing-keywords <?= $routingMode === 'specialist' ? 'is-visible' : '' ?>" data-routing-keywords-field>
                                                        <span>Assuntos que direcionam para este assistente</span>
                                                        <textarea name="routing_keywords[<?= $channelId ?>]" rows="3" maxlength="1000" placeholder="Ex.: comercial, vendas, planos, preço, orçamento" data-routing-keywords <?= (!$isLinked || $routingMode !== 'specialist') ? 'disabled' : '' ?>><?= View::e($routingKeywordsValue) ?></textarea>
                                                        <small class="field-hint">Quando a mensagem tiver um destes assuntos, a conversa passa para este assistente e continua com ele.</small>
                                                    </label>
                                                    <div class="agent-routing-mode-hint" data-routing-mode-hint></div>
                                                </div>
                                            </article>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="field-hint agent-channel-help">Atendimento principal recebe as conversas gerais. Assuntos específicos recebem apenas os temas escolhidos. Divisão automática reparte novos atendimentos entre os assistentes disponíveis.</p>
                                <?php else: ?>
                                    <div class="message-warning">Cadastre uma conexão em Canais WhatsApp antes de vincular este assistente.</div>
                                <?php endif; ?>
                            </section>

                            <div class="form-grid two">
                                <label class="field compact-field"><span>Disponibilidade do assistente</span><select name="status"><option value="active" <?= $agent['status'] === 'active' ? 'selected' : '' ?>>Ativo</option><option value="inactive" <?= $agent['status'] === 'inactive' ? 'selected' : '' ?>>Inativo</option></select></label>
                                <label class="field compact-field"><span>Nível de economia da IA</span><select name="ai_efficiency_mode"><option value="economy" <?= ($agent['ai_efficiency_mode'] ?? 'balanced') === 'economy' ? 'selected' : '' ?>>Econômico</option><option value="balanced" <?= ($agent['ai_efficiency_mode'] ?? 'balanced') === 'balanced' ? 'selected' : '' ?>>Equilibrado</option><option value="quality" <?= ($agent['ai_efficiency_mode'] ?? 'balanced') === 'quality' ? 'selected' : '' ?>>Qualidade máxima</option></select><small class="field-hint">Controla automaticamente histórico, base de conhecimento e tamanho da resposta.</small></label>
                                <label class="field compact-field"><span>Mensagens lembradas</span><input type="number" name="max_context_messages" value="<?= (int) ($agent['max_context_messages'] ?? 12) ?>" min="4" max="30"><small class="field-hint">Funciona como teto. O modo Econômico usa no máximo 6 e o Equilibrado no máximo 10.</small></label>
                                <label class="field compact-field"><span>Tamanho máximo da resposta</span><input type="number" name="ai_max_output_tokens" value="<?= View::e((string) ($agent['ai_max_output_tokens'] ?? '')) ?>" min="64" max="2000" placeholder="Automático pelo modo"><small class="field-hint">Se ficar vazio, o sistema usa um limite adequado ao nível de economia escolhido.</small></label>
                                <label class="field compact-field"><span>Orçamento da base (caracteres)</span><input type="number" name="ai_knowledge_budget_chars" value="<?= View::e((string) ($agent['ai_knowledge_budget_chars'] ?? '')) ?>" min="1000" max="120000" placeholder="Automático pelo modo"><small class="field-hint">Limita quanto da base de conhecimento entra em cada chamada.</small></label>
                                <label class="field compact-field">
                                    <span>Tempo para juntar mensagens (seg.)</span>
                                    <input type="number" name="cooldown_seconds" value="<?= (int) ($agent['cooldown_seconds'] ?? 15) ?>" min="0" max="120">
                                    <small class="field-hint">Depois da última mensagem do cliente, o assistente espera esse período de silêncio antes de responder. Se chegar outra mensagem, a contagem recomeça.</small>
                                </label>
                            </div>
                            <section class="ai-local-automation-card" style="margin-top:12px">
                                <div class="ai-local-automation-body">
                                    <div class="ai-local-automation-intro"><span class="eyebrow">Conversa natural</span><strong>Responder o conjunto da conversa, não só o último balão</strong><p class="field-hint">Recomendado para WhatsApp: o cliente costuma enviar a mesma ideia em duas ou três mensagens seguidas.</p></div>
                                    <div class="agent-toggle-grid">
                                        <label class="check-field compact-check"><input type="checkbox" name="message_grouping_enabled" value="1" <?= !array_key_exists('message_grouping_enabled', $agent) || (int) ($agent['message_grouping_enabled'] ?? 1) === 1 ? 'checked' : '' ?>><span>Aguardar o cliente terminar e agrupar as mensagens antes de responder</span></label>
                                        <label class="check-field compact-check"><input type="checkbox" name="prioritize_current_turn" value="1" <?= !array_key_exists('prioritize_current_turn', $agent) || (int) ($agent['prioritize_current_turn'] ?? 1) === 1 ? 'checked' : '' ?>><span>Responder primeiro o que o cliente acabou de perguntar e depois retomar o roteiro</span></label>
                                    </div>
                                    <p class="field-hint">Exemplo: se o cliente enviar “quero uma indicação” e logo depois “com quem eu falo mesmo?”, o assistente deve considerar as duas mensagens na mesma resposta e só depois seguir para outra pergunta necessária.</p>
                                </div>
                            </section>
                            <details class="ai-local-automation-card">
                                <summary><span><strong>Respostas sem nova cobrança de IA</strong><small>Saudação opcional por tipo de contato e reaproveitamento antes de chamar o serviço de IA.</small></span><span class="drawer-chevron"></span></summary>
                                <div class="ai-local-automation-body">
                                    <div class="agent-toggle-grid">
                                        <label class="check-field compact-check"><input type="checkbox" name="ai_local_replies_enabled" value="1" <?= !array_key_exists('ai_local_replies_enabled', $agent) || (int) ($agent['ai_local_replies_enabled'] ?? 1) === 1 ? 'checked' : '' ?>><span>Usar respostas locais configuradas</span></label>
                                        <label class="check-field compact-check"><input type="checkbox" name="ai_exact_cache_enabled" value="1" <?= (int) ($agent['ai_exact_cache_enabled'] ?? 0) === 1 ? 'checked' : '' ?>><span>Reutilizar perguntas idênticas elegíveis</span></label>
                                    </div>
                                    <div class="form-grid two">
                                        <label class="field compact-field"><span>Resposta para saudação</span><input name="ai_greeting_reply" value="<?= View::e($agent['ai_greeting_reply'] ?? '') ?>" maxlength="500" placeholder="Olá! Como posso ajudar você hoje?"><small class="field-hint">Usada como resposta pronta sempre que a pessoa enviar apenas uma saudação elegível (oi, olá, bom dia etc.) e como referência para a abertura natural da IA.</small></label>
                                        <label class="field compact-field"><span>Quem recebe a saudação de abertura?</span><select name="ai_greeting_mode"><option value="all_contacts" <?= ($agent['ai_greeting_mode'] ?? 'all_contacts') === 'all_contacts' ? 'selected' : '' ?>>Todos os contatos</option><option value="new_contacts" <?= ($agent['ai_greeting_mode'] ?? '') === 'new_contacts' ? 'selected' : '' ?>>Somente novos contatos; cliente/paciente reconhecido continua naturalmente</option><option value="disabled" <?= ($agent['ai_greeting_mode'] ?? '') === 'disabled' ? 'selected' : '' ?>>Sem saudação automática</option></select><small class="field-hint">Uma saudação enviada pelo contato usa esta política mesmo em uma conversa já existente. Em outras mensagens, a apresentação automática só acontece na abertura do atendimento.</small></label>
                                        <label class="check-field compact-check"><input type="checkbox" name="ai_greeting_use_contact_name" value="1" <?= !array_key_exists('ai_greeting_use_contact_name', $agent) || (int) ($agent['ai_greeting_use_contact_name'] ?? 1) === 1 ? 'checked' : '' ?>><span>Usar o nome do contato quando estiver disponível e soar natural</span></label>
                                        <label class="field compact-field"><span>Resposta para agradecimento</span><input name="ai_gratitude_reply" value="<?= View::e($agent['ai_gratitude_reply'] ?? '') ?>" maxlength="500" placeholder="Por nada! Estou à disposição."></label>
                                        <label class="field compact-field"><span>Resposta para despedida</span><input name="ai_farewell_reply" value="<?= View::e($agent['ai_farewell_reply'] ?? '') ?>" maxlength="500" placeholder="Até mais! Quando precisar, fale com a gente."></label>
                                        <label class="field compact-field"><span>Por quantas horas uma resposta pode ser reaproveitada?</span><input type="number" name="ai_exact_cache_ttl_hours" value="<?= (int) ($agent['ai_exact_cache_ttl_hours'] ?? 168) ?>" min="1" max="720"><small class="field-hint">As respostas salvas são apagadas automaticamente quando as instruções, informações ou modelo mudam.</small></label>
                                    </div>
                                    <label class="field compact-field"><span>Resposta para menu/ajuda</span><textarea name="ai_menu_reply" rows="3" maxlength="4000" placeholder="Liste aqui as opções principais disponíveis."><?= View::e($agent['ai_menu_reply'] ?? '') ?></textarea></label>
                                    <p class="field-hint">As respostas prontas atendem somente mensagens curtas e exatas. O reaproveitamento vem desligado por padrão e não é usado em dados pessoais, pedidos, agenda, números ou links.</p>
                                </div>
                            </details>
                            <details class="ai-local-automation-card ai-memory-config-card">
                                <summary><span><strong>Memória da conversa</strong><small>Cria um resumo de tempos em tempos para lembrar o contexto usando menos IA.</small></span><span class="drawer-chevron"></span></summary>
                                <div class="ai-local-automation-body">
                                    <label class="check-field compact-check"><input type="checkbox" name="ai_progressive_memory_enabled" value="1" <?= !array_key_exists('ai_progressive_memory_enabled', $agent) || (int) ($agent['ai_progressive_memory_enabled'] ?? 1) === 1 ? 'checked' : '' ?>><span>Ativar resumo progressivo e memória estruturada</span></label>
                                    <div class="form-grid two">
                                        <label class="field compact-field"><span>Atualizar a cada N mensagens</span><input type="number" name="ai_memory_refresh_messages" value="<?= (int) ($agent['ai_memory_refresh_messages'] ?? 8) ?>" min="4" max="30"><small class="field-hint">Recomendado: 8. Evita gerar um resumo a cada resposta.</small></label>
                                        <label class="field compact-field"><span>Tamanho máximo do resumo</span><input type="number" name="ai_memory_max_chars" value="<?= (int) ($agent['ai_memory_max_chars'] ?? 2200) ?>" min="800" max="6000"><small class="field-hint">O resumo substitui parte do histórico antigo no contexto.</small></label>
                                    </div>
                                    <p class="field-hint">A memória preserva pedidos, decisões, preferências, pendências e próximos passos. Mensagens recentes sempre prevalecem sobre o resumo.</p>
                                </div>
                            </details>
                            <label class="field compact-field"><span>Palavras que pedem atendimento humano</span><input name="handoff_keywords" value="<?= View::e($agent['handoff_keywords'] ?? '') ?>" placeholder="humano, atendente, pessoa"></label>
                            <label class="field compact-field"><span>Ao chamar uma pessoa</span><select name="handoff_action"><option value="paused" <?= ($agent['handoff_action'] ?? 'paused') === 'paused' ? 'selected' : '' ?>>Pausar respostas automáticas</option><option value="human" <?= ($agent['handoff_action'] ?? '') === 'human' ? 'selected' : '' ?>>Marcar atendimento humano</option></select></label>
                            <label class="field compact-field"><span>Mensagem ao encaminhar para a equipe</span><input name="human_handoff_message" value="<?= View::e($agent['human_handoff_message'] ?? '') ?>" placeholder="Vou encaminhar você para uma pessoa da equipe."></label>
                            <label class="field compact-field"><span>Fuso horário</span><input name="business_timezone" value="<?= View::e($agent['business_timezone'] ?? 'America/Sao_Paulo') ?>"></label>
                            <div class="business-hours-editor" data-business-hours-editor>
                                <div class="business-hours-editor-head"><strong>Horário por dia</strong><small>Ative somente os dias de atendimento e defina a faixa de cada um.</small></div>
                                <?php foreach ($dayLabels as $dayKey => $label): $dayHour = $dayHours[$dayKey] ?? ['enabled' => false, 'start' => '08:00', 'end' => ($dayKey === 'sat' ? '12:00' : '18:00')]; ?>
                                    <div class="business-hours-day <?= !empty($dayHour['enabled']) ? 'is-enabled' : '' ?>" data-business-hours-day>
                                        <label class="business-hours-day-toggle"><input type="checkbox" name="business_day_enabled[<?= View::e($dayKey) ?>]" value="1" <?= !empty($dayHour['enabled']) ? 'checked' : '' ?> data-business-day-toggle><span><?= View::e($label) ?></span></label>
                                        <label class="field compact-field"><span>Início</span><input type="time" name="business_day_start[<?= View::e($dayKey) ?>]" value="<?= View::e((string) $dayHour['start']) ?>" data-business-day-time></label>
                                        <label class="field compact-field"><span>Fim</span><input type="time" name="business_day_end[<?= View::e($dayKey) ?>]" value="<?= View::e((string) $dayHour['end']) ?>" data-business-day-time></label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <label class="field compact-field"><span>Mensagem fora do horário</span><input name="after_hours_message" value="<?= View::e($agent['after_hours_message'] ?? '') ?>" placeholder="Estamos fora do horário. Retornaremos em breve."></label>
                            <?php if (Auth::isSuperAdmin()): ?>
                                <label class="field compact-field"><span>Automação externa deste assistente</span><input name="n8n_webhook_url" value="<?= View::e($agent['n8n_webhook_url'] ?? '') ?>" placeholder="Preencha somente com orientação da equipe RS Connect"><small class="field-hint">Use somente quando este assistente tiver uma automação própria. A Agenda Google é acionada automaticamente quando existe um compromisso real.</small></label>
                                <?php if (!empty($agent['n8n_calendar_conflict'])): ?><div class="message-warning"><strong>Configuração antiga precisa ser corrigida:</strong> este assistente está ligado diretamente a uma automação antiga que cria eventos no Google Calendar. Para evitar agendamentos duplicados, remova o endereço deste campo e mantenha a Agenda somente em Automações (n8n) → Fluxos por empresa.</div><?php endif; ?>
                            <?php else: ?>
                                <div class="message-info"><strong>Integrações técnicas protegidas</strong><span>URLs e acionamento de automações externas são mantidos pela RS Connect para evitar interrupções acidentais.</span></div>
                            <?php endif; ?>
                            <div class="agent-toggle-grid">
                                <label class="check-field compact-check"><input type="checkbox" name="auto_reply_enabled" value="1" <?= (int) ($agent['auto_reply_enabled'] ?? 0) === 1 ? 'checked' : '' ?>><span>Responder automaticamente</span></label>
                                <label class="check-field compact-check"><input type="checkbox" name="business_hours_enabled" value="1" <?= (int) ($agent['business_hours_enabled'] ?? 0) === 1 ? 'checked' : '' ?>><span>Responder somente no horário configurado</span></label>
                                <?php if (Auth::isSuperAdmin()): ?><label class="check-field compact-check"><input type="checkbox" name="n8n_enabled" value="1" <?= (int) ($agent['n8n_enabled'] ?? 0) === 1 ? 'checked' : '' ?>><span>Usar integração externa</span></label><?php endif; ?>
                                <label class="check-field compact-check"><input type="checkbox" name="reply_to_reactions" value="1" <?= (int) ($agent['reply_to_reactions'] ?? 0) === 1 ? 'checked' : '' ?>><span>Responder a reações em mensagens</span></label>
                                <label class="check-field compact-check"><input type="checkbox" name="ai_selective_knowledge" value="1" <?= !array_key_exists('ai_selective_knowledge', $agent) || (int) ($agent['ai_selective_knowledge'] ?? 1) === 1 ? 'checked' : '' ?>><span>Enviar somente trechos relevantes da base</span></label>
                                <label class="check-field compact-check"><input type="checkbox" name="is_default" value="1" <?= (int) $agent['is_default'] === 1 ? 'checked' : '' ?>><span>Assistente de apoio</span></label>
                            </div>
                            <p class="field-hint"><strong>O horário configurado sempre tem prioridade.</strong> Quando “Responder somente no horário configurado” estiver ativo, IA, agenda, seleção de horários e automações conversacionais ficam bloqueadas fora do expediente, mesmo que as instruções do assistente digam para atender 24 horas.</p>
                            <button class="btn btn-outline" type="submit">Salvar configurações</button>
                        </form>
                        </details>

                        <details class="agent-group-rules">
                            <summary>
                                <span><strong>Regras por grupo de contato</strong><small>Defina como pacientes, interessados, familiares e outros grupos devem ser atendidos.</small></span>
                                <span class="drawer-chevron"></span>
                            </summary>
                            <form method="post" action="<?= View::e(Router::url('/agents/group-rules')) ?>">
                                <?= Csrf::input() ?>
                                <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>
                                <input type="hidden" name="agent_id" value="<?= (int) $agent['id'] ?>">
                                <div class="agent-group-rule-grid">
                                    <?php foreach ($contactGroups as $groupKey => $groupLabel): ?>
                                        <?php
                                        $savedRule = $groupRules[(int) $agent['id']][$groupKey] ?? [];
                                        $defaults = match ($groupKey) {
                                            'customer' => ['allow' => 1, 'require' => 0, 'reschedule' => 1, 'instructions' => 'Cliente atual: use cadastro e histórico existentes e não reinicie a triagem como novo interessado. Pergunte somente o que for necessário para o pedido atual.'],
                                            'patient' => ['allow' => 1, 'require' => 0, 'reschedule' => 1, 'instructions' => 'Paciente atual: use o cadastro e o histórico existentes. Não repita perguntas de triagem já respondidas para consultar, marcar ou remarcar horário.'],
                                            'family' => ['allow' => 0, 'require' => 1, 'reschedule' => 0, 'instructions' => 'Siga a regra da empresa para familiares antes de oferecer atendimento ou agenda.'],
                                            'couple' => ['allow' => 0, 'require' => 1, 'reschedule' => 0, 'instructions' => 'Não abra pré-agendamento automático quando a empresa atende somente individualmente.'],
                                            default => ['allow' => 1, 'require' => 1, 'reschedule' => 0, 'instructions' => ''],
                                        };
                                        $allow = array_key_exists('allow_pre_schedule', $savedRule) ? (int) $savedRule['allow_pre_schedule'] : $defaults['allow'];
                                        $require = array_key_exists('require_demand_before_pre_schedule', $savedRule) ? (int) $savedRule['require_demand_before_pre_schedule'] : $defaults['require'];
                                        $reschedule = array_key_exists('allow_reschedule_without_demand', $savedRule) ? (int) $savedRule['allow_reschedule_without_demand'] : $defaults['reschedule'];
                                        $instructions = trim((string) ($savedRule['instructions'] ?? $defaults['instructions']));
                                        ?>
                                        <section class="agent-group-rule-card">
                                            <div><span class="eyebrow">Grupo</span><h4><?= View::e($groupLabel) ?></h4></div>
                                            <label class="check-field compact-check"><input type="checkbox" name="group_rules[<?= View::e($groupKey) ?>][allow_pre_schedule]" value="1" <?= $allow === 1 ? 'checked' : '' ?>><span>Permitir pré-agendamento</span></label>
                                            <?php if (in_array($groupKey, ['customer', 'patient'], true)): ?>
                                                <div class="agent-rule-fixed-note"><strong>Triagem já conhecida</strong><span>Para clientes e pacientes atuais, o assistente usa o histórico e não exige novamente o motivo do atendimento antes da agenda.</span></div>
                                            <?php else: ?>
                                                <label class="check-field compact-check"><input type="checkbox" name="group_rules[<?= View::e($groupKey) ?>][require_demand_before_pre_schedule]" value="1" <?= $require === 1 ? 'checked' : '' ?>><span>Pedir o motivo antes de consultar a agenda</span></label>
                                            <?php endif; ?>
                                            <label class="check-field compact-check"><input type="checkbox" name="group_rules[<?= View::e($groupKey) ?>][allow_reschedule_without_demand]" value="1" <?= $reschedule === 1 ? 'checked' : '' ?>><span>Permitir remarcação sem repetir a demanda</span></label>
                                            <label class="field compact-field"><span>Orientação específica</span><textarea name="group_rules[<?= View::e($groupKey) ?>][instructions]" rows="4" placeholder="Explique como o assistente deve agir com este grupo."><?= View::e($instructions) ?></textarea></label>
                                        </section>
                                    <?php endforeach; ?>
                                </div>
                                <div class="agent-group-rule-actions"><button class="btn btn-primary" type="submit">Salvar regras dos grupos</button></div>
                            </form>
                        </details>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
            <?php if (!$agents): ?><div class="empty-state">Nenhum assistente cadastrado ainda.</div><?php endif; ?>
        </div>
    </section>
</div>

<?php if ($canManage): ?>
<?php if ($isClientExperience): ?>
<aside class="conversation-details agent-create-drawer agent-client-drawer" id="agent-create-drawer" aria-label="Criar novo assistente" aria-modal="true" role="dialog">
    <div class="conversation-drawer-header agent-client-drawer-header">
        <div>
            <span class="eyebrow">Novo assistente</span>
            <h2>Crie seu assistente de atendimento</h2>
            <p>Defina quem ele atende, como conversa e quais informações pode usar nas respostas.</p>
        </div>
        <button class="icon-button drawer-close" type="button" data-close-panel="agent-create-drawer" aria-label="Fechar painel">×</button>
    </div>

    <form class="drawer-form agent-create-form agent-guided-form" method="post" action="<?= View::e(Router::url('/agents')) ?>" data-prompt-studio data-prompt-endpoint="<?= View::e(Router::url('/prompt-studio/generate')) ?>">
        <?= Csrf::input() ?>
        <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>
        <div class="agent-drawer-progress" aria-label="Etapas do cadastro">
            <span><b>1</b> Identificação</span>
            <span><b>2</b> Atendimento</span>
            <span><b>3</b> Empresa</span>
            <span><b>4</b> Prompt</span>
        </div>

        <div class="conversation-drawer-body agent-client-drawer-body">
            <section class="drawer-section agent-step-card">
                <div class="drawer-section-title">
                    <div><span class="eyebrow">Etapa 1</span><h3>Quem vai atender?</h3><p>Escolha o WhatsApp e dê uma identidade simples ao assistente.</p></div>
                </div>
                <div class="drawer-form-grid">
                    <label class="field drawer-span"><span>Canal inicial</span><select name="instance_id" required><option value="">Selecione o WhatsApp</option><?php foreach ($instances as $instance): ?><option value="<?= (int) $instance['id'] ?>"><?= View::e($instance['name']) ?></option><?php endforeach; ?></select><small class="field-hint">É o primeiro número em que ele atuará. Outros canais podem ser adicionados depois.</small></label>
                    <label class="field"><span>Como atender neste WhatsApp</span><select name="routing_mode" data-routing-mode><option value="primary" <?= count($agents) === 0 ? 'selected' : '' ?>>Atendimento principal</option><option value="specialist">Atender assuntos específicos</option><option value="round_robin" <?= count($agents) > 0 ? 'selected' : '' ?>>Dividir atendimentos automaticamente</option></select><small class="field-hint">Você poderá alterar esta opção a qualquer momento.</small></label>
                    <label class="field agent-routing-keywords" data-routing-keywords-field><span>Assuntos que direcionam para este assistente</span><input name="routing_keywords" maxlength="1000" placeholder="comercial, vendas, planos, preço, orçamento" data-routing-keywords disabled><small class="field-hint">Preencha quando escolher “Atender assuntos específicos”.</small></label>
                    <label class="field"><span>Nome do assistente</span><input name="name" placeholder="Ex.: Digi" required></label>
                    <label class="field"><span>Área de atendimento</span><input name="segment" placeholder="Ex.: vendas e agendamentos" data-agent-segment required></label>
                    <label class="field drawer-span"><span>Objetivo do atendimento</span><textarea name="service_objective" rows="4" placeholder="Ex.: responder dúvidas, identificar a necessidade do cliente, apresentar os serviços e encaminhar oportunidades para a equipe." required></textarea><small class="field-hint">Explique em palavras simples o resultado esperado de cada conversa.</small></label>
                </div>
            </section>

            <section class="drawer-section agent-step-card">
                <div class="drawer-section-title">
                    <div><span class="eyebrow">Etapa 2</span><h3>Como ele deve responder?</h3><p>Defina o estilo da conversa e as regras mais importantes.</p></div>
                </div>
                <div class="drawer-form-grid">
                    <label class="field"><span>Tom de voz</span><select name="tone_of_voice"><option value="claro, cordial e profissional">Claro e profissional</option><option value="acolhedor, paciente e próximo">Acolhedor e próximo</option><option value="objetivo, direto e consultivo">Objetivo e consultivo</option><option value="descontraído, simpático e respeitoso">Descontraído e simpático</option></select></label>
                    <label class="field"><span>Mensagem de boas-vindas</span><input name="welcome_message" placeholder="Ex.: Olá! Como posso ajudar você hoje?"></label>
                    <label class="field drawer-span"><span>Regras principais</span><textarea name="assistant_rules" rows="7" placeholder="Ex.: faça uma pergunta por vez; não informe preços sem confirmar; encaminhe para uma pessoa quando o cliente pedir; nunca invente informações." required></textarea></label>
                    <label class="field drawer-span"><span>Público principal</span><textarea name="audience" rows="3" placeholder="Ex.: clientes atuais, novos interessados, pacientes, responsáveis ou empresas parceiras."></textarea></label>
                    <label class="field drawer-span"><span>Produtos e serviços</span><textarea name="services" rows="5" placeholder="Liste os serviços e explique brevemente o que pode ser apresentado ao contato."></textarea></label>
                    <label class="field drawer-span"><span>Informações autorizadas</span><textarea name="allowed_information" rows="4" placeholder="Preços confirmados, prazos, links, políticas e informações que o agente pode informar com segurança."></textarea></label>
                    <label class="field drawer-span"><span>Perguntas essenciais</span><textarea name="required_questions" rows="4" placeholder="Quais dados são realmente necessários? Ex.: nome, serviço desejado e melhor período."></textarea></label>
                    <div class="form-grid two drawer-span">
                        <label class="field"><span>Como tratar novos interessados</span><textarea name="lead_rules" rows="4" placeholder="Ex.: entender a demanda e apresentar o próximo passo sem pressionar."></textarea></label>
                        <label class="field"><span>Como tratar clientes atuais</span><textarea name="customer_rules" rows="4" placeholder="Ex.: usar cadastro e histórico, sem reiniciar a triagem."></textarea></label>
                    </div>
                    <label class="field drawer-span"><span>Regras de agenda</span><textarea name="agenda_rules" rows="4" placeholder="Ex.: perguntar modalidade, nunca inventar disponibilidade e aguardar aprovação quando exigida."></textarea></label>
                    <label class="field drawer-span"><span>Quando encaminhar para uma pessoa</span><textarea name="handoff_rules" rows="4" placeholder="Ex.: quando o cliente pedir humano, houver reclamação sensível ou faltar autorização."></textarea></label>
                    <label class="field drawer-span"><span>O que o agente nunca deve fazer</span><textarea name="forbidden_information" rows="4" placeholder="Ex.: inventar preço, prometer prazo, confirmar agenda sem retorno ou expor dados internos."></textarea></label>
                    <label class="field drawer-span"><span>Exemplos de bom comportamento</span><textarea name="examples" rows="5" placeholder="Ex.: Cliente: quero remarcar. Assistente: claro, vou verificar seu agendamento atual e as opções disponíveis."></textarea></label>
                    <input type="hidden" name="response_style" value="mensagens curtas, naturais e com uma pergunta por vez">
                </div>
                <div class="agent-create-behavior agent-friendly-toggles">
                    <label class="switch-card"><input type="checkbox" name="auto_reply_enabled" value="1" checked><span><strong>Responder automaticamente</strong><small>O assistente responde quando a conversa estiver no modo IA ativa.</small></span></label>
                    <label class="switch-card"><input type="checkbox" name="is_default" value="1"><span><strong>Assistente de apoio</strong><small>Usado apenas quando um número ainda não tem um assistente principal definido. O responsável de cada WhatsApp é escolhido em Canais WhatsApp.</small></span></label>
                </div>
            </section>

            <section class="drawer-section agent-step-card">
                <div class="drawer-section-title">
                    <div><span class="eyebrow">Etapa 3</span><h3>O que ele precisa saber sobre a empresa?</h3><p>Revise as informações que poderão ser usadas nas respostas.</p></div>
                </div>
                <label class="field"><span>Informações da empresa</span><textarea name="knowledge_base" rows="11" placeholder="Serviços, horários, links, políticas, perguntas frequentes e outras informações importantes."><?= View::e($defaultCompanyKnowledge) ?></textarea><small class="field-hint">O conteúdo foi preenchido com os dados do Perfil da empresa. Você pode complementar antes de criar.</small></label>
            </section>

            <section class="drawer-section agent-step-card prompt-studio-output">
                <div class="drawer-section-title">
                    <div><span class="eyebrow">Etapa 4</span><h3>Criar e revisar as instruções</h3><p>O RS Connect organiza as orientações do assistente e verifica conflitos com horário, agenda e regras de atendimento.</p></div>
                </div>
                <div class="prompt-studio-toolbar">
                    <button class="btn btn-outline" type="button" data-prompt-generate>Criar instruções organizadas</button>
                    <span class="muted-text" data-prompt-status>Preencha as etapas anteriores e gere a primeira versão.</span>
                </div>
                <div class="prompt-studio-warnings" data-prompt-warnings hidden></div>
                <label class="field"><span>Instruções finais do assistente</span><textarea class="agent-prompt-textarea" name="system_prompt" rows="18" maxlength="60000" placeholder="As instruções organizadas aparecerão aqui. Você poderá revisar antes de criar o assistente." required></textarea><small class="field-hint">Revise e altere qualquer parte antes de salvar.</small></label>
                <input type="hidden" name="prompt_studio_generated" value="0" data-prompt-generated>
                <input type="hidden" name="prompt_studio_answers_json" value="" data-prompt-answers>
                <input type="hidden" name="prompt_studio_warnings_json" value="" data-prompt-warnings-json>
            </section>

            <details class="drawer-section drawer-collapsed-card agent-advanced-settings">
                <summary>
                    <span><span class="eyebrow">Opcional</span><strong>Configurações avançadas</strong><small>Horários, transferência para a equipe e ajustes técnicos.</small></span>
                    <span class="drawer-chevron"></span>
                </summary>
                <div class="agent-advanced-body">
                    <div class="form-grid two">
                        <label class="field"><span>Estilo das respostas</span><select name="temperature"><option value="0.1">Mais objetivo</option><option value="0.2" selected>Equilibrado</option><option value="0.5">Mais criativo</option><option value="0.8">Bem criativo</option></select></label>
                        <div class="message-info"><strong>Serviço de IA protegido</strong><span>Chave, provedor e modelo técnico são definidos pela RS Connect para evitar incompatibilidades. Você continua controlando instruções, estilo e regras do atendimento.</span></div>
                    </div>
                    <label class="field"><span>Palavras para chamar uma pessoa</span><input name="handoff_keywords" value="humano, atendente, pessoa, suporte"></label>
                    <label class="field"><span>Mensagem ao encaminhar para a equipe</span><input name="human_handoff_message" value="Vou encaminhar você para uma pessoa da nossa equipe. Aguarde um momento, por favor."></label>
                    <input type="hidden" name="handoff_action" value="paused">
                    <label class="field"><span>Fuso horário</span><input name="business_timezone" value="America/Sao_Paulo"></label>
                    <div class="business-hours-editor" data-business-hours-editor>
                        <div class="business-hours-editor-head"><strong>Horário por dia</strong><small>Você pode, por exemplo, usar Seg–Sex 08:00–17:00 e Sáb 08:00–12:00.</small></div>
                        <?php foreach ($dayLabels as $dayKey => $label): $enabledByDefault = in_array($dayKey, ['mon','tue','wed','thu','fri'], true); ?>
                            <div class="business-hours-day <?= $enabledByDefault ? 'is-enabled' : '' ?>" data-business-hours-day>
                                <label class="business-hours-day-toggle"><input type="checkbox" name="business_day_enabled[<?= View::e($dayKey) ?>]" value="1" <?= $enabledByDefault ? 'checked' : '' ?> data-business-day-toggle><span><?= View::e($label) ?></span></label>
                                <label class="field"><span>Início</span><input type="time" name="business_day_start[<?= View::e($dayKey) ?>]" value="08:00" data-business-day-time></label>
                                <label class="field"><span>Fim</span><input type="time" name="business_day_end[<?= View::e($dayKey) ?>]" value="<?= $dayKey === 'sat' ? '12:00' : '18:00' ?>" data-business-day-time></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <label class="field"><span>Mensagem fora do horário</span><input name="after_hours_message" value="Estamos fora do horário de atendimento agora. Assim que retornarmos, nossa equipe responde por aqui."></label>
                    <div class="ai-efficiency-create-card">
                        <div><span class="eyebrow">Economia de IA</span><strong>Estratégia de consumo</strong><small>O modo Equilibrado é recomendado para começar.</small></div>
                        <div class="form-grid two">
                            <label class="field"><span>Modo</span><select name="ai_efficiency_mode"><option value="economy">Econômico</option><option value="balanced" selected>Equilibrado</option><option value="quality">Qualidade máxima</option></select></label>
                            <label class="field"><span>Mensagens lembradas</span><input type="number" name="max_context_messages" value="12" min="4" max="30"></label>
                            <label class="field"><span>Tamanho máximo da resposta</span><input type="number" name="ai_max_output_tokens" min="64" max="2000" placeholder="Automático pelo modo"></label>
                            <label class="field"><span>Base por chamada (caracteres)</span><input type="number" name="ai_knowledge_budget_chars" min="1000" max="120000" placeholder="Automático pelo modo"></label>
                        </div>
                        <label class="check-field"><input type="checkbox" name="ai_selective_knowledge" value="1" checked><span>Enviar somente os trechos da base relacionados à conversa</span></label>
                    </div>
                    <details class="ai-local-automation-card">
                        <summary><span><strong>Respostas sem nova cobrança de IA</strong><small>Configure a saudação e escolha se cliente/paciente reconhecido deve receber boas-vindas ou continuidade natural.</small></span><span class="drawer-chevron"></span></summary>
                        <div class="ai-local-automation-body">
                            <label class="check-field"><input type="checkbox" name="ai_local_replies_enabled" value="1" checked><span>Usar respostas locais configuradas</span></label>
                            <div class="form-grid two">
                                <label class="field"><span>Saudação</span><input name="ai_greeting_reply" maxlength="500" placeholder="Olá! Como posso ajudar você hoje?"></label>
                                <label class="field"><span>Quem recebe a saudação?</span><select name="ai_greeting_mode"><option value="all_contacts">Todos os contatos</option><option value="new_contacts" selected>Somente novos contatos; cliente/paciente reconhecido continua naturalmente</option><option value="disabled">Sem saudação automática</option></select><small class="field-hint">Se a mensagem for apenas uma saudação, esta política é aplicada mesmo em conversa já existente; a abertura automática da IA continua restrita ao início do atendimento.</small></label>
                                <label class="check-field"><input type="checkbox" name="ai_greeting_use_contact_name" value="1" checked><span>Usar o nome do contato quando estiver disponível e soar natural</span></label>
                                <label class="field"><span>Agradecimento</span><input name="ai_gratitude_reply" maxlength="500" placeholder="Por nada! Estou à disposição."></label>
                                <label class="field"><span>Despedida</span><input name="ai_farewell_reply" maxlength="500" placeholder="Até mais! Quando precisar, fale com a gente."></label>
                                <label class="field"><span>Por quantas horas uma resposta pode ser reaproveitada?</span><input type="number" name="ai_exact_cache_ttl_hours" value="168" min="1" max="720"></label>
                            </div>
                            <label class="field"><span>Menu/ajuda</span><textarea name="ai_menu_reply" rows="3" maxlength="4000" placeholder="Liste as opções principais disponíveis."></textarea></label>
                            <label class="check-field"><input type="checkbox" name="ai_exact_cache_enabled" value="1"><span>Reutilizar respostas para perguntas idênticas e elegíveis</span></label>
                            <small class="field-hint">Respostas reaproveitadas não são usadas para agenda, dados pessoais, números, links ou mensagens que dependem da conversa.</small>
                        </div>
                    </details>
                    <div class="ai-local-automation-card">
                        <div class="ai-local-automation-body">
                            <input type="hidden" name="message_grouping_present" value="1">
                            <input type="hidden" name="current_turn_priority_present" value="1">
                            <div class="ai-local-automation-intro"><span class="eyebrow">Conversa natural</span><strong>Agrupar mensagens antes de responder</strong><p class="field-hint">Evita responder no meio da fala quando o cliente divide a mesma ideia em vários balões.</p></div>
                            <label class="check-field"><input type="checkbox" name="message_grouping_enabled" value="1" checked><span>Aguardar o cliente terminar e juntar as mensagens</span></label>
                            <label class="field"><span>Tempo de silêncio antes da resposta (seg.)</span><input type="number" name="cooldown_seconds" value="10" min="2" max="120"><small class="field-hint">Se chegar outra mensagem dentro desse tempo, a contagem recomeça e o novo balão entra na mesma resposta.</small></label>
                            <label class="check-field"><input type="checkbox" name="prioritize_current_turn" value="1" checked><span>Responder primeiro as perguntas atuais e depois continuar o roteiro</span></label>
                        </div>
                    </div>
                    <div class="message-info"><strong>Integrações técnicas</strong><span>Endereços de automação externa são mantidos pela RS Connect. Isso evita que uma alteração acidental interrompa agenda, callbacks ou outros fluxos críticos.</span></div>
                    <label class="check-field"><input type="checkbox" name="business_hours_enabled" value="1"><span>Responder somente no horário configurado</span></label>
                    <p class="field-hint">Quando ativado, este horário tem prioridade e pausa a IA, a agenda e outras automações fora do expediente.</p>
                    <label class="check-field"><input type="checkbox" name="reply_to_reactions" value="1"><span>Responder quando o contato reagir a uma mensagem</span><small class="field-hint">Desativado por padrão. Curtidas e emojis de reação não geram resposta automática.</small></label>
                </div>
            </details>
        </div>

        <div class="drawer-savebar agent-create-savebar agent-client-savebar">
            <button class="btn btn-quiet" type="button" data-close-panel="agent-create-drawer">Cancelar</button>
            <button class="btn btn-primary" type="submit" <?= !$instances ? 'disabled' : '' ?>>Criar assistente</button>
            <?php if (!$instances): ?><p class="field-hint">A equipe RS Connect precisa preparar uma conexão WhatsApp primeiro.</p><?php endif; ?>
        </div>
    </form>
</aside>
<?php else: ?>
<aside class="conversation-details agent-create-drawer" id="agent-create-drawer" aria-label="Cadastrar novo assistente">
    <div class="conversation-drawer-header">
        <div>
            <span class="eyebrow">Novo assistente</span>
            <h2>Criar assistente virtual</h2>
            <p>Preencha primeiro as informações essenciais. As opções técnicas ficam agrupadas no final.</p>
        </div>
        <button class="icon-button drawer-close" type="button" data-close-panel="agent-create-drawer" aria-label="Fechar painel">×</button>
    </div>

    <div class="conversation-drawer-body">
        <form class="drawer-form agent-create-form" method="post" action="<?= View::e(Router::url('/agents')) ?>" data-prompt-studio data-prompt-endpoint="<?= View::e(Router::url('/prompt-studio/generate')) ?>">
            <?= Csrf::input() ?>
            <?php if (Auth::isSuperAdmin()): ?><input type="hidden" name="tenant_id" value="<?= $selectedTenantId ?>"><?php endif; ?>

            <section class="drawer-section">
                <div class="drawer-section-title"><div><span class="eyebrow">1. Identificação</span><h3>Quem vai atender?</h3></div></div>
                <label class="field"><span>Canal inicial</span><select name="instance_id" required><option value="">Selecione o WhatsApp</option><?php foreach ($instances as $instance): ?><option value="<?= (int) $instance['id'] ?>"><?= View::e($instance['name']) ?></option><?php endforeach; ?></select><small class="field-hint">Escolha o primeiro WhatsApp deste assistente. Depois você pode vinculá-lo a outros canais na tela WhatsApp.</small></label>
                <label class="field"><span>Como atender neste WhatsApp</span><select name="routing_mode" data-routing-mode><option value="primary" <?= count($agents) === 0 ? 'selected' : '' ?>>Atendimento principal</option><option value="specialist">Atender assuntos específicos</option><option value="round_robin" <?= count($agents) > 0 ? 'selected' : '' ?>>Dividir atendimentos automaticamente</option></select></label>
                <label class="field agent-routing-keywords" data-routing-keywords-field><span>Assuntos que direcionam para este assistente</span><input name="routing_keywords" maxlength="1000" placeholder="comercial, vendas, planos, preço, orçamento" data-routing-keywords disabled><small class="field-hint">Preencha quando escolher “Atender assuntos específicos”.</small></label>
                <label class="field"><span>Nome do assistente</span><input name="name" placeholder="Ex.: Digi, Assistente Comercial" required></label>
                <label class="field"><span>Área de atendimento</span><input name="segment" placeholder="Ex.: vendas, suporte, agendamentos" data-agent-segment required><small class="field-hint">Ajuda a identificar a função principal do assistente.</small></label>
            </section>

            <section class="drawer-section prompt-studio-output">
                <div class="drawer-section-title"><div><span class="eyebrow">2. Criador de instruções</span><h3>O que ele deve saber e fazer?</h3><p>Responda ao questionário e gere uma estrutura consistente antes de salvar.</p></div></div>
                <label class="field"><span>Objetivo do atendimento</span><textarea name="service_objective" rows="4" placeholder="Resultado esperado de cada conversa." required></textarea></label>
                <div class="form-grid two">
                    <label class="field"><span>Tom de voz</span><select name="tone_of_voice"><option value="claro, cordial e profissional">Claro e profissional</option><option value="acolhedor, paciente e próximo">Acolhedor e próximo</option><option value="objetivo, direto e consultivo">Objetivo e consultivo</option></select></label>
                    <label class="field"><span>Público principal</span><input name="audience" placeholder="Clientes, leads, pacientes..."></label>
                </div>
                <label class="field"><span>Produtos e serviços</span><textarea name="services" rows="4"></textarea></label>
                <label class="field"><span>Regras principais</span><textarea name="assistant_rules" rows="5" placeholder="Uma pergunta por vez, regras comerciais e limites."></textarea></label>
                <div class="form-grid two">
                    <label class="field"><span>Novos interessados</span><textarea name="lead_rules" rows="4"></textarea></label>
                    <label class="field"><span>Clientes atuais</span><textarea name="customer_rules" rows="4"></textarea></label>
                </div>
                <label class="field"><span>Agenda</span><textarea name="agenda_rules" rows="4"></textarea></label>
                <label class="field"><span>Transferência humana</span><textarea name="handoff_rules" rows="4"></textarea></label>
                <label class="field"><span>Restrições</span><textarea name="forbidden_information" rows="4"></textarea></label>
                <input type="hidden" name="response_style" value="mensagens curtas, naturais e com uma pergunta por vez">
                <div class="prompt-studio-toolbar"><button class="btn btn-outline" type="button" data-prompt-generate>Criar instruções organizadas</button><span class="muted-text" data-prompt-status>As instruções serão comparadas com as regras de atendimento.</span></div>
                <div class="prompt-studio-warnings" data-prompt-warnings hidden></div>
                <label class="field"><span>Instruções finais</span><textarea name="system_prompt" rows="16" maxlength="60000" required></textarea></label>
                <input type="hidden" name="prompt_studio_generated" value="0" data-prompt-generated>
                <input type="hidden" name="prompt_studio_answers_json" value="" data-prompt-answers>
                <input type="hidden" name="prompt_studio_warnings_json" value="" data-prompt-warnings-json>
                <label class="field"><span>Informações da empresa</span><textarea name="knowledge_base" rows="7" placeholder="Inclua serviços, horários, perguntas frequentes, regras, links e informações que podem ser usadas nas respostas."></textarea></label>
            </section>

            <section class="drawer-section agent-create-behavior">
                <div class="drawer-section-title"><div><span class="eyebrow">3. Funcionamento</span><h3>Comportamento inicial</h3></div></div>
                <label class="check-field"><input type="checkbox" name="auto_reply_enabled" value="1" checked><span>Responder automaticamente quando a conversa estiver com IA ativa</span></label>
                <label class="check-field"><input type="checkbox" name="is_default" value="1"><span>Usar como assistente de apoio da empresa</span></label>
            </section>

            <details class="drawer-section drawer-collapsed-card agent-advanced-settings">
                <summary>
                    <span><span class="eyebrow">Opcional</span><strong>Configurações avançadas</strong><small>Modelo de IA, horários, transferência e integração externa.</small></span>
                    <span class="drawer-chevron"></span>
                </summary>
                <div class="agent-advanced-body">
                    <div class="form-grid two">
                        <label class="field"><span>Serviço de IA</span><select name="model_provider"><option value="openai">OpenAI</option><option value="google">Google Gemini</option><option value="custom">Outro serviço</option></select></label>
                        <label class="field"><span>Estilo das respostas</span><select name="temperature"><option value="0.1">Mais objetivo</option><option value="0.2" selected>Equilibrado</option><option value="0.5">Mais criativo</option><option value="0.8">Bem criativo</option></select></label>
                    </div>
                    <label class="field"><span>Modelo de IA</span><input name="model_name" value="gpt-4o-mini" required><small class="field-hint">A equipe RS Connect pode ajustar este campo conforme a chave e o modelo disponíveis.</small></label>
                    <label class="field"><span>Palavras que pedem atendimento humano</span><input name="handoff_keywords" value="humano, atendente, pessoa, suporte" placeholder="humano, atendente, pessoa"></label>
                    <label class="field"><span>Mensagem ao encaminhar para a equipe</span><input name="human_handoff_message" value="Vou encaminhar você para uma pessoa da nossa equipe. Aguarde um momento, por favor."></label>
                    <input type="hidden" name="handoff_action" value="paused">
                    <label class="field"><span>Fuso horário</span><input name="business_timezone" value="America/Sao_Paulo"></label>
                    <div class="business-hours-editor" data-business-hours-editor>
                        <div class="business-hours-editor-head"><strong>Horário por dia</strong><small>Você pode, por exemplo, usar Seg–Sex 08:00–17:00 e Sáb 08:00–12:00.</small></div>
                        <?php foreach ($dayLabels as $dayKey => $label): $enabledByDefault = in_array($dayKey, ['mon','tue','wed','thu','fri'], true); ?>
                            <div class="business-hours-day <?= $enabledByDefault ? 'is-enabled' : '' ?>" data-business-hours-day>
                                <label class="business-hours-day-toggle"><input type="checkbox" name="business_day_enabled[<?= View::e($dayKey) ?>]" value="1" <?= $enabledByDefault ? 'checked' : '' ?> data-business-day-toggle><span><?= View::e($label) ?></span></label>
                                <label class="field"><span>Início</span><input type="time" name="business_day_start[<?= View::e($dayKey) ?>]" value="08:00" data-business-day-time></label>
                                <label class="field"><span>Fim</span><input type="time" name="business_day_end[<?= View::e($dayKey) ?>]" value="<?= $dayKey === 'sat' ? '12:00' : '18:00' ?>" data-business-day-time></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <label class="field"><span>Mensagem fora do horário</span><input name="after_hours_message" value="Estamos fora do horário de atendimento agora. Assim que retornarmos, nossa equipe responde por aqui."></label>
                    <div class="ai-efficiency-create-card">
                        <div><span class="eyebrow">Economia de IA</span><strong>Estratégia de consumo</strong><small>O modo Equilibrado é recomendado para começar.</small></div>
                        <div class="form-grid two">
                            <label class="field"><span>Modo</span><select name="ai_efficiency_mode"><option value="economy">Econômico</option><option value="balanced" selected>Equilibrado</option><option value="quality">Qualidade máxima</option></select></label>
                            <label class="field"><span>Mensagens lembradas</span><input type="number" name="max_context_messages" value="12" min="4" max="30"></label>
                            <label class="field"><span>Tamanho máximo da resposta</span><input type="number" name="ai_max_output_tokens" min="64" max="2000" placeholder="Automático pelo modo"></label>
                            <label class="field"><span>Base por chamada (caracteres)</span><input type="number" name="ai_knowledge_budget_chars" min="1000" max="120000" placeholder="Automático pelo modo"></label>
                        </div>
                        <label class="check-field"><input type="checkbox" name="ai_selective_knowledge" value="1" checked><span>Enviar somente os trechos da base relacionados à conversa</span></label>
                    </div>
                    <details class="ai-local-automation-card">
                        <summary><span><strong>Respostas sem nova cobrança de IA</strong><small>Configure a saudação e escolha se cliente/paciente reconhecido deve receber boas-vindas ou continuidade natural.</small></span><span class="drawer-chevron"></span></summary>
                        <div class="ai-local-automation-body">
                            <label class="check-field"><input type="checkbox" name="ai_local_replies_enabled" value="1" checked><span>Usar respostas locais configuradas</span></label>
                            <div class="form-grid two">
                                <label class="field"><span>Saudação</span><input name="ai_greeting_reply" maxlength="500" placeholder="Olá! Como posso ajudar você hoje?"></label>
                                <label class="field"><span>Quem recebe a saudação?</span><select name="ai_greeting_mode"><option value="all_contacts">Todos os contatos</option><option value="new_contacts" selected>Somente novos contatos; cliente/paciente reconhecido continua naturalmente</option><option value="disabled">Sem saudação automática</option></select><small class="field-hint">Se a mensagem for apenas uma saudação, esta política é aplicada mesmo em conversa já existente; a abertura automática da IA continua restrita ao início do atendimento.</small></label>
                                <label class="check-field"><input type="checkbox" name="ai_greeting_use_contact_name" value="1" checked><span>Usar o nome do contato quando estiver disponível e soar natural</span></label>
                                <label class="field"><span>Agradecimento</span><input name="ai_gratitude_reply" maxlength="500" placeholder="Por nada! Estou à disposição."></label>
                                <label class="field"><span>Despedida</span><input name="ai_farewell_reply" maxlength="500" placeholder="Até mais! Quando precisar, fale com a gente."></label>
                                <label class="field"><span>Por quantas horas uma resposta pode ser reaproveitada?</span><input type="number" name="ai_exact_cache_ttl_hours" value="168" min="1" max="720"></label>
                            </div>
                            <label class="field"><span>Menu/ajuda</span><textarea name="ai_menu_reply" rows="3" maxlength="4000" placeholder="Liste as opções principais disponíveis."></textarea></label>
                            <label class="check-field"><input type="checkbox" name="ai_exact_cache_enabled" value="1"><span>Reutilizar respostas para perguntas idênticas e elegíveis</span></label>
                            <small class="field-hint">Respostas reaproveitadas não são usadas para agenda, dados pessoais, números, links ou mensagens que dependem da conversa.</small>
                        </div>
                    </details>
                    <div class="ai-local-automation-card">
                        <div class="ai-local-automation-body">
                            <input type="hidden" name="message_grouping_present" value="1">
                            <input type="hidden" name="current_turn_priority_present" value="1">
                            <div class="ai-local-automation-intro"><span class="eyebrow">Conversa natural</span><strong>Agrupar mensagens antes de responder</strong><p class="field-hint">Evita responder no meio da fala quando o cliente divide a mesma ideia em vários balões.</p></div>
                            <label class="check-field"><input type="checkbox" name="message_grouping_enabled" value="1" checked><span>Aguardar o cliente terminar e juntar as mensagens</span></label>
                            <label class="field"><span>Tempo de silêncio antes da resposta (seg.)</span><input type="number" name="cooldown_seconds" value="10" min="2" max="120"><small class="field-hint">Se chegar outra mensagem dentro desse tempo, a contagem recomeça e o novo balão entra na mesma resposta.</small></label>
                            <label class="check-field"><input type="checkbox" name="prioritize_current_turn" value="1" checked><span>Responder primeiro as perguntas atuais e depois continuar o roteiro</span></label>
                        </div>
                    </div>
                    <label class="field"><span>Integração externa</span><input name="n8n_webhook_url" placeholder="Preencha somente com orientação da equipe RS Connect"></label>
                    <label class="check-field"><input type="checkbox" name="business_hours_enabled" value="1"><span>Responder somente no horário configurado</span></label>
                    <p class="field-hint">Quando ativado, este horário tem prioridade e pausa a IA, a agenda e outras automações fora do expediente.</p>
                    <label class="check-field"><input type="checkbox" name="n8n_enabled" value="1"><span>Usar integração externa neste assistente</span></label>
                    <label class="check-field"><input type="checkbox" name="reply_to_reactions" value="1"><span>Responder quando o contato reagir a uma mensagem</span><small class="field-hint">Desativado por padrão. Curtidas e emojis de reação não geram resposta automática.</small></label>
                </div>
            </details>

            <div class="drawer-savebar agent-create-savebar">
                <button class="btn btn-primary btn-block" type="submit" <?= !$instances ? 'disabled' : '' ?>>Criar assistente</button>
                <?php if (!$instances): ?><p class="field-hint">A equipe RS Connect precisa preparar uma conexão WhatsApp primeiro.</p><?php endif; ?>
            </div>
        </form>
    </div>
</aside>
<?php endif; ?>
<?php endif; ?>
