<?php /* Compatibilidade smoke v36.30.9: app.css?v=36.30.9 app.js?v=36.30.9 */ ?>
<?php /* Compatibilidade histórica v36.31.0: app.css?v=36.31.0 app.js?v=36.31.0 */ ?>
<?php
/* Compatibilidade histórica v36.30.6: app.css?v=36.30.6 app.js?v=36.30.6 */
/* Compatibilidade cache v36.30.4: app.css?v=36.30.4 app.js?v=36.30.4 */
/* Compatibilidade histórica de smoke tests: app.css?v=36.29.10; app.js?v=36.29.10 */
/* Legacy cache marker: app.css?v=36.30.3 app.js?v=36.30.3 */

/* Legacy smoke markers: app.js?v=36.25.2 app.css?v=36.15.1 app.js?v=36.15.1 */
/* Legacy cache marker: app.css?v=36.27.9 app.js?v=36.27.9 */
/* Legacy cache marker: app.css?v=36.27.15 app.js?v=36.27.15 */
/* Legacy cache marker: app.css?v=36.27.18 app.js?v=36.27.18 */
/* Legacy cache marker: app.css?v=36.27.20 app.js?v=36.27.20 */
/* Legacy cache marker: app.css?v=36.28.3 app.js?v=36.28.3 */
/* Legacy cache marker: app.css?v=36.29.9 app.js?v=36.29.9 */
/* Legacy cache marker: app.css?v=36.30.2 app.js?v=36.30.2 */
/* Legacy cache marker: app.css?v=36.27.16 app.js?v=36.27.16 */

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Router;
use App\Core\View;
use App\Services\NotificationService;
use App\Services\OperationalAlertService;
use App\Services\OperationalLanguageService;
use App\Services\TenantModuleService;
use App\Services\ClientCommunicationService;
use App\Services\PageHelpService;
use App\Services\BrandingService;

$user = Auth::user();
$flashes = Flash::all();
$branding = Auth::isSuperAdmin() ? BrandingService::defaults() : BrandingService::forCurrentRequest();
$tenantIdentity = !Auth::isSuperAdmin() && !empty($branding['tenant_identity']);
$brandEnabled = !Auth::isSuperAdmin() && !empty($branding['enabled']);
$brandName = $tenantIdentity ? (string) ($branding['app_name'] ?? 'Empresa') : 'RS Connect';
$brandSubtitle = $tenantIdentity ? (string) ($branding['subtitle'] ?? 'Atendimento e Comercial') : 'Atendimento e Comercial';
$brandIconText = $tenantIdentity ? (string) ($branding['icon_text'] ?? 'EP') : 'RS';
$brandLogoUrl = $brandEnabled ? (string) ($branding['logo_url'] ?? '') : '';
$brandLogoBackground = $tenantIdentity ? (string) ($branding['logo_background'] ?? '#ffffff') : '#ffffff';
$brandLogoMarkStyle = 'background: ' . $brandLogoBackground . ' !important; border: 1px solid rgba(20, 100, 152, 0.14); box-shadow: inset 0 1px 0 rgba(255,255,255,0.85), 0 10px 22px rgba(15, 23, 42, 0.08); overflow: hidden; padding: 0;';
$brandLogoImageStyle = 'width: 100%; height: 100%; object-fit: cover; transform: scale(1.35); transform-origin: center; display: block;';
$brandFaviconUrl = '';
$brandPrimary = '#146498';
$brandSecondary = '#631b7c';
$brandAccent = '#01c5b6';
$brandFooterText = '';
$brandShowPoweredBy = false;
$brandCssVariables = '--rs-blue:' . $brandPrimary . ';--rs-purple:' . $brandSecondary . ';--rs-cyan:' . $brandAccent . ';--rs-teal:' . $brandAccent . ';';
$brandAssetHref = static fn (string $url): string => preg_match('~^https://~i', $url) === 1 ? $url : Router::url($url);
$currentPath = rtrim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/');
$isActive = static function (string $path) use ($currentPath): string {
    if ($path === '/') {
        $appPath = rtrim(parse_url(Router::url('/'), PHP_URL_PATH) ?: '/', '/');
        return $currentPath === $appPath ? ' is-active' : '';
    }
    return str_ends_with($currentPath, rtrim($path, '/')) ? ' is-active' : '';
};
$isAnyActive = static function (array $paths) use ($isActive): string {
    foreach ($paths as $path) {
        if ($isActive((string) $path) !== '') {
            return ' is-active';
        }
    }

    return '';
};

$notificationUnread = 0;
if (Auth::isSuperAdmin()) {
    try {
        $operationalAlerts = new OperationalAlertService();
        $notificationUnread = method_exists($operationalAlerts, 'unreadCount')
            ? $operationalAlerts->unreadCount((int) Auth::id())
            : 0;
    } catch (Throwable) {
        $notificationUnread = 0;
    }
} elseif (Auth::tenantId()) {
    $notificationUnread = (new NotificationService())->unreadCount((int) Auth::tenantId());
}
$notificationBadge = static fn (int $count): string => $count > 0 ? '<span class="nav-badge">' . min(99, $count) . '</span>' : '';
$notificationLiveBadge = static fn (int $count): string => '<span class="nav-badge" data-notification-badge' . ($count > 0 ? '' : ' hidden') . '>' . ($count > 0 ? min(99, $count) : 0) . '</span>';

$moduleService = new TenantModuleService();
$moduleVisible = static function (string $moduleKey) use ($moduleService): bool {
    if (Auth::isSuperAdmin()) {
        return true;
    }
    $tenantId = Auth::tenantId();
    return $tenantId ? $moduleService->visible((int) $tenantId, $moduleKey) : true;
};
$communicationInbox = ['unread' => 0, 'items' => [], 'latest' => null];
if (Auth::check() && !Auth::isSuperAdmin() && Auth::tenantId()) {
    try {
        $communicationInbox = (new ClientCommunicationService())->inbox((int) Auth::tenantId(), 30);
    } catch (Throwable) {
        $communicationInbox = ['unread' => 0, 'items' => [], 'latest' => null];
    }
}
$communicationUnread = (int) ($communicationInbox['unread'] ?? 0);
$communicationLatest = is_array($communicationInbox['latest'] ?? null) ? $communicationInbox['latest'] : null;
$tenantAccessStatus = is_array($_SESSION['tenant_access_status'] ?? null) ? $_SESSION['tenant_access_status'] : [];
$trialStatus = is_array($tenantAccessStatus['trial'] ?? null) ? $tenantAccessStatus['trial'] : [];
$tenantLifecycle = null;
if (Auth::check() && !Auth::isSuperAdmin() && Auth::tenantId()) {
    try {
        $lifecycleStatement = Database::connection()->prepare('SELECT lifecycle_status, lifecycle_changed_at, went_live_at FROM tenants WHERE id = :id LIMIT 1');
        $lifecycleStatement->execute(['id' => (int) Auth::tenantId()]);
        $tenantLifecycle = $lifecycleStatement->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable) {
        $tenantLifecycle = null;
    }
}
$pageHelp = (new PageHelpService())->forPath($_SERVER['REQUEST_URI'] ?? '/', Auth::isSuperAdmin());

$conversationUnread = 0;
if (Auth::check() && Auth::can('conversations.view')) {
    try {
        if (Auth::isSuperAdmin()) {
            $activeTenantId = (int) ($_GET['tenant_id'] ?? 0);
            if ($activeTenantId > 0) {
                $statement = Database::connection()->prepare('SELECT COALESCE(SUM(unread_count), 0) FROM conversations WHERE tenant_id = :tenant_id');
                $statement->execute(['tenant_id' => $activeTenantId]);
                $conversationUnread = (int) $statement->fetchColumn();
            } else {
                $conversationUnread = 0;
            }
        } elseif (Auth::tenantId()) {
            $statement = Database::connection()->prepare('SELECT COALESCE(SUM(unread_count), 0) FROM conversations WHERE tenant_id = :tenant_id');
            $statement->execute(['tenant_id' => Auth::tenantId()]);
            $conversationUnread = (int) $statement->fetchColumn();
        }
    } catch (Throwable) {
        $conversationUnread = 0;
    }
}
$svgIcon = static function (string $name): string {
    $icons = [
        'dashboard' => '<path d="M4 11.5 12 5l8 6.5V20a1 1 0 0 1-1 1h-5v-6h-4v6H5a1 1 0 0 1-1-1v-8.5Z"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'chat' => '<path d="M5 6h14v9H8l-3 3V6Z"/>',
        'contacts' => '<path d="M16 21v-2a4 4 0 0 0-8 0v2"/><circle cx="12" cy="7" r="4"/>',
        'crm' => '<path d="M4 6h16M4 12h16M4 18h16"/><path d="M8 6v12M16 6v12"/>',
        'tasks' => '<path d="M9 6h11M9 12h11M9 18h11"/><path d="m4 6 1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"/>',
        'reports' => '<path d="M4 19V5"/><path d="M8 17V9"/><path d="M12 17V7"/><path d="M16 17v-5"/><path d="M20 19H4"/>',
        'calendar' => '<path d="M7 3v4M17 3v4M4 9h16M5 5h14v16H5z"/>',
        'instance' => '<rect x="5" y="5" width="14" height="14" rx="3"/><path d="M9 9h6v6H9z"/>',
        'lock' => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'flow' => '<path d="M6 7h4v4H6zM14 13h4v4h-4zM10 9h2a2 2 0 0 1 2 2v2"/>',
        'template' => '<path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h5"/>',
        'billing' => '<path d="M12 2v20M17 7.5c0-2-2-3-5-3s-5 1-5 3 2 3 5 3 5 1 5 3-2 3-5 3-5-1-5-3"/>',
        'card' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/>',
        'bell' => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
        'agent' => '<path d="M12 3l2.4 5 5.6.8-4 3.9.9 5.5L12 15.6 7.1 18.2l.9-5.5-4-3.9 5.6-.8L12 3Z"/>',
        'automation' => '<path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="9"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'company' => '<path d="M4 21V5h10v16M14 9h6v12M8 9h2M8 13h2M8 17h2M17 13h1M17 17h1"/>',
        'palette' => '<path d="M12 3a9 9 0 1 0 0 18h1.5a1.5 1.5 0 0 0 0-3H12a2 2 0 0 1 0-4h4a5 5 0 0 0 5-5c0-3.3-4-6-9-6Z"/><circle cx="7.5" cy="10.5" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="14" cy="7" r="1"/><circle cx="16.5" cy="10.5" r="1"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-8 0v2"/><circle cx="12" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
        'permissions' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
        'security' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
        'implementation' => '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
        'operations' => '<path d="M4 19h16"/><path d="M6 16l3-4 3 2 4-7 2 4"/><circle cx="6" cy="16" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="12" cy="14" r="1"/><circle cx="16" cy="7" r="1"/>',
        'privacy' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="M9 12h6M12 9v6"/>',
        'help' => '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 1 1 5.8 1c-.7 1-1.9 1.4-2.4 2.5"/><path d="M12 17h.01"/>',
        'rocket' => '<path d="M5 14c-1 1-2 4-2 4s3-1 4-2"/><path d="M14 5l5-2-2 5-8 8-3-3 8-8Z"/><path d="M15 9l-4-4"/>',
        'status' => '<path d="M4 6h16"/><path d="M4 12h10"/><path d="M4 18h7"/><path d="M17 14l2 2 4-5"/>',
        'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
    ];
    $path = $icons[$name] ?? $icons['dashboard'];
    return '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
};
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="<?= View::e($brandPrimary) ?>">
    <title><?= View::e($title ?? $brandName) ?> — <?= View::e($brandName) ?></title>
    <?php if ($brandFaviconUrl !== ''): ?><link rel="icon" href="<?= View::e($brandAssetHref($brandFaviconUrl)) ?>"><?php endif; ?>
    <!-- Marcador histórico de regressão: app.css?v=36.20.2 -->
    <!-- Marcador histórico de regressão: app.css?v=36.20.5 -->
    <!-- Marcadores históricos de regressão: app.css?v=36.20.6 app.css?v=36.20.7 app.css?v=36.20.8 app.css?v=36.20.9 -->
    <!-- Compatibilidade histórica v36.30.5: app.css?v=36.30.5 app.js?v=36.30.5 -->
    <link rel="stylesheet" href="<?= View::e(Router::url('/assets/css/app.css?v=36.36.1')) ?>">
    <style>
        .brand.is-custom-brand .brand-mark-client-logo {
            width: 54px !important;
            height: 54px !important;
            min-width: 54px !important;
            padding: 0 !important;
            overflow: hidden;
            border-radius: 16px;
            transition: background-color .2s ease;
        }
        .brand.is-custom-brand .brand-mark-client-logo img {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            transform: scale(1.35);
            transform-origin: center;
            display: block;
            border-radius: 0;
        }
    </style>
</head>
<body<?= $tenantIdentity ? ' class="has-tenant-branding" style="' . View::e($brandCssVariables) . '"' : '' ?>>
<a class="skip-link" href="#main-content">Pular para o conteúdo principal</a>
<div class="sr-only" aria-live="polite" aria-atomic="true" data-app-live-region></div>
<div class="app-shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand<?= $tenantIdentity ? ' is-custom-brand' : '' ?>" href="<?= View::e(Router::url('/')) ?>">
            <?php if ($brandLogoUrl !== ''): ?>
                <span class="brand-mark brand-mark-image brand-mark-client-logo" style="<?= View::e($brandLogoMarkStyle) ?>">
                    <img src="<?= View::e($brandAssetHref($brandLogoUrl)) ?>" alt="Logo de <?= View::e($brandName) ?>" style="<?= View::e($brandLogoImageStyle) ?>">
                </span>
            <?php else: ?>
                <span class="brand-mark"><?= View::e($brandIconText) ?></span>
            <?php endif; ?>
            <span><strong><?= View::e($brandName) ?></strong><small><?= View::e($brandSubtitle) ?></small></span>
        </a>

        <nav class="sidebar-nav" aria-label="Navegação principal">
            <a class="nav-link<?= $isActive('/') ?>" href="<?= View::e(Router::url('/')) ?>"><?= $svgIcon('dashboard') ?><span>Visão geral</span></a>

            <?php if (!Auth::isSuperAdmin() && Auth::can('onboarding.manage')): ?>
                <a class="nav-link<?= $isActive('/onboarding') ?>" href="<?= View::e(Router::url('/onboarding')) ?>"><?= $svgIcon('check') ?><span>Primeiros passos</span></a>
            <?php endif; ?>

            <?php if ((Auth::can('conversations.view') && $moduleVisible('conversations')) || (Auth::can('queue.view') && $moduleVisible('queue')) || (Auth::can('contacts.view') && $moduleVisible('contacts')) || (Auth::can('crm.view') && $moduleVisible('crm')) || (Auth::can('tasks.view') && $moduleVisible('tasks')) || (Auth::can('calendar.view') && $moduleVisible('calendar'))): ?>
                <span class="nav-caption">Relacionamento</span>
            <?php endif; ?>
            <?php if (Auth::can('conversations.view') && $moduleVisible('conversations')): ?>
                <a class="nav-link<?= $isActive('/conversations') ?>" href="<?= View::e(Router::url('/conversations')) ?>"><?= $svgIcon('chat') ?><span>Conversas</span><?= $notificationBadge($conversationUnread) ?></a>
            <?php endif; ?>
            <?php if (Auth::can('conversations.view') && $moduleVisible('conversations')): ?>
                <a class="nav-link<?= $isActive('/carga-operacional') ?>" href="<?= View::e(Router::url('/carga-operacional')) ?>"><?= $svgIcon('operations') ?><span>Carga operacional</span></a>
            <?php endif; ?>
            <?php if (Auth::can('queue.view') && $moduleVisible('queue')): ?>
                <a class="nav-link<?= $isActive('/queue') ?>" href="<?= View::e(Router::url('/queue')) ?>"><?= $svgIcon('users') ?><span>Fila e setores</span></a>
            <?php endif; ?>
            <?php if (Auth::can('contacts.view') && $moduleVisible('contacts')): ?>
                <a class="nav-link<?= $isActive('/contacts') ?>" href="<?= View::e(Router::url('/contacts')) ?>"><?= $svgIcon('contacts') ?><span>Contatos</span></a>
            <?php endif; ?>
            <?php if (Auth::can('crm.view') && $moduleVisible('crm')): ?>
                <a class="nav-link<?= $isActive('/crm') ?>" href="<?= View::e(Router::url('/crm')) ?>"><?= $svgIcon('crm') ?><span><?= Auth::isSuperAdmin() ? 'Comercial RS' : 'Comercial' ?></span></a>
            <?php endif; ?>
            <?php if (Auth::can('tasks.view') && $moduleVisible('tasks')): ?>
                <a class="nav-link<?= $isActive('/tasks') ?>" href="<?= View::e(Router::url('/tasks')) ?>"><?= $svgIcon('tasks') ?><span>Atividades</span></a>
            <?php endif; ?>
            <?php if (Auth::can('calendar.view') && $moduleVisible('calendar')): ?>
                <a class="nav-link<?= $isAnyActive(['/calendar', '/calendar/availability', '/agenda-inteligente', '/agenda-disponibilidade']) ?>" href="<?= View::e(Router::url('/calendar')) ?>"><?= $svgIcon('calendar') ?><span>Agenda</span></a>
            <?php endif; ?>
            <?php if (Auth::can('reports.view') && $moduleVisible('reports')): ?>
                <a class="nav-link<?= $isActive('/reports') ?>" href="<?= View::e(Router::url('/reports')) ?>"><?= $svgIcon('reports') ?><span><?= Auth::isSuperAdmin() ? 'Relatórios executivos' : 'Relatórios' ?></span></a>
            <?php endif; ?>

            <?php if (Auth::isSuperAdmin()): ?>
                <span class="nav-caption">WhatsApp e inteligência artificial</span>
                <?php if (Auth::can('instances.view')): ?>
                    <a class="nav-link<?= $isActive('/instances') ?>" href="<?= View::e(Router::url('/instances')) ?>"><?= $svgIcon('instance') ?><span>Canais WhatsApp</span></a>
                <?php endif; ?>
                <a class="nav-link<?= $isActive('/ai-credentials') ?>" href="<?= View::e(Router::url('/ai-credentials')) ?>"><?= $svgIcon('lock') ?><span>Assistentes e chaves de acesso</span></a>
                <a class="nav-link<?= $isActive('/openai-usage') ?>" href="<?= View::e(Router::url('/openai-usage')) ?>"><?= $svgIcon('reports') ?><span>Uso e custo da IA</span></a>
                <a class="nav-link<?= $isActive('/ai-profitability') ?>" href="<?= View::e(Router::url('/ai-profitability')) ?>"><?= $svgIcon('billing') ?><span>Resultados por cliente</span></a>
                <a class="nav-link<?= $isActive('/client-attention') ?>" href="<?= View::e(Router::url('/client-attention')) ?>"><?= $svgIcon('bell') ?><span>Clientes que precisam de atenção</span></a>
                <a class="nav-link<?= $isAnyActive(['/n8n', '/n8n-flows', '/n8n-templates']) ?>" href="<?= View::e(Router::url('/n8n')) ?>"><?= $svgIcon('flow') ?><span>Automações (n8n)</span></a>

                <span class="nav-caption">Financeiro</span>
                <a class="nav-link<?= $isActive('/billing') ?>" href="<?= View::e(Router::url('/billing')) ?>"><?= $svgIcon('billing') ?><span>Planos e cobrança</span></a>
                <a class="nav-link<?= $isActive('/payment-gateways') ?>" href="<?= View::e(Router::url('/payment-gateways')) ?>"><?= $svgIcon('card') ?><span>Meios de pagamento</span></a>
                <a class="nav-link<?= $isActive('/settings/public-signup') ?>" href="<?= View::e(Router::url('/settings/public-signup')) ?>"><?= $svgIcon('users') ?><span>Inscrição pública</span></a>
                <a class="nav-link<?= $isActive('/billing-reminders') ?>" href="<?= View::e(Router::url('/billing-reminders')) ?>"><?= $svgIcon('bell') ?><span>Lembretes de cobrança</span></a>

                <span class="nav-caption">Operação RS</span>
                <a class="nav-link<?= $isAnyActive(['/painel-operacional', '/operacao-rs']) ?>" href="<?= View::e(Router::url('/painel-operacional')) ?>"><?= $svgIcon('operations') ?><span>Painel operacional</span></a>
                <a class="nav-link<?= $isAnyActive(['/central-operacao', '/security', '/seguranca', '/operations', '/monitoramento', '/backup-automatico', '/operations/backups/automation', '/operations/ai-reprocess', '/beta-comercial', '/status-sistema']) ?>" href="<?= View::e(Router::url('/central-operacao')) ?>"><?= $svgIcon('operations') ?><span>Saúde do sistema</span></a>
                <a class="nav-link<?= $isActive('/operacao-alertas') ?>" href="<?= View::e(Router::url('/operacao-alertas')) ?>"><?= $svgIcon('bell') ?><span>Avisos do sistema</span><?= $notificationBadge($notificationUnread) ?></a>
                <a class="nav-link<?= $isActive('/comunicados') ?>" href="<?= View::e(Router::url('/comunicados')) ?>"><?= $svgIcon('chat') ?><span>Comunicados</span></a>
                <a class="nav-link<?= $isActive('/implementation') ?>" href="<?= View::e(Router::url('/implementation')) ?>"><?= $svgIcon('implementation') ?><span>Implantação</span></a>

                <span class="nav-caption">Administração RS</span>
                <a class="nav-link<?= $isAnyActive(['/companies', '/companies/overview', '/companies/health', '/company-settings']) ?>" href="<?= View::e(Router::url('/companies')) ?>"><?= $svgIcon('company') ?><span>Empresas</span></a>
                <a class="nav-link<?= $isActive('/agent-blueprints') ?>" href="<?= View::e(Router::url('/agent-blueprints')) ?>"><?= $svgIcon('agent') ?><span>Modelos por segmento</span></a>
                <a class="nav-link<?= $isActive('/agent-tests') ?>" href="<?= View::e(Router::url('/agent-tests')) ?>"><?= $svgIcon('chat') ?><span>Testar assistentes</span></a>
                <a class="nav-link<?= $isAnyActive(['/white-label', '/white_label']) ?>" href="<?= View::e(Router::url('/white-label')) ?>"><?= $svgIcon('palette') ?><span>Marca dos clientes</span></a>
                <?php if (Auth::can('users.view')): ?>
                    <a class="nav-link<?= $isActive('/users') ?>" href="<?= View::e(Router::url('/users')) ?>"><?= $svgIcon('users') ?><span>Usuários</span></a>
                <?php endif; ?>
                <?php if (Auth::can('permissions.view')): ?>
                    <a class="nav-link<?= $isActive('/permissions') ?>" href="<?= View::e(Router::url('/permissions')) ?>"><?= $svgIcon('permissions') ?><span>Permissões</span></a>
                <?php endif; ?>
                <a class="nav-link<?= $isActive('/privacy') ?>" href="<?= View::e(Router::url('/privacy')) ?>"><?= $svgIcon('privacy') ?><span>Privacidade/LGPD</span></a>
                <a class="nav-link<?= $isActive('/ajuda') ?>" href="<?= View::e(Router::url('/ajuda')) ?>"><?= $svgIcon('help') ?><span>Central de ajuda</span></a>
            <?php else: ?>
                <?php if ((Auth::can('instances.view') && $moduleVisible('instances')) || (Auth::can('agents.view') && $moduleVisible('agents')) || (Auth::can('automations.view') && $moduleVisible('automations'))): ?>
                    <span class="nav-caption">Automação</span>
                <?php endif; ?>
                <?php if (Auth::can('instances.view') && $moduleVisible('instances')): ?>
                    <a class="nav-link<?= $isActive('/instances') ?>" href="<?= View::e(Router::url('/instances')) ?>"><?= $svgIcon('instance') ?><span>Canais WhatsApp</span></a>
                <?php endif; ?>
                <?php if (Auth::can('agents.view') && $moduleVisible('agents')): ?>
                    <a class="nav-link<?= $isActive('/agents') ?>" href="<?= View::e(Router::url('/agents')) ?>"><?= $svgIcon('agent') ?><span>Assistentes de IA</span></a>
                <?php endif; ?>
                <?php if (Auth::can('automations.view') && $moduleVisible('automations')): ?>
                    <a class="nav-link<?= $isActive('/automations') ?>" href="<?= View::e(Router::url('/automations')) ?>"><?= $svgIcon('automation') ?><span>Automações</span></a>
                <?php endif; ?>

                <?php if ((Auth::can('company.view') && $moduleVisible('company_settings'))
                    || (Auth::can('users.view') && $moduleVisible('users'))
                    || (Auth::can('permissions.view') && $moduleVisible('permissions'))
                    || (Auth::can('privacy.view') && $moduleVisible('privacy'))
                    || (Auth::can('billing.view') && $moduleVisible('subscription'))
                    || (Auth::can('notifications.view') && $moduleVisible('notifications'))): ?>
                    <span class="nav-caption">Administração</span>
                <?php endif; ?>
                <?php if (Auth::can('company.view') && $moduleVisible('company_settings')): ?>
                    <a class="nav-link<?= $isActive('/company-settings') ?>" href="<?= View::e(Router::url('/company-settings')) ?>"><?= $svgIcon('company') ?><span>Minha empresa</span></a>
                <?php endif; ?>
                <?php if (Auth::can('users.view') && $moduleVisible('users')): ?>
                    <a class="nav-link<?= $isActive('/users') ?>" href="<?= View::e(Router::url('/users')) ?>"><?= $svgIcon('users') ?><span>Usuários</span></a>
                <?php endif; ?>
                <?php if (Auth::can('permissions.view') && $moduleVisible('permissions')): ?>
                    <a class="nav-link<?= $isActive('/permissions') ?>" href="<?= View::e(Router::url('/permissions')) ?>"><?= $svgIcon('permissions') ?><span>Permissões</span></a>
                <?php endif; ?>
                <?php if (Auth::can('privacy.view') && $moduleVisible('privacy')): ?>
                    <a class="nav-link<?= $isAnyActive(['/privacy', '/lgpd']) ?>" href="<?= View::e(Router::url('/privacy')) ?>"><?= $svgIcon('privacy') ?><span>Privacidade/LGPD</span></a>
                <?php endif; ?>
                <?php if (Auth::can('billing.view') && $moduleVisible('subscription')): ?>
                    <a class="nav-link<?= $isActive('/subscription') ?>" href="<?= View::e(Router::url('/subscription')) ?>"><?= $svgIcon('billing') ?><span>Assinatura e uso</span></a>
                <?php endif; ?>
                <?php if (Auth::can('notifications.view') && $moduleVisible('notifications')): ?>
                    <a class="nav-link<?= $isActive('/notifications') ?>" href="<?= View::e(Router::url('/notifications')) ?>"><?= $svgIcon('bell') ?><span>Notificações</span><?= $notificationBadge($notificationUnread) ?></a>
                    <?php if (Auth::can('notifications.manage')): ?>
                        <a class="nav-link<?= $isActive('/settings/notifications') ?>" href="<?= View::e(Router::url('/settings/notifications')) ?>"><?= $svgIcon('bell') ?><span>Config. notificações</span></a>
                    <?php endif; ?>
                <?php endif; ?>
                <a class="nav-link<?= $isActive('/ajuda') ?>" href="<?= View::e(Router::url('/ajuda')) ?>"><?= $svgIcon('help') ?><span>Central de ajuda</span></a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-footer">
            <div class="user-mini">
                <span class="avatar"><?= View::e(mb_strtoupper(mb_substr($user['name'] ?? 'U', 0, 1))) ?></span>
                <span><strong><?= View::e($user['name'] ?? '') ?></strong><small><?= View::e($user['tenant_name'] ?? 'Equipe RS') ?></small></span>
            </div>
            <form method="post" action="<?= View::e(Router::url('/logout')) ?>">
                <?= Csrf::input() ?>
                <button class="btn btn-quiet btn-block" type="submit">Sair da conta</button>
            </form>
        </div>
    </aside>
    <button class="sidebar-backdrop" id="sidebarBackdrop" type="button" aria-label="Fechar menu"></button>

    <main class="main-content" id="main-content" tabindex="-1">
        <header class="topbar topbar-v36181">
            <a class="topbar-home" href="<?= View::e(Router::url('/')) ?>" aria-label="Ir para o início"><?= $svgIcon('dashboard') ?></a>
            <div class="topbar-title-block">
                <span class="eyebrow"><?= Auth::isSuperAdmin() ? 'Operação RS' : View::e($brandEnabled ? $brandName : ($user['tenant_name'] ?? 'Cliente')) ?></span>
                <h1><?= View::e($title ?? 'RS Connect') ?></h1>
            </div>
            <div class="topbar-module-search" data-module-search>
                <span class="topbar-search-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                </span>
                <input type="search" placeholder="Buscar página ou função..." autocomplete="off" aria-label="Buscar página ou função" data-module-search-input>
                <kbd>Ctrl K</kbd>
                <div class="topbar-search-results" data-module-search-results hidden></div>
            </div>
            <div class="topbar-actions">
                <button class="topbar-action-button" type="button" data-context-help-open aria-label="Abrir ajuda desta página" title="Ajuda desta página — tecla ?"><?= $svgIcon('help') ?></button>
                <?php if (Auth::isSuperAdmin()): ?>
                    <a class="topbar-notification" href="<?= View::e(Router::url('/operacao-alertas')) ?>" aria-label="Avisos do sistema" data-notification-link data-count-url="<?= View::e(Router::url('/operacao-alertas/count')) ?>">
                        <?= $svgIcon('bell') ?>
                        <?= $notificationLiveBadge($notificationUnread) ?>
                    </a>
                <?php elseif (Auth::can('notifications.view') && $moduleVisible('notifications')): ?>
                    <a class="topbar-notification" href="<?= View::e(Router::url('/notifications')) ?>" aria-label="Notificações" data-notification-link data-count-url="<?= View::e(Router::url('/notifications/count')) ?>">
                        <?= $svgIcon('bell') ?>
                        <?= $notificationLiveBadge($notificationUnread) ?>
                    </a>
                <?php endif; ?>
                <div class="topbar-profile" title="<?= View::e($user['name'] ?? '') ?>">
                    <span class="topbar-profile-avatar"><?= View::e(mb_strtoupper(mb_substr($user['name'] ?? 'U', 0, 1))) ?></span>
                    <span class="topbar-profile-copy"><strong><?= View::e($user['name'] ?? '') ?></strong><small><?= Auth::isSuperAdmin() ? 'Administrador RS' : View::e($user['tenant_name'] ?? 'Administrador') ?></small></span>
                </div>
            </div>
        </header>

        <?php if (!Auth::isSuperAdmin() && !empty($trialStatus)): ?>
            <section class="trial-access-banner<?= !empty($trialStatus['in_grace']) ? ' is-grace' : '' ?>">
                <span class="trial-access-icon" aria-hidden="true"><?= $svgIcon('clock') ?></span>
                <div>
                    <strong><?= !empty($trialStatus['in_grace']) ? 'Período gratuito encerrado' : 'Teste gratuito em andamento' ?></strong>
                    <span><?php if (!empty($trialStatus['in_grace'])): ?>Acesso em tolerância comercial<?= !empty($trialStatus['grace_ends_at']) ? ' até ' . View::e(date('d/m/Y', strtotime((string) $trialStatus['grace_ends_at']))) : '' ?>.<?php else: ?><?= (int) ($trialStatus['days_remaining'] ?? 0) ?> dia(s) restante(s)<?= !empty($trialStatus['ends_at']) ? ', até ' . View::e(date('d/m/Y', strtotime((string) $trialStatus['ends_at']))) : '' ?>.<?php endif; ?></span>
                </div>
                <a class="btn btn-small btn-outline" href="<?= View::e(Router::url('/subscription')) ?>">Ver plano</a>
            </section>
        <?php endif; ?>

        <?php if (!Auth::isSuperAdmin() && is_array($tenantLifecycle) && (($tenantLifecycle['lifecycle_status'] ?? 'onboarding') !== 'live')): ?>
            <?php $tenantLifecycleStatus = (string) ($tenantLifecycle['lifecycle_status'] ?? 'onboarding'); ?>
            <section class="trial-access-banner<?= $tenantLifecycleStatus === 'suspended' ? ' is-grace' : '' ?>" role="status">
                <span class="trial-access-icon" aria-hidden="true"><?= $svgIcon($tenantLifecycleStatus === 'suspended' ? 'status' : 'rocket') ?></span>
                <div>
                    <strong><?= $tenantLifecycleStatus === 'ready' ? 'Ambiente pronto para produção' : ($tenantLifecycleStatus === 'suspended' ? 'Operação produtiva suspensa' : 'Ambiente de onboarding / homologação') ?></strong>
                    <span><?= $tenantLifecycleStatus === 'ready' ? 'Configuração concluída. SLA e métricas oficiais só começam após o Go-Live confirmado pela RS.' : ($tenantLifecycleStatus === 'suspended' ? 'Novas métricas oficiais estão pausadas; o histórico de produção anterior permanece preservado.' : 'Você pode testar WhatsApp, IA, agenda e atendimento normalmente sem contaminar SLA e métricas oficiais.') ?></span>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($flashes): ?>
            <section class="flash-stack" aria-live="polite">
                <?php foreach ($flashes as $flash): ?>
                    <div class="flash flash-<?= View::e($flash['type']) ?>">
                        <span><?= View::e(OperationalLanguageService::replaceTechnicalTerms((string) $flash['message'])) ?></span>
                        <button type="button" data-dismiss-flash aria-label="Fechar">×</button>
                    </div>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <section class="page-content"><?= $content ?></section>
        <?php if ($brandEnabled && ($brandFooterText !== '' || $brandShowPoweredBy)): ?>
            <footer class="tenant-brand-footer">
                <span><?= View::e($brandFooterText !== '' ? $brandFooterText : $brandName) ?></span>
                <?php if ($brandShowPoweredBy): ?><small>Powered by RS Connect</small><?php endif; ?>
            </footer>
        <?php endif; ?>
    </main>
</div>
<div class="context-help-backdrop" data-context-help-backdrop hidden></div>
<aside class="context-help-drawer" data-context-help-drawer hidden role="dialog" aria-modal="true" aria-labelledby="context-help-title">
    <header class="context-help-header">
        <div>
            <span class="eyebrow">Ajuda desta página</span>
            <h2 id="context-help-title"><?= View::e((string) ($pageHelp['title'] ?? 'Ajuda desta página')) ?></h2>
            <p><?= View::e((string) ($pageHelp['summary'] ?? '')) ?></p>
        </div>
        <button class="icon-button" type="button" data-context-help-close aria-label="Fechar ajuda">×</button>
    </header>
    <div class="context-help-body">
        <?php if (!empty($pageHelp['steps'])): ?>
            <section class="context-help-section">
                <span class="eyebrow">Como usar</span>
                <ol class="context-help-steps">
                    <?php foreach ((array) $pageHelp['steps'] as $step): ?><li><?= View::e((string) $step) ?></li><?php endforeach; ?>
                </ol>
            </section>
        <?php endif; ?>
        <?php if (!empty($pageHelp['tips'])): ?>
            <section class="context-help-section is-tip">
                <span class="eyebrow">Dicas importantes</span>
                <ul class="context-help-tips">
                    <?php foreach ((array) $pageHelp['tips'] as $tip): ?><li><?= View::e((string) $tip) ?></li><?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>
        <?php if (!empty($pageHelp['terms'])): ?>
            <section class="context-help-section">
                <span class="eyebrow">O que estes nomes significam?</span>
                <dl class="context-help-terms">
                    <?php foreach ((array) $pageHelp['terms'] as $term => $meaning): ?><div><dt><?= View::e((string) $term) ?></dt><dd><?= View::e((string) $meaning) ?></dd></div><?php endforeach; ?>
                </dl>
            </section>
        <?php endif; ?>
        <section class="context-help-section context-help-accessibility">
            <span class="eyebrow">Conforto de leitura</span>
            <button class="context-help-setting" type="button" data-reading-mode-toggle aria-pressed="false">
                <span><strong>Texto um pouco maior</strong><small>Aumenta textos e campos sem alterar os dados.</small></span>
                <i aria-hidden="true"></i>
            </button>
            <button class="context-help-setting" type="button" data-reduced-motion-toggle aria-pressed="false">
                <span><strong>Reduzir movimentos</strong><small>Diminui animações e transições da interface.</small></span>
                <i aria-hidden="true"></i>
            </button>
        </section>
    </div>
    <footer class="context-help-footer">
        <a class="btn btn-outline" href="<?= View::e(Router::url((string) ($pageHelp['manual_url'] ?? '/ajuda'))) ?>">Abrir manual completo</a>
        <?php if (!empty($pageHelp['primary_url']) && !empty($pageHelp['primary_label'])): ?>
            <a class="btn btn-primary" href="<?= View::e(Router::url((string) $pageHelp['primary_url'])) ?>"><?= View::e((string) $pageHelp['primary_label']) ?></a>
        <?php endif; ?>
    </footer>
</aside>
<button class="icon-button global-sidebar-toggle" id="sidebarToggle" type="button" aria-label="Abrir menu" aria-controls="sidebar" aria-expanded="false"><?= $svgIcon('menu') ?></button>
<?php if (!Auth::isSuperAdmin() && Auth::tenantId()): ?>
<div class="rs-communication-hub"
     data-rs-communication-hub
     data-inbox-url="<?= View::e(Router::url('/communications/inbox')) ?>"
     data-read-url="<?= View::e(Router::url('/communications/read')) ?>"
     data-ack-url="<?= View::e(Router::url('/communications/acknowledge')) ?>"
     data-respond-url="<?= View::e(Router::url('/communications/respond')) ?>"
     data-requested-communication-id="<?= (int) ($_GET['communication_id'] ?? 0) ?>"
     data-csrf="<?= View::e(Csrf::token()) ?>"<?= $communicationUnread > 0 ? '' : ' hidden' ?>>
    <script type="application/json" data-communication-initial><?= json_encode($communicationInbox, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
    <section class="rs-communication-float<?= (($communicationLatest['priority'] ?? '') === 'important') ? ' is-important' : ((($communicationLatest['priority'] ?? '') === 'critical') ? ' is-critical' : '') ?>" data-communication-float<?= $communicationUnread > 0 ? '' : ' hidden' ?> aria-live="polite">
        <button class="rs-communication-float-close" type="button" data-communication-minimize aria-label="Minimizar mensagem">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 12h12"/></svg>
        </button>
        <span class="rs-communication-float-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 6h14v9H8l-3 3V6Z"/></svg>
        </span>
        <div class="rs-communication-float-copy">
            <small>Mensagem da RS Connect</small>
            <strong data-communication-float-title><?= View::e((string) ($communicationLatest['title'] ?? 'Nova mensagem')) ?></strong>
            <span data-communication-float-message><?= View::e((string) ($communicationLatest['message'] ?? 'Abra para ver os detalhes.')) ?></span>
        </div>
        <button class="btn btn-small" type="button" data-communication-open>Ver mensagem</button>
    </section>
    <button class="rs-communication-bubble" type="button" data-communication-bubble hidden aria-label="Abrir mensagens da RS Connect">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 6h14v9H8l-3 3V6Z"/></svg>
        <span data-communication-bubble-count><?= min(99, $communicationUnread) ?></span>
    </button>
    <div class="rs-communication-drawer-backdrop" data-communication-drawer-backdrop hidden></div>
    <aside class="rs-communication-drawer" data-communication-drawer hidden aria-label="Mensagens da RS Connect" aria-modal="true" role="dialog">
        <header>
            <div><small>Central de comunicação</small><h2>Mensagens da RS Connect</h2></div>
            <button class="icon-button" type="button" data-communication-close aria-label="Fechar mensagens">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="m6 6 12 12M18 6 6 18"/></svg>
            </button>
        </header>
        <div class="rs-communication-drawer-body">
            <nav class="rs-communication-inbox-list" data-communication-list aria-label="Lista de mensagens"></nav>
            <section class="rs-communication-thread" data-communication-thread>
                <div class="rs-communication-thread-empty">Selecione uma mensagem para ler os detalhes.</div>
            </section>
        </div>
    </aside>
</div>
<?php endif; ?>
<button class="back-to-top" type="button" data-back-to-top aria-label="Voltar ao topo" title="Voltar ao topo">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 15 6-6 6 6"/></svg>
</button>
<!-- Marcador histórico de regressão: app.js?v=36.20.2 -->
<!-- Marcador histórico de regressão: app.js?v=36.20.5 -->
<!-- Marcadores históricos de regressão: app.js?v=36.20.6 app.js?v=36.20.7 app.js?v=36.20.8 app.js?v=36.20.9 -->
<script src="<?= View::e(Router::url('/assets/js/app.js?v=36.34.1')) ?>" defer></script>
</body>
</html>
